from pathlib import Path
import csv, json, math
root=Path(__file__).resolve().parents[1]
b={}
for mode in ('free','fixed'):
    for task in ('Mg_far_cu','Mg_common_neighbor','Zn_far_cu','Zn_common_neighbor'):
        folder=root/'DFT_paths'/mode/task
        rows=list(csv.DictReader((folder/'profile.csv').open(encoding='utf-8-sig')))
        energy=[float(r['energy_ev']) for r in rows]
        barrier=max(energy)-energy[0]
        saved=json.loads((folder/'summary.json').read_text())['forward_barrier_ev']
        assert math.isclose(barrier,saved,abs_tol=1e-9),(mode,task,barrier,saved)
        b[mode,task]=barrier
        print(mode,task,'barrier_eV',f'{barrier:.8f}')
for solute in ('Mg','Zn'):
    common=solute+'_common_neighbor'; far=solute+'_far_cu'
    direct=b['fixed',common]-b['free',common]
    baseline=b['fixed',far]-b['free',far]
    print(solute,'direct_constraint_meV',f'{1000*direct:.5f}',
          'far_baseline_meV',f'{1000*baseline:.5f}',
          'corrected_constraint_meV',f'{1000*(direct-baseline):.5f}')
print('All eight forward barriers match the saved summaries within 1e-9 eV.')
