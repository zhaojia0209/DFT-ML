from pathlib import Path
import csv,hashlib
root=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((root/'MANIFEST.csv').open(encoding='utf-8')))
for r in rows:
    p=root/r['path']; data=p.read_bytes()
    assert len(data)==int(r['bytes']),r['path']
    assert hashlib.sha256(data).hexdigest()==r['sha256'],r['path']
print('Verified',len(rows),'files against MANIFEST.csv')
