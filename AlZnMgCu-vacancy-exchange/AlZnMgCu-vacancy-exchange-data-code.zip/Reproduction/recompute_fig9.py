"""Reproduce Fig. 9 from the supplied seven-image final free-Cu POSCAR bands.
Requires NumPy. Run from any directory; this script resolves its own data paths.
No DFT or relaxation is performed.
"""
from pathlib import Path
import csv
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def poscar(path):
    lines=path.read_text(encoding='utf-8').splitlines();scale=float(lines[1])
    cell=np.array([[float(v) for v in x.split()[:3]] for x in lines[2:5]])*scale
    names=lines[5].split();counts=list(map(int,lines[6].split()))
    symbols=np.array([s for s,n in zip(names,counts) for _ in range(n)])
    idx=7+(lines[7].strip().lower().startswith('s'))
    xyz=np.array([[float(v) for v in x.split()[:3]] for x in lines[idx+1:idx+1+sum(counts)]])
    return symbols,cell,xyz@cell if lines[idx].strip().lower().startswith('d') else xyz*scale
def mic(v,cell):
    frac=v@np.linalg.inv(cell);return (frac-np.round(frac))@cell
results=[]
for task in ('Mg_far_cu','Mg_common_neighbor','Zn_far_cu','Zn_common_neighbor'):
    band=ROOT/'DFT_paths/free'/task/'band'
    sy,cell,r0=poscar(band/'00/POSCAR');al=np.flatnonzero(sy=='Al');cu=int(np.flatnonzero(sy=='Cu')[0]);x=int(np.flatnonzero(sy==task.split('_')[0])[0])
    local=al[np.linalg.norm(mic(r0[al]-r0[cu],cell),axis=1)<3.1]
    midpoint=mic(r0[x],cell)/2
    d0=np.linalg.norm(mic(r0[cu]-r0[x],cell));mid0=np.linalg.norm(mic(r0[cu]-midpoint,cell))
    for i in range(7):
        syi,ci,ri=poscar(band/f'{i:02d}/POSCAR');assert np.array_equal(syi,sy) and np.allclose(ci,cell)
        dr=mic(ri-r0,cell);host_mean=dr[al].mean(axis=0);u=dr-host_mean
        results.append({'task':task,'image':i,'normalized_image_index':i/6,'selected_Al_count':len(local),'selected_Al_1based':';'.join(str(j+1) for j in local),'Cu_displacement_A':float(np.linalg.norm(u[cu])),'delta_Cu_migrating_atom_distance_A':float(np.linalg.norm(mic(ri[cu]-ri[x],cell))-d0),'delta_Cu_fixed_initial_midpoint_distance_A':float(np.linalg.norm(mic(r0[cu]+u[cu]-midpoint,cell))-mid0),'local_Al_RMS_A':float(np.sqrt(np.mean(np.sum(u[local]**2,axis=1))))})
with (ROOT/'Figure_data/Fig9_recomputed.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
for filename,keys in [('Fig9_abc.csv',('Cu_displacement_A','delta_Cu_migrating_atom_distance_A','delta_Cu_fixed_initial_midpoint_distance_A')),('Fig9_d.csv',('local_Al_RMS_A',))]:
    expected={(r['task'],int(r['image'])):r for r in csv.DictReader((ROOT/'Figure_data'/filename).open(encoding='utf-8-sig'))}
    for r in results:
        for key in keys:assert abs(r[key]-float(expected[(r['task'],r['image'])][key]))<1e-9,(r['task'],r['image'],key)
print('All 28 image records reproduce Fig. 9 within 1e-9 angstrom.')
