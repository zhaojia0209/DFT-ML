#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ROOT="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT"

POOL="work/active_learning_v1/pool_v1.extxyz"
OUT="work/active_learning_v1/predictions"
SELECTED="work/active_learning_v1/selected_v1.extxyz"
models=(
  "work/final_models/alzmcv_neb_v4_epoch145_candidate.model"
  "work/neb_retrain_v4/02_mace/ensemble_seed29/checkpoints/alzmcv_neb_v4_seed29_run-29_stagetwo.model"
  "work/neb_retrain_v4/02_mace/ensemble_seed47/checkpoints/alzmcv_neb_v4_seed47_run-47_stagetwo.model"
)
mkdir -p "$OUT"
if [[ ! -s "$POOL" ]]; then
  echo "[failed] pool not found: $POOL" >&2
  exit 1
fi
for i in "${!models[@]}"; do
  model="${models[$i]}"
  output="$OUT/model_${i}.extxyz"
  echo "[run] ensemble model $i"
  mace_eval_configs --configs="$POOL" --model="$model" \
    --output="$output" --device=cpu --info_prefix=MACE_
  echo "[done] $output"
done
python3 scripts/22_active_learning_v1.py --config configs/refined.yaml select \
  --predictions "$OUT/model_0.extxyz" "$OUT/model_1.extxyz" "$OUT/model_2.extxyz" \
  --output "$SELECTED"
python3 - "$SELECTED" <<'PY'
import sys
from ase.io import read
frames = read(sys.argv[1], index=":")
print(f"[done] selected frames: {len(frames)}")
PY
