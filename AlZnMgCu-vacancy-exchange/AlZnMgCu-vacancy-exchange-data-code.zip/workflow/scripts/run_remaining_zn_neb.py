"""Run the three remaining Zn NEBs; deliberately replace incomplete output logs."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import resource
import subprocess
import time

from cu_dft_workflow import signature, incar
from recover_mg_common_neb import check_idle


def converged(path, since=None):
    for image in ('01', '02', '03', '04', '05'):
        out = path / image / 'OUTCAR'
        if not out.exists() or (since is not None and out.stat().st_mtime < since):
            return False
        text = out.read_text(errors='replace')
        if 'reached required accuracy' not in text or 'General timing and accounting' not in text:
            return False
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ranks', type=int, default=90)
    args = parser.parse_args()
    if args.ranks <= 0 or args.ranks % 10:
        parser.error('MPI ranks must be a positive multiple of 10')
    root = Path('/home/zhaojia/AlZnMgCuV1/work/cu_environment_dft_v1/neb')
    check_idle()
    with (root / 'remaining_zn.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # The original runner removes this on ordinary errors. Do not bypass a live/stale lock blindly.
        if (root / 'RUNNING.lock').exists():
            raise RuntimeError('RUNNING.lock exists; inspect before launching another batch')
        resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY, resource.getrlimit(resource.RLIMIT_STACK)[1]))
        env = os.environ.copy()
        env.pop('LD_PRELOAD', None)
        env.update(OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
        libs = [p for p in env.get('LD_LIBRARY_PATH', '').split(':') if p and 'libtorch' not in p.lower()]
        env['LD_LIBRARY_PATH'] = '/opt/intel/oneapi/mpi/2021.12/lib:' + ':'.join(libs)
        mpi = '/opt/intel/oneapi/mpi/2021.12/bin/mpirun'
        vasp = '/home/zhaojia/vasp.6.4.2/bin/vasp_std'
        for executable in (mpi, vasp):
            if not Path(executable).is_file():
                raise FileNotFoundError(executable)
        print('[runtime] stack=unlimited; MPI ranks={}'.format(args.ranks), flush=True)
        print('[skip] Mg_no_cu, Mg_far_cu, Mg_common_neighbor: outside this batch', flush=True)
        with (root / 'RUNNING.lock').open('x') as stage_lock:
            stage_lock.write(str(os.getpid()))
        try:
            for name in ('Zn_no_cu', 'Zn_far_cu', 'Zn_common_neighbor'):
                task = root / 'tasks' / name
                cfg = incar(task / 'INCAR')
                for tag, expected in {'IMAGES': '5', 'NCORE': '2', 'KPAR': '1', 'ISTART': '0', 'ICHARG': '2'}.items():
                    if cfg.get(tag) != expected:
                        raise RuntimeError('{}: expected {}={}'.format(name, tag, expected))
                for image in ('00', '01', '02', '03', '04', '05', '06'):
                    if not (task / image / 'POSCAR').is_file():
                        raise FileNotFoundError(task / image / 'POSCAR')
                sig = signature(task)
                record_path = task / 'execution.json'
                try:
                    old = json.loads(record_path.read_text())
                except (FileNotFoundError, ValueError):
                    old = {}
                if converged(task):
                    if old.get('input_sha256') not in (None, sig):
                        raise RuntimeError(name + ': converged outputs have mismatched input signature')
                    print('[skip] ' + name + ': all images converged', flush=True)
                    continue
                record = dict(task=name, input_sha256=sig, exit_code=None, status='running')
                record_path.write_text(json.dumps(record, indent=2))
                print('[run] ' + name + ' (current POSCARs; replacing incomplete output logs)', flush=True)
                started = time.time()
                with (task / 'vasp.stdout').open('w') as out, (task / 'vasp.stderr').open('w') as err:
                    code = subprocess.run([mpi, '-np', str(args.ranks), vasp], cwd=str(task), env=env,
                                          stdout=out, stderr=err, stdin=subprocess.DEVNULL).returncode
                ok = code == 0 and converged(task, since=started)
                record.update(exit_code=code, status='converged' if ok else 'incomplete')
                record_path.write_text(json.dumps(record, indent=2))
                print('[done] {}: exit_code={}, converged={}'.format(name, code, ok), flush=True)
                if not ok:
                    raise RuntimeError(name + ': inspect logs; remaining tasks not launched')
        finally:
            (root / 'RUNNING.lock').unlink()
        print('[finished] All three Zn tasks converged.', flush=True)


if __name__ == '__main__':
    main()
