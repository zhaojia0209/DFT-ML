"""Sequential CPU MACE NEB then CI-NEB on previously relaxed endpoints."""
import argparse
import csv
import hashlib
import json
from pathlib import Path


def save_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True, help='neb_initial directory')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--threads', type=int, default=16)
    p.add_argument('--pre-fmax', type=float, default=0.05)
    p.add_argument('--fmax', type=float, default=0.02)
    p.add_argument('--pre-steps', type=int, default=300)
    p.add_argument('--steps', type=int, default=800)
    p.add_argument('--spring', type=float, default=0.1)
    p.add_argument('--only', nargs='+', help='Optional task names')
    a = p.parse_args()
    if min(a.threads, a.pre_steps, a.steps) < 1 or not 0 < a.fmax <= a.pre_fmax < 1 or not 0 < a.spring < 10:
        p.error('Invalid numerical parameters')
    if a.output.exists():
        p.error('Output already exists; select a new directory to preserve previous work')
    files = sorted(a.input.glob('*/metadata.json'))
    if a.only:
        missing = set(a.only) - {f.parent.name for f in files}
        if missing:
            p.error('Unknown tasks: ' + ', '.join(sorted(missing)))
        files = [f for f in files if f.parent.name in a.only]
    if not files or not a.model.is_file():
        p.error('Missing input paths or model')
    # Require the exact endpoint model: other seeds need their own endpoint relaxation.
    model_hash = hashlib.sha256(a.model.read_bytes()).hexdigest()
    settings = a.input.parent/'settings.json'
    if not settings.is_file() or json.loads(settings.read_text()).get('model_sha256') != model_hash:
        p.error('Endpoint model hash does not match, or endpoint settings.json is missing')
    import numpy as np
    import torch
    from ase.io import read, write
    from ase.mep import NEB
    from ase.optimize import FIRE
    from mace.calculators import MACECalculator
    torch.set_num_threads(a.threads)
    torch.set_num_interop_threads(1)
    calc = MACECalculator(model_paths=str(a.model.resolve()), device='cpu', default_dtype='float64')
    a.output.mkdir(parents=True)
    params = {k: str(v) if isinstance(v, Path) else v for k, v in vars(a).items()}
    params.update(model_sha256=model_hash, method='improvedtangent', maxstep_A=0.05,
                  parallel_images=False, endpoint_fixed=True, cell_fixed=True)
    (a.output/'settings.json').write_text(json.dumps(params, indent=2))
    rows = []
    for file in files:
        meta = json.loads(file.read_text())
        task = file.parent.name
        out = a.output/'tasks'/task
        out.mkdir(parents=True)
        row = dict(task=task, initial_energy_ev='', final_energy_ev='', delta_energy_ev='',
                   forward_barrier_ev='', reverse_barrier_ev='', max_image='',
                   pre_neb_fmax_ev_A='', ci_neb_fmax_ev_A='', min_pair_distance_A='',
                   status='failed', error='')
        images = []
        try:
            last = int(meta['intermediate_images']) + 1
            images = [read(str(file.parent/f'{i:02d}'/'POSCAR')) for i in range(last+1)]
            for im in images:
                if not np.array_equal(im.numbers, images[0].numbers) or not np.allclose(im.cell, images[0].cell):
                    raise ValueError('Inconsistent atom ordering/species or cell')
                im.calc = calc
            for im in (images[0], images[-1]):
                if np.linalg.norm(im.get_forces(), axis=1).max() > 0.011:
                    raise ValueError('Endpoint no longer satisfies previous 0.01 eV/A force tolerance')
            # Coordinates from the previous stage are already consistently interpolated.
            neb = NEB(images, k=a.spring, climb=False, method='improvedtangent',
                      parallel=False, allow_shared_calculator=True)
            print('[run]', task, 'ordinary NEB', flush=True)
            with FIRE(neb, logfile=str(out/'pre.log'), trajectory=str(out/'pre.traj'), maxstep=0.05) as opt:
                opt.run(fmax=a.pre_fmax, steps=a.pre_steps)
            pre_force = float(np.linalg.norm(neb.get_forces(), axis=1).max())
            row['pre_neb_fmax_ev_A'] = pre_force
            if not np.isfinite(pre_force) or pre_force > a.pre_fmax:
                raise ValueError('Ordinary NEB not converged; CI stage not started; inspect pre.log/pre.traj')
            neb.climb = True
            print('[run]', task, 'climbing-image NEB', flush=True)
            with FIRE(neb, logfile=str(out/'ci.log'), trajectory=str(out/'ci.traj'), maxstep=0.05) as opt:
                opt.run(fmax=a.fmax, steps=a.steps)
            force = float(np.linalg.norm(neb.get_forces(), axis=1).max())
            energies = np.array([im.get_potential_energy() for im in images])
            saddle = int(energies.argmax())
            minsep = float('inf')
            for im in images:
                distances = im.get_all_distances(mic=True)
                np.fill_diagonal(distances, np.inf)
                minsep = min(minsep, float(distances.min()))
            valid = bool(np.isfinite(energies).all() and np.isfinite(force) and force <= a.fmax
                         and 0 < saddle < last and minsep > 1.5)
            row.update(initial_energy_ev=float(energies[0]), final_energy_ev=float(energies[-1]),
                       delta_energy_ev=float(energies[-1]-energies[0]),
                       forward_barrier_ev=float(energies[saddle]-energies[0]),
                       reverse_barrier_ev=float(energies[saddle]-energies[-1]), max_image=saddle,
                       ci_neb_fmax_ev_A=force, min_pair_distance_A=minsep,
                       status='converged_screen' if valid else 'check')
            save_csv(out/'profile.csv', [dict(image=i, energy_ev=float(e),
                relative_energy_ev=float(e-energies[0])) for i, e in enumerate(energies)])
        except Exception as exc:
            row['error'] = repr(exc)
        # Preserve last geometries even for paths that did not converge.
        for i, im in enumerate(images):
            dest = out/f'{i:02d}'
            dest.mkdir(exist_ok=True)
            write(str(dest/'POSCAR'), im, format='vasp', direct=True, sort=False)
        (out/'metadata.json').write_text(json.dumps(meta, indent=2))
        (out/'summary.json').write_text(json.dumps(row, indent=2))
        rows.append(row)
        save_csv(a.output/'neb_summary.csv', rows)
        print('[%s] %s forward=%s reverse=%s' % (row['status'],task,
              row['forward_barrier_ev'],row['reverse_barrier_ev']), flush=True)
    print('Summary:', a.output/'neb_summary.csv', flush=True)
    if any(r['status'] != 'converged_screen' for r in rows):
        raise SystemExit('One or more paths require inspection; see neb_summary.csv')


if __name__ == '__main__':
    main()
