#!/usr/bin/env python3
"""Prepare the active-learning v5 split while keeping v4 holdouts frozen."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

from ase.io import read, write

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from alznmgcu_v.dataset import _structure_digest
from alznmgcu_v.mace_workflow import _normalize_reference_keys


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_frames(path: Path):
    if not path.is_file():
        raise FileNotFoundError(path)
    frames = list(read(str(path), index=":"))
    if not frames:
        raise ValueError(f"No frames found in {path}")
    return [_normalize_reference_keys(atoms, i) for i, atoms in enumerate(frames)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-dir", default="work/neb_retrain_v4/02_mace",
        help="directory containing the frozen v4 train/valid/test extxyz files",
    )
    parser.add_argument(
        "--labels", default="work/active_learning_v1/dataset_active_learning_v1.extxyz",
    )
    parser.add_argument(
        "--output-dir", default="work/active_learning_v1/02_mace_v5",
    )
    parser.add_argument("--expected-labels", type=int, default=60)
    args = parser.parse_args()

    base_dir = Path(args.base_dir)
    labels_path = Path(args.labels)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    train = load_frames(base_dir / "train.extxyz")
    valid = load_frames(base_dir / "valid.extxyz")
    test = load_frames(base_dir / "test.extxyz")
    labels = load_frames(labels_path)
    if len(labels) != args.expected_labels:
        raise ValueError(
            f"Expected {args.expected_labels} active-learning labels, found {len(labels)}"
        )

    train_hashes = {_structure_digest(atoms) for atoms in train}
    valid_hashes = {_structure_digest(atoms) for atoms in valid}
    test_hashes = {_structure_digest(atoms) for atoms in test}
    if train_hashes & (valid_hashes | test_hashes) or valid_hashes & test_hashes:
        raise ValueError("The frozen v4 splits already contain exact structural leakage")

    accepted = []
    duplicates = 0
    for atoms in labels:
        structure_hash = _structure_digest(atoms)
        if structure_hash in valid_hashes or structure_hash in test_hashes:
            raise ValueError(
                "An adaptively selected label duplicates a frozen validation/test structure"
            )
        if structure_hash in train_hashes:
            duplicates += 1
            continue
        train_hashes.add(structure_hash)
        atoms.info["split"] = "train"
        atoms.info["excluded_from_validation"] = True
        atoms.info["active_learning_round"] = 1
        accepted.append(atoms)

    if not accepted:
        raise ValueError("No new active-learning labels remained after deduplication")

    outputs = {
        "train": output_dir / "train.extxyz",
        "valid": output_dir / "valid.extxyz",
        "test": output_dir / "test.extxyz",
    }
    write(outputs["train"], train + accepted, format="extxyz", write_results=False)
    write(outputs["valid"], valid, format="extxyz", write_results=False)
    write(outputs["test"], test, format="extxyz", write_results=False)

    report = {
        "policy": "freeze_v4_valid_test_append_active_labels_to_train_only",
        "base_dir": str(base_dir.resolve()),
        "labels": str(labels_path.resolve()),
        "input_counts": {
            "train": len(train), "valid": len(valid), "test": len(test),
            "active_labels": len(labels),
        },
        "active_labels_added": len(accepted),
        "active_label_duplicates_removed": duplicates,
        "output_counts": {
            "train": len(train) + len(accepted), "valid": len(valid), "test": len(test),
        },
        "active_config_types": dict(Counter(str(a.info.get("config_type", "")) for a in accepted)),
        "exact_structure_leakage": False,
        "outputs_sha256": {name: file_sha256(path) for name, path in outputs.items()},
    }
    report_path = output_dir / "preparation_report.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(report_path)
    print(json.dumps(report["output_counts"], indent=2))


if __name__ == "__main__":
    main()
