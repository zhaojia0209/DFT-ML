from _bootstrap import run

run(["active-pool"])
