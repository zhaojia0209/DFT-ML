#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PROJECT_ROOT="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

OUT="work/ensemble_validation_v4"
NEB_STAGE="work/neb_workstation/04_neb_dense_singlepoints"
VAL_STAGE="work/refined/03_validation"
mkdir -p "$OUT"

labels=(seed11 seed29 seed47)
models=(
  "work/final_models/alzmcv_neb_v4_epoch145_candidate.model"
  "work/neb_retrain_v4/02_mace/ensemble_seed29/checkpoints/alzmcv_neb_v4_seed29_run-29_stagetwo.model"
  "work/neb_retrain_v4/02_mace/ensemble_seed47/checkpoints/alzmcv_neb_v4_seed47_run-47_stagetwo.model"
)

for i in "${!labels[@]}"; do
  label="${labels[$i]}"
  model="${models[$i]}"
  if [[ ! -s "$model" ]]; then
    echo "[failed] missing $label model: $model" >&2
    exit 1
  fi
  echo "[run] $label NEB validation"
  python3 scripts/17_evaluate_neb_mace.py \
    --config configs/neb_workstation.yaml --model "$model" --device cpu
  cp "$NEB_STAGE/neb_mace_vs_dft.csv" "$OUT/neb_mace_vs_dft_${label}.csv"
  cp "$NEB_STAGE/neb_mace_paths.csv" "$OUT/neb_mace_paths_${label}.csv"

  echo "[run] $label physical-property validation"
  python3 scripts/05_validate.py --config configs/refined.yaml evaluate \
    --engine mace --model "$model" --device cpu
  cp "$VAL_STAGE/validation_mace.csv" "$OUT/validation_mace_${label}.csv"
  cp "$VAL_STAGE/validation_mace_raw.csv" "$OUT/validation_mace_raw_${label}.csv"
  python3 scripts/05_validate.py --config configs/refined.yaml summarize \
    --reference "$VAL_STAGE/validation_dft.csv" \
    --prediction "$OUT/validation_mace_${label}.csv"
  cp "$VAL_STAGE/validation_summary.csv" "$OUT/validation_summary_${label}.csv"
  echo "[done] $label"
done

python3 - "$OUT" <<'PY'
import csv
import sys
from pathlib import Path

root = Path(sys.argv[1])
rows = []
for label in ("seed11", "seed29", "seed47"):
    with (root / f"neb_mace_vs_dft_{label}.csv").open(newline="") as handle:
        neb = list(csv.DictReader(handle))
    with (root / f"validation_summary_{label}.csv").open(newline="") as handle:
        physical = {row["family"]: row for row in csv.DictReader(handle)}
    max_barrier = max(float(row["abs_barrier_error_ev"]) for row in neb)
    max_path = max(float(row["path_max_abs_error_ev"]) for row in neb)
    saddle_ok = all(row["dft_max_image"] == row["mace_max_image"] for row in neb)
    barrier_ok = max_barrier <= 0.08 and saddle_ok
    binding = float(physical["binding"]["rmse"])
    substitution = float(physical["substitution_delta"]["rmse"])
    vacancy = float(physical["vacancy"]["max_abs"])
    property_ok = binding <= 0.05 and substitution <= 0.05 and vacancy <= 0.10
    rows.append({
        "model": label,
        "max_abs_barrier_error_ev": max_barrier,
        "max_path_abs_error_ev": max_path,
        "all_saddles_correct": saddle_ok,
        "binding_rmse_ev": binding,
        "substitution_rmse_ev": substitution,
        "vacancy_error_ev": vacancy,
        "neb_status": "pass" if barrier_ok else "check",
        "property_status": "pass" if property_ok else "check",
        "overall_status": "pass" if barrier_ok and property_ok else "check",
    })

output = root / "ensemble_gate.csv"
with output.open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
print(output)
PY

echo "[done] ensemble validation complete"
cat "$OUT/ensemble_gate.csv"
