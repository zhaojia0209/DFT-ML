#!/usr/bin/env python3
"""Prepare v6 by reweighting existing vacancy-energy anchors in v5 train only."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from collections import Counter
from pathlib import Path

from ase.io import read, write

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from alznmgcu_v.mace_workflow import _normalize_reference_keys


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", default="work/active_learning_v1/02_mace_v5")
    parser.add_argument("--output-dir", default="work/vacancy_reweight_v6/02_mace")
    parser.add_argument("--pair-energy-weight", type=float, default=10.0)
    parser.add_argument("--calibration-vacancy-energy-weight", type=float, default=5.0)
    args = parser.parse_args()

    if args.pair_energy_weight <= 1.0 or args.calibration_vacancy_energy_weight <= 1.0:
        raise ValueError("Targeted vacancy energy weights must be greater than 1")

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    train_path = input_dir / "train.extxyz"
    valid_path = input_dir / "valid.extxyz"
    test_path = input_dir / "test.extxyz"
    for path in (train_path, valid_path, test_path):
        if not path.is_file():
            raise FileNotFoundError(path)

    frames = list(read(str(train_path), index=":"))
    if not frames:
        raise ValueError(f"No frames found in {train_path}")
    frames = [_normalize_reference_keys(atoms, i) for i, atoms in enumerate(frames)]

    target_counts = Counter()
    previous_weights = Counter()
    for atoms in frames:
        config_type = str(atoms.info.get("config_type", "Default"))
        if config_type in {"VacancyPairBulk", "VacancyPairDefect"}:
            target_counts[config_type] += 1
            previous_weights[str(atoms.info.get("config_energy_weight", "missing"))] += 1
            atoms.info["config_energy_weight"] = float(args.pair_energy_weight)
            atoms.info["vacancy_reweight_round"] = 1
        elif config_type == "CalibrationVacancy":
            target_counts[config_type] += 1
            previous_weights[str(atoms.info.get("config_energy_weight", "missing"))] += 1
            atoms.info["config_energy_weight"] = float(
                args.calibration_vacancy_energy_weight
            )
            atoms.info["vacancy_reweight_round"] = 1

    required = ("VacancyPairBulk", "VacancyPairDefect", "CalibrationVacancy")
    missing_types = [name for name in required if target_counts[name] == 0]
    if missing_types:
        raise ValueError(f"Training set lacks required vacancy anchors: {missing_types}")
    if target_counts["VacancyPairBulk"] != target_counts["VacancyPairDefect"]:
        raise ValueError("Bulk and defect vacancy-pair counts are not equal")

    output_dir.mkdir(parents=True, exist_ok=True)
    output_train = output_dir / "train.extxyz"
    output_valid = output_dir / "valid.extxyz"
    output_test = output_dir / "test.extxyz"
    write(output_train, frames, format="extxyz", write_results=False)
    # Holdouts remain byte-for-byte identical to v5 for a fair comparison.
    shutil.copy2(valid_path, output_valid)
    shutil.copy2(test_path, output_test)

    report = {
        "policy": "reweight_existing_vacancy_anchors_train_only",
        "input_dir": str(input_dir.resolve()),
        "output_dir": str(output_dir.resolve()),
        "train_frames": len(frames),
        "target_counts": dict(target_counts),
        "previous_target_energy_weights": dict(previous_weights),
        "new_energy_weights": {
            "VacancyPairBulk": args.pair_energy_weight,
            "VacancyPairDefect": args.pair_energy_weight,
            "CalibrationVacancy": args.calibration_vacancy_energy_weight,
        },
        "new_dft_frames": 0,
        "valid_unchanged": sha256(valid_path) == sha256(output_valid),
        "test_unchanged": sha256(test_path) == sha256(output_test),
        "output_sha256": {
            "train": sha256(output_train),
            "valid": sha256(output_valid),
            "test": sha256(output_test),
        },
    }
    report_path = output_dir / "reweight_report.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(report_path)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
