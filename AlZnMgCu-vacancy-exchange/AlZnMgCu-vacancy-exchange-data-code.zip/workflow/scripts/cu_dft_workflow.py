"""Cu-environment DFT verification. ASE/numpy required; no project imports."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

TASKS = [e+'_'+c for e in ('Mg','Zn') for c in ('no_cu','far_cu','common_neighbor')]
POTS = {'Al':'Al','Zn':'Zn','Mg':'Mg_pv','Cu':'Cu_pv'}
ROOT = Path('work/cu_environment_dft_v1')


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding='utf-8')


def table(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def incar(path):
    values = {}
    for line in path.read_text().splitlines():
        for part in re.split('[#!]',line)[0].split(';'):
            if '=' in part:
                key, value = part.split('=',1)
                values[key.strip().upper()] = value.strip()
    return values


def fresh(path):
    if path.exists():
        raise ValueError('Refusing to overwrite existing directory: '+str(path))
    path.mkdir(parents=True)


def signature(path):
    h = hashlib.sha256()
    files = sorted(path.rglob('POSCAR')) + [path/'INCAR',path/'KPOINTS',path/'POTCAR']
    files += [path/i/'OUTCAR' for i in ('00','06') if (path/i/'OUTCAR').is_file()]
    for f in files:
        h.update(str(f.relative_to(path)).encode()); h.update(f.read_bytes())
    return h.hexdigest()


def write_inputs(dest, atoms, cfg, stage):
    from ase.io import write
    dest.mkdir(parents=True, exist_ok=True)
    write(str(dest/'POSCAR'), atoms, format='vasp', direct=True, sort=False)
    values = dict(cfg['electronic_incar'])
    values.update(ISTART='0', ICHARG='2', LWAVE='.FALSE.', LCHARG='.FALSE.',
                  ISIF='2', NCORE='2', KPAR='1')
    if stage == 'endpoints':
        values.update(IBRION='2', NSW='300', EDIFFG='-0.01', POTIM='0.2')
    elif stage == 'neb':
        # Ordinary NEB supported by stock VASP; no unverified VTST tags.
        values.update(IBRION='3', NSW='500', EDIFFG='-0.03', POTIM='0.1',
                      SMASS='2', IMAGES='5', SPRING='-5')
    else:
        values.update(IBRION='-1', NSW='0')
    (dest/'INCAR').write_text('\n'.join(k+' = '+str(v) for k,v in values.items())+'\n')
    (dest/'KPOINTS').write_text(cfg['kpoints'])
    species = (dest/'POSCAR').read_text().splitlines()[5].split()
    with (dest/'POTCAR').open('wb') as f:
        for element in species:
            pot = Path(cfg['potcar_root'])/POTS[element]/'POTCAR'
            data = pot.read_bytes()
            if hashlib.sha256(data).hexdigest() != cfg['potcar_hashes'][element]:
                raise ValueError('POTCAR changed since campaign generation: '+str(pot))
            f.write(data)
            if not data.endswith(b'\n'): f.write(b'\n')


def load_result(path, relaxed=False):
    import numpy as np
    from ase.io import read
    import xml.etree.ElementTree as ET
    out = (path/'OUTCAR').read_text(errors='replace')
    if 'General timing and accounting' not in out:
        raise ValueError('No normal VASP termination: '+str(path))
    if 'aborting loop because EDIFF is reached' not in out:
        raise ValueError('No electronic convergence marker: '+str(path))
    tree = ET.parse(path/'vasprun.xml')
    calculations = tree.findall('.//calculation')
    if not calculations: raise ValueError('No electronic calculations')
    nelm = tree.find(".//parameters//i[@name='NELM']")
    if nelm is None or len(calculations[-1].findall('scstep')) >= int(nelm.text):
        raise ValueError('Final SCF reached NELM or NELM unavailable; inspect manually')
    frame = read(str(path/'vasprun.xml'), index=-1)
    e0 = float(frame.get_potential_energy())
    free = float(frame.get_potential_energy(force_consistent=True))
    forces = frame.get_forces()
    if not np.isfinite([e0,free]).all() or not np.isfinite(forces).all():
        raise ValueError('Nonfinite energy/forces')
    fmax = float(np.linalg.norm(forces,axis=1).max())
    if relaxed and ('reached required accuracy' not in out or fmax > 0.011):
        raise ValueError('Endpoint force convergence not satisfied: '+str(path))
    return frame, e0, free, fmax


def verify_basin(original, final):
    import numpy as np
    # The generator uses a cubic FCC cell; recover its missing site.
    if not np.array_equal(original.numbers,final.numbers) or not np.allclose(original.cell,final.cell):
        raise ValueError('Endpoint species/order or cell changed')
    length = float(original.cell[0,0]); count = len(original)+1
    n = round((count/4)**(1/3)); a0 = length/n
    if 4*n**3 != count: raise ValueError('Not the expected FCC single-vacancy cell')
    sites = np.array([(i+x,j+y,k+z) for i in range(n) for j in range(n) for k in range(n)
                      for x,y,z in ((0,0,0),(0,.5,.5),(.5,0,.5),(.5,.5,0))])*a0
    def assigned(pos):
        d = pos[:,None,:]-sites[None,:,:]; d -= length*np.rint(d/length)
        norms = np.linalg.norm(d,axis=2)
        return norms.argmin(axis=1), norms.min(axis=1).max()
    start_ids,_ = assigned(original.positions)
    diff = final.positions-original.positions; diff -= length*np.rint(diff/length)
    shift = np.median(diff,axis=0)
    end_ids, maximum = assigned(final.positions-shift)
    if len(set(start_ids)) != len(original) or not np.array_equal(start_ids,end_ids) or maximum > .9:
        raise ValueError('Endpoint basin/site identity changed or ambiguous')
    aligned = final.copy(); aligned.positions -= shift
    return aligned


def generate(a):
    from ase.io import read, write
    base = a.root
    if a.stage == 'sp':
        if not a.reference: raise ValueError('--reference is required for first generation')
        ref = a.reference
        for f in ('INCAR','KPOINTS','POSCAR','POTCAR'):
            if not (ref/f).is_file(): raise FileNotFoundError(ref/f)
        values = incar(ref/'INCAR')
        if any(k.startswith(('ML_','LDAU')) for k in values):
            raise ValueError('Unexpected ML/DFT+U reference; review manually')
        for k in ('ENCUT','EDIFF','ISMEAR','SIGMA'):
            if k not in values: raise ValueError('Missing reference parameter '+k)
        if values.get('ISPIN','1') != '1' or 'NELECT' in values:
            raise ValueError('Reference is spin-polarized/charged; review manually')
        # Remove only geometry/dynamics, restart and parallelism tags; retain electronic settings.
        remove = {'IBRION','NSW','EDIFFG','POTIM','SMASS','IMAGES','SPRING','LCLIMB','IOPT',
                  'ICHAIN','NFREE','ISIF','ISTART','ICHARG','LWAVE','LCHARG','KSPACING','KGAMMA',
                  'NCORE','NPAR','KPAR','NWRITE'}
        values = {k:v for k,v in values.items() if k not in remove}
        kpoints = (ref/'KPOINTS').read_text()
        if int(kpoints.splitlines()[1].strip()) != 0 or not kpoints.splitlines()[2].lower().startswith(('g','m')):
            raise ValueError('Expected automatic Gamma/Monkhorst KPOINTS mesh')
        hashes = {e:hashlib.sha256((a.potcar_root/pot/'POTCAR').read_bytes()).hexdigest() for e,pot in POTS.items()}
        # Verify shared species against actual reference POTCAR, not just its directory name.
        ref_species = (ref/'POSCAR').read_text().splitlines()[5].split()
        combined = b''
        for e in ref_species:
            b = (a.potcar_root/POTS[e]/'POTCAR').read_bytes(); combined += b if b.endswith(b'\n') else b+b'\n'
        if combined.strip() != (ref/'POTCAR').read_bytes().strip():
            raise ValueError('POTCAR does not match reference. Resolve before new calculations.')
        cfg = dict(reference=str(ref.resolve()),electronic_incar=values,kpoints=kpoints,
                   potcar_root=str(a.potcar_root.resolve()),potcar_hashes=hashes,
                   mace_root=str(a.mace_root.resolve()), tasks=TASKS, energy_convention='sigma->0 eV')
        # Preflight every source and cell against reference.
        ref_atoms = read(str(ref/'POSCAR'))
        import numpy as np
        for t in TASKS:
            for i in range(7):
                atoms = read(str(a.mace_root/'tasks'/t/f'{i:02d}'/'POSCAR'))
                if not np.allclose(atoms.cell,ref_atoms.cell,atol=1e-5,rtol=0):
                    raise ValueError('Cell differs from old DFT reference; resolve a0 first: '+t)
        fresh(base)
        dump(base/'campaign.json',cfg)
    else:
        cfg = json.loads((base/'campaign.json').read_text())
    dest = base/a.stage
    prepared = []
    source = Path(cfg['mace_root'])
    if a.stage in ('sp','endpoints'):
        for t in cfg['tasks']:
            for i in (range(7) if a.stage=='sp' else (0,6)):
                prepared.append((t,i,read(str(source/'tasks'/t/f'{i:02d}'/'POSCAR'))))
    elif a.stage == 'final-sp':
        for t in cfg['tasks']:
            neb = base/'neb'/'tasks'/t
            for i in range(7):
                if i in (0,6):
                    atoms = read(str(neb/f'{i:02d}'/'POSCAR'))
                else:
                    text = (neb/f'{i:02d}'/'OUTCAR').read_text(errors='replace')
                    if 'reached required accuracy' not in text:
                        raise ValueError('NEB image lacks convergence marker: '+str(neb/f'{i:02d}'))
                    atoms = read(str(neb/f'{i:02d}'/'CONTCAR'))
                prepared.append((t,i,atoms))
    elif a.stage == 'neb':
        import numpy as np
        for t in cfg['tasks']:
            ends = []
            for i in (0,6):
                ep = base/'endpoints'/'tasks'/f'{t}__{i:02d}'
                frame,_,_,_ = load_result(ep,relaxed=True)
                ends.append(verify_basin(read(str(ep/'POSCAR')),frame))
            start,end = ends; length = float(start.cell[0,0])
            # Retain MACE path curvature, smoothly correct it to DFT endpoints.
            band = [read(str(source/'tasks'/t/f'{i:02d}'/'POSCAR')) for i in range(7)]
            d0 = start.positions-band[0].positions; d0 -= length*np.rint(d0/length)
            d1 = end.positions-band[-1].positions; d1 -= length*np.rint(d1/length)
            for i,frame in enumerate(band):
                frame.positions += (1-i/6)*d0+(i/6)*d1
                distance = frame.get_all_distances(mic=True); np.fill_diagonal(distance,np.inf)
                if distance.min()<1.5: raise ValueError('Overlapping NEB guess: '+t)
                prepared.append((t,i,frame))
    fresh(dest)
    manifest = []
    for t,i,atoms in prepared:
        if a.stage == 'neb':
            directory = dest/'tasks'/t
            if i == 0:
                write_inputs(directory,atoms,cfg,'neb')
                manifest.append(dict(task=t,path=str(directory.resolve())))
            sub = directory/f'{i:02d}'; sub.mkdir()
            write(str(sub/'POSCAR'),atoms,format='vasp',direct=True,sort=False)
            if i in (0,6):
                shutil.copyfile(base/'endpoints'/'tasks'/f'{t}__{i:02d}'/'OUTCAR',sub/'OUTCAR')
        else:
            directory = dest/'tasks'/f'{t}__{i:02d}'
            write_inputs(directory,atoms,cfg,a.stage)
            dump(directory/'metadata.json',dict(task=t,image=i))
            manifest.append(dict(task=t,image=i,path=str(directory.resolve())))
    dump(dest/'manifest.json',manifest)
    print('Generated',len(manifest),'tasks:',dest)
    print('Electronic settings:',cfg['electronic_incar']); print('KPOINTS:\n'+cfg['kpoints'])


def run(a):
    stage = a.root/a.stage
    manifest = json.loads((stage/'manifest.json').read_text())
    ranks = a.ranks
    if ranks < 1 or ranks%2 or (a.stage=='neb' and (ranks%5 or (ranks//5)%2)):
        raise ValueError('NCORE=2: ranks must be even; NEB ranks must be a multiple of 10')
    env = os.environ.copy()
    env.pop('LD_PRELOAD',None)
    env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    mpi = Path('/opt/intel/oneapi/mpi/2021.12/bin/mpirun')
    vasp = Path('/home/zhaojia/vasp.6.4.2/bin/vasp_std')
    if not mpi.is_file() or not vasp.is_file(): raise FileNotFoundError('Intel MPI or vasp_std missing')
    # Exclude standalone LibTorch paths implicated in earlier crashes, retain Intel runtime.
    libs = [x for x in env.get('LD_LIBRARY_PATH','').split(':') if x and 'libtorch' not in x.lower()]
    env['LD_LIBRARY_PATH'] = '/opt/intel/oneapi/mpi/2021.12/lib:'+':'.join(libs)
    import resource
    stack_soft, stack_hard = resource.getrlimit(resource.RLIMIT_STACK)

    if stack_hard != resource.RLIM_INFINITY:
        raise RuntimeError(
            "Stack hard limit is finite; resolve it before running VASP"
        )

    resource.setrlimit(
        resource.RLIMIT_STACK,
        (resource.RLIM_INFINITY, stack_hard)
    )

    print(
        "[runtime] stack=unlimited; MPI ranks=" + str(ranks),
        flush=True
    )
    lock = stage/'RUNNING.lock'
    with lock.open('x') as f: f.write(str(os.getpid()))
    reports=[]
    try:
        for item in manifest:
            path=Path(item['path']); sig=signature(path)
            record=path/'execution.json'
            if record.exists():
                old=json.loads(record.read_text())
                if old.get('exit_code')==0 and old.get('input_sha256')==sig:
                    print('[skip]',path.name,flush=True); continue
                raise ValueError('Previous execution exists: preserve and inspect '+str(path))
            if (path/'OUTCAR').exists() or (path/'vasp.stdout').exists():
                raise ValueError('Prior outputs without matching execution record: '+str(path))
            print('[run]',path.name,flush=True)
            with (path/'vasp.stdout').open('w') as out, (path/'vasp.stderr').open('w') as err:
                code=subprocess.run([str(mpi),'-np',str(ranks),str(vasp)],cwd=path,env=env,
                                    stdout=out,stderr=err,stdin=subprocess.DEVNULL).returncode
            report=dict(task=path.name,exit_code=code,input_sha256=sig)
            dump(record,report); reports.append(report); table(stage/'run_summary.csv',reports)
            if code: raise RuntimeError('VASP failed; remaining tasks not launched: '+str(path))
    finally:
        lock.unlink()
    print('Execution finished. Collect must still verify convergence.')


def collect(a):
    from ase.io import read
    cfg=json.loads((a.root/'campaign.json').read_text()); stage=a.root/a.stage
    rows=[]; failed=[]
    for item in json.loads((stage/'manifest.json').read_text()):
        path=Path(item['path'])
        try:
            frame,e0,free,fmax=load_result(path,relaxed=a.stage=='endpoints')
            if a.stage=='endpoints': verify_basin(read(str(path/'POSCAR')),frame)
            rows.append(dict(task=item['task'],image=item['image'],energy_ev=e0,
                             free_energy_ev=free,fmax_ev_A=fmax))
        except Exception as exc: failed.append(dict(path=str(path),error=repr(exc)))
    if failed:
        table(stage/'failures.csv',failed)
        raise ValueError('Incomplete/unconverged results; see '+str(stage/'failures.csv'))
    if (stage/'energies.csv').exists(): raise ValueError('Report exists; preserve it before recollecting')
    table(stage/'energies.csv',rows)
    if a.stage=='endpoints':
        print('All 12 endpoints passed force and basin checks.'); return
    barriers=[]
    for task in cfg['tasks']:
        r=sorted([x for x in rows if x['task']==task],key=lambda x:x['image'])
        if len(r)!=7: raise ValueError('Need 7 complete images')
        peak=max(r,key=lambda x:x['energy_ev']); fwd=peak['energy_ev']-r[0]['energy_ev']
        rev=peak['energy_ev']-r[-1]['energy_ev']
        barriers.append(dict(task=task,forward_barrier_ev=fwd,reverse_barrier_ev=rev,
            delta_energy_ev=r[-1]['energy_ev']-r[0]['energy_ev'],max_image=peak['image'],
            kind='DFT_on_MACE_path' if a.stage=='sp' else 'ordinary_DFT_NEB_rescored',
            status='interior_maximum' if 0<peak['image']<6 else 'check_endpoint_maximum'))
    table(stage/'barriers.csv',barriers)
    if a.stage == 'sp':
        with (Path(cfg['mace_root'])/'neb_summary.csv').open(newline='') as f:
            mace = {r['task']:r for r in csv.DictReader(f)}
        comparisons=[]
        for r in barriers:
            predicted=float(mace[r['task']]['forward_barrier_ev'])
            comparisons.append(dict(task=r['task'],dft_on_mace_path_barrier_ev=r['forward_barrier_ev'],
                mace_barrier_ev=predicted,mace_minus_dft_barrier_ev=predicted-r['forward_barrier_ev']))
        table(stage/'mace_vs_dft.csv',comparisons)
    contrasts=[]
    for e in ('Mg','Zn'):
        by={r['task']:r for r in barriers}
        for control in ('no_cu','far_cu'):
            contrasts.append(dict(element=e,control=control,
                common_minus_control_barrier_ev=by[e+'_common_neighbor']['forward_barrier_ev']-by[e+'_'+control]['forward_barrier_ev']))
    table(stage/'contrasts.csv',contrasts)
    print('Reports:',stage/'barriers.csv',stage/'contrasts.csv')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['generate','run','collect'])
    p.add_argument('stage',choices=['sp','endpoints','neb','final-sp'])
    p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--reference',type=Path)
    p.add_argument('--mace-root',type=Path,default=Path('work/cu_environment_v1/03_neb_seed11'))
    p.add_argument('--potcar-root',type=Path,default=Path('/home/zhaojia/vasp.6.4.2/POTCAR_PBE'))
    p.add_argument('--ranks',type=int,default=40)
    a=p.parse_args()
    if a.command=='collect' and a.stage=='neb': p.error('Use generate final-sp after NEB, then collect final-sp')
    {'generate':generate,'run':run,'collect':collect}[a.command](a)


if __name__=='__main__':
    main()
