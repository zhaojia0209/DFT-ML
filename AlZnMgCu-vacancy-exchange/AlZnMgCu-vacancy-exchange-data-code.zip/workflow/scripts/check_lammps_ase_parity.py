"""Compare a trusted MACE model in ASE and ML-MACE LAMMPS, without MD."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    p = argparse.ArgumentParser(description=__doc__)
    root = Path('/home/zhaojia/AlZnMgCuV1')
    p.add_argument('--data', type=Path, default=root / 'work/pilot/05_md/runs/pilot_cu10_v1_T500_r1/structure.data')
    p.add_argument('--model', type=Path, default=root / 'work/final_models/alzmcv_v6_seed11_final.model')
    p.add_argument('--exported', type=Path)
    p.add_argument('--lmp', type=Path, default=Path('/home/zhaojia/lammps-mace-cpu/install/bin/lmp'))
    p.add_argument('--mpi', type=Path, default=Path('/opt/intel/oneapi/mpi/2021.12/bin/mpirun'))
    p.add_argument('--libtorch', type=Path, default=Path('/home/zhaojia/libtorch-2.5.1-cpu/lib'))
    p.add_argument('--output-root', type=Path, default=root / 'work/lammps_ase_parity_v6')
    p.add_argument('--threads', type=int, default=48)
    p.add_argument('--stress', action='store_true', help='Also compare six configurational stress components')
    args = p.parse_args()
    if args.threads < 1:
        p.error('--threads must be positive')
    args.exported = args.exported or Path(str(args.model) + '-lammps.pt')
    for path in (args.data, args.model, args.exported, args.lmp, args.mpi):
        if not path.is_file():
            p.error('Missing file: ' + str(path))
    if not args.libtorch.is_dir():
        p.error('Missing LibTorch directory: ' + str(args.libtorch))

    # Re-exec before importing native modules to isolate pip Torch from LibTorch.
    if any(os.environ.get(k) for k in ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'PYTHONPATH', 'PYTHONHOME')):
        import sys
        clean = os.environ.copy()
        for k in ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'PYTHONPATH', 'PYTHONHOME'):
            clean.pop(k, None)
        os.execve(sys.executable, [sys.executable, '-u', *sys.argv], clean)

    import numpy as np
    import torch
    from ase.io import read
    from ase import units
    from mace.calculators import MACECalculator

    torch.set_num_threads(args.threads)
    args.output_root.mkdir(parents=True, exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix='check_', dir=args.output_root.resolve()))
    print('Output:', out, flush=True)
    shutil.copy2(args.data, out / 'structure.data')
    # Explicit type map matches the project's data writer; retain ID ordering.
    atoms = read(out / 'structure.data', format='lammps-data', atom_style='atomic',
                 Z_of_type={1: 13, 2: 30, 3: 12, 4: 29}, sort_by_id=True, units='metal')
    if not np.allclose(atoms.cell.array, np.diag(atoms.cell.lengths()), atol=1e-10):
        raise ValueError('This pilot checker requires an orthorhombic box')
    ids = np.asarray(atoms.arrays['id'], dtype=int)
    print('[run] ASE energy and forces', flush=True)
    atoms.calc = MACECalculator(model_paths=str(args.model.resolve()), device='cpu', default_dtype='float64')
    e_ase = float(atoms.get_potential_energy())
    f_ase = atoms.get_forces()
    stress_ase = atoms.get_stress(voigt=True, include_ideal_gas=False) / units.GPa if args.stress else None
    np.savez(out / 'ase_reference.npz', ids=ids, energy=e_ase, forces=f_ase)

    exported = str(args.exported.resolve())
    if any(c in exported for c in ('"', '\n', '$', '&')):
        raise ValueError('Model path contains unsupported LAMMPS input characters')
    inp = '''units metal
atom_style atomic
boundary p p p
atom_modify map yes
newton on
read_data structure.data
pair_style mace no_domain_decomposition
pair_coeff * * "MODEL_PATH" Al Zn Mg Cu
neighbor 2.0 bin
neigh_modify every 1 delay 0 check yes
thermo 1
thermo_style custom step atoms pe
thermo_modify norm no format float %.17g
run 0
print "$(pe:%.17g)" file energy.txt screen no
write_dump all custom forces.dump id type x y z fx fy fz modify sort id format float %.17g
'''.replace('MODEL_PATH', exported)
    if args.stress:
        inp = inp.replace('thermo 1\n', 'compute PARITY all pressure NULL virial\nthermo 1\n')
        inp = inp.replace('thermo_style custom step atoms pe',
                          'thermo_style custom step atoms pe c_PARITY[1] c_PARITY[2] c_PARITY[3] c_PARITY[4] c_PARITY[5] c_PARITY[6]')
        inp += 'print "$(c_PARITY[1]:%.17g) $(c_PARITY[2]:%.17g) $(c_PARITY[3]:%.17g) $(c_PARITY[4]:%.17g) $(c_PARITY[5]:%.17g) $(c_PARITY[6]:%.17g)" file pressure_bar.txt screen no\n'
    (out / 'in.parity').write_text(inp, encoding='utf-8')
    env = os.environ.copy()
    for k in ('I_MPI_PIN_DOMAIN', 'I_MPI_PIN_PROCESSOR_LIST', 'KMP_AFFINITY', 'GOMP_CPU_AFFINITY'):
        env.pop(k, None)
    env.update(I_MPI_PIN='0', OMP_PROC_BIND='false', OMP_NUM_THREADS=str(args.threads),
               MKL_NUM_THREADS=str(args.threads), OPENBLAS_NUM_THREADS='1')
    env['LD_LIBRARY_PATH'] = str(args.libtorch.resolve()) + ':' + str(args.mpi.resolve().parent.parent / 'lib')
    print('[run] LAMMPS run 0 (fixed coordinates)', flush=True)
    with (out / 'console.log').open('w', encoding='utf-8') as log:
        result = subprocess.run([str(args.mpi.resolve()), '-np', '1', str(args.lmp.resolve()),
                                 '-in', 'in.parity', '-log', 'log.lammps'],
                                cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError('LAMMPS failed; inspect ' + str(out / 'console.log'))
    e_lmp = float((out / 'energy.txt').read_text().strip())
    lines = (out / 'forces.dump').read_text().splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith('ITEM: ATOMS '))
    cols = lines[start].split()[2:]
    values = np.array([[float(v) for v in line.split()] for line in lines[start + 1:] if line.strip()])
    values = values[np.argsort(values[:, cols.index('id')])]
    if not np.array_equal(values[:, cols.index('id')], ids):
        raise ValueError('LAMMPS / ASE atom ID mismatch')
    types = values[:, cols.index('type')].astype(int)
    if not np.array_equal(np.array([0, 13, 30, 12, 29])[types], atoms.numbers):
        raise ValueError('LAMMPS / ASE element mismatch')
    xyz = values[:, [cols.index(k) for k in ('x', 'y', 'z')]]
    delta = xyz - atoms.positions
    delta -= np.rint(delta / atoms.cell.lengths()) * atoms.cell.lengths()
    if np.max(np.abs(delta)) > 1e-9:
        raise ValueError('Coordinates differ; comparison is invalid')
    f_lmp = values[:, [cols.index(k) for k in ('fx', 'fy', 'fz')]]
    if not all(np.isfinite(v).all() for v in (np.asarray([e_ase, e_lmp]), f_ase, f_lmp)):
        raise ValueError('Non-finite energy or forces')
    diff = f_lmp - f_ase
    # Engineering tolerances for float64 interface parity, NOT DFT accuracy gates.
    de = abs(e_lmp - e_ase) / len(atoms)
    maxf = float(np.max(np.abs(diff)))
    report = dict(n_atoms=len(atoms), ase_energy_ev=e_ase, lammps_energy_ev=e_lmp,
                  abs_energy_difference_ev_per_atom=de,
                  force_component_rmse_ev_per_angstrom=float(np.sqrt(np.mean(diff**2))),
                  max_force_component_error_ev_per_angstrom=maxf,
                  energy_tolerance_ev_per_atom=1e-6, force_component_tolerance_ev_per_angstrom=1e-5,
                  status='pass' if de <= 1e-6 and maxf <= 1e-5 else 'check',
                  model=str(args.model.resolve()), exported=str(args.exported.resolve()),
                  input_data=str(args.data.resolve()))
    if args.stress:
        pressure = np.loadtxt(out / 'pressure_bar.txt').reshape(6)
        # LAMMPS: xx yy zz xy xz yz, bar, compression positive.
        # ASE: xx yy zz yz xz xy, tensile stress positive, converted to GPa.
        stress_lmp = -pressure[[0, 1, 2, 5, 4, 3]] * 1e-4
        if not (np.isfinite(stress_ase).all() and np.isfinite(stress_lmp).all()):
            raise ValueError('Non-finite stress')
        stress_error = float(np.max(np.abs(stress_lmp - stress_ase)))
        stress_pass = stress_error <= 1e-5
        report.update(stress_order=['xx', 'yy', 'zz', 'yz', 'xz', 'xy'],
                      ase_stress_gpa=stress_ase.tolist(), lammps_stress_gpa=stress_lmp.tolist(),
                      lammps_virial_pressure_bar=pressure.tolist(),
                      stress_max_abs_error_gpa=stress_error, stress_tolerance_gpa=1e-5,
                      stress_status='pass' if stress_pass else 'check')
        if not stress_pass:
            report['status'] = 'check'
    (out / 'summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    np.savez(out / 'force_comparison.npz', ids=ids, ase=f_ase, lammps=f_lmp, difference=diff)
    print(json.dumps(report, indent=2), flush=True)
    print('Summary:', out / 'summary.json', flush=True)
    return 0 if report['status'] == 'pass' else 2


if __name__ == '__main__':
    raise SystemExit(main())
