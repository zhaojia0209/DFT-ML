#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PROJECT_ROOT="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

DATA_DIR="work/active_learning_v1/02_mace_v5"
TRAIN="$DATA_DIR/train.extxyz"
VALID="$DATA_DIR/valid.extxyz"
TEST="$DATA_DIR/test.extxyz"

for file in "$TRAIN" "$VALID" "$TEST"; do
    if [[ ! -s "$file" ]]; then
        echo "[failed] missing dataset: $file" >&2
        exit 1
    fi
done
if ! command -v mace_run_train >/dev/null 2>&1; then
    echo "[failed] mace_run_train is unavailable; activate .venv-mace-cpu first" >&2
    exit 1
fi

export OMP_NUM_THREADS="${OMP_NUM_THREADS:-48}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-48}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-48}"
export OMP_PROC_BIND="${OMP_PROC_BIND:-close}"
export OMP_PLACES="${OMP_PLACES:-cores}"

if (( $# > 0 )); then
    seeds=("$@")
else
    seeds=(11 29 47)
fi

for seed in "${seeds[@]}"; do
    [[ "$seed" =~ ^[0-9]+$ ]] || { echo "[failed] invalid seed: $seed" >&2; exit 1; }
    name="alzmcv_al_v1_seed${seed}"
    run_dir="$DATA_DIR/ensemble_seed${seed}"
    final_model="$run_dir/checkpoints/${name}_run-${seed}_stagetwo.model"
    mkdir -p "$run_dir"/{results,checkpoints,models,logs}
    if [[ -s "$final_model" && "${FORCE_RETRAIN:-0}" != "1" ]]; then
        echo "[skip] seed $seed already complete: $final_model"
        continue
    fi
    echo "[run] v5 seed $seed; log: $run_dir/console.log"
    mace_run_train \
        --name="$name" \
        --seed="$seed" \
        --train_file="$TRAIN" \
        --valid_file="$VALID" \
        --test_file="$TEST" \
        --config_type_weights='{"Default":1.0,"NEBCalibration":1.0,"ALNEBLabel":1.0,"ALRandomDefectLabel":1.0}' \
        --model=MACE \
        --r_max=6.0 \
        --num_channels=32 \
        --max_L=1 \
        --correlation=2 \
        --batch_size=2 \
        --valid_batch_size=4 \
        --max_num_epochs=150 \
        --energy_weight=1.0 \
        --forces_weight=100.0 \
        --stress_weight=10.0 \
        --loss=stress \
        --start_stage_two=100 \
        --swa_lr=0.001 \
        --ema \
        --ema_decay=0.99 \
        --amsgrad \
        --eval_interval=5 \
        --error_table=PerAtomRMSEstressvirials \
        --energy_key=REF_energy \
        --forces_key=REF_forces \
        --stress_key=REF_stress \
        --default_dtype=float64 \
        --device=cpu \
        --num_workers=0 \
        --save_cpu \
        --restart_latest \
        --results_dir="$run_dir/results" \
        --checkpoints_dir="$run_dir/checkpoints" \
        --model_dir="$run_dir/models" \
        --log_dir="$run_dir/logs" \
        2>&1 | tee "$run_dir/console.log"
    if [[ ! -s "$final_model" ]]; then
        echo "[failed] seed $seed ended without the Stage Two model" >&2
        exit 1
    fi
    echo "[done] seed $seed: $final_model"
done

echo "[done] v5 ensemble training complete"
