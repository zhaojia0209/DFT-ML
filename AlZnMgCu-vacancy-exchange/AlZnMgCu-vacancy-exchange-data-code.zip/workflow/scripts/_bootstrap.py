from __future__ import annotations

import sys
from pathlib import Path


def run(command: list[str]) -> None:
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "src"))
    from alznmgcu_v.cli import main

    main([*command, *sys.argv[1:]])

