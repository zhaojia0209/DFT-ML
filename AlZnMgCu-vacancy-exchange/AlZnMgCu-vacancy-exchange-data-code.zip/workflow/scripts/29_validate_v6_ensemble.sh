#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PROJECT_ROOT="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

OUT="work/ensemble_validation_v6"
NEB_STAGE="work/neb_workstation/04_neb_dense_singlepoints"
VAL_STAGE="work/refined/03_validation"
mkdir -p "$OUT"

labels=(seed11 seed29 seed47)
models=(
  "work/vacancy_reweight_v6/02_mace/seed11/checkpoints/alzmcv_vacweight_v6_seed11_run-11_stagetwo.model"
  "work/vacancy_reweight_v6/02_mace/seed29/checkpoints/alzmcv_vacweight_v6_seed29_run-29_stagetwo.model"
  "work/vacancy_reweight_v6/02_mace/seed47/checkpoints/alzmcv_vacweight_v6_seed47_run-47_stagetwo.model"
)

for i in "${!labels[@]}"; do
  label="${labels[$i]}"
  model="${models[$i]}"
  [[ -s "$model" ]] || { echo "[failed] missing $label model: $model" >&2; exit 1; }

  echo "[run] $label NEB validation"
  python3 scripts/17_evaluate_neb_mace.py \
    --config configs/neb_workstation.yaml --model "$model" --device cpu
  cp "$NEB_STAGE/neb_mace_vs_dft.csv" "$OUT/neb_mace_vs_dft_${label}.csv"
  cp "$NEB_STAGE/neb_mace_paths.csv" "$OUT/neb_mace_paths_${label}.csv"

  echo "[run] $label physical-property validation"
  python3 scripts/05_validate.py --config configs/refined.yaml evaluate \
    --engine mace --model "$model" --device cpu
  cp "$VAL_STAGE/validation_mace.csv" "$OUT/validation_mace_${label}.csv"
  cp "$VAL_STAGE/validation_mace_raw.csv" "$OUT/validation_mace_raw_${label}.csv"
  python3 scripts/05_validate.py --config configs/refined.yaml summarize \
    --reference "$VAL_STAGE/validation_dft.csv" \
    --prediction "$OUT/validation_mace_${label}.csv"
  cp "$VAL_STAGE/validation_summary.csv" "$OUT/validation_summary_${label}.csv"
  echo "[done] $label"
done

python3 - "$OUT" "$VAL_STAGE/validation_dft.csv" <<'PY'
import csv
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
reference_path = Path(sys.argv[2])
labels = ("seed11", "seed29", "seed47")

with reference_path.open(newline="") as handle:
    reference = {row["id"]: row for row in csv.DictReader(handle)}
dft_vacancy = float(reference["vacancy_formation"]["value_ev"])

neb_by_model = {}
summary_by_model = {}
prediction_by_model = {}
for label in labels:
    with (root / f"neb_mace_vs_dft_{label}.csv").open(newline="") as handle:
        neb_by_model[label] = list(csv.DictReader(handle))
    with (root / f"validation_summary_{label}.csv").open(newline="") as handle:
        summary_by_model[label] = {row["family"]: row for row in csv.DictReader(handle)}
    with (root / f"validation_mace_{label}.csv").open(newline="") as handle:
        prediction_by_model[label] = {row["id"]: row for row in csv.DictReader(handle)}

gate_rows = []
for label in labels:
    neb = neb_by_model[label]
    physical = summary_by_model[label]
    max_barrier = max(float(row["abs_barrier_error_ev"]) for row in neb)
    max_path = max(float(row["path_max_abs_error_ev"]) for row in neb)
    saddle_ok = all(row["dft_max_image"] == row["mace_max_image"] for row in neb)
    binding = float(physical["binding"]["rmse"])
    substitution = float(physical["substitution_delta"]["rmse"])
    vacancy_error = float(physical["vacancy"]["max_abs"])
    vacancy_prediction = float(
        prediction_by_model[label]["vacancy_formation"]["value_ev"]
    )
    neb_ok = max_barrier <= 0.08 and saddle_ok
    property_ok = binding <= 0.05 and substitution <= 0.05 and vacancy_error <= 0.10
    gate_rows.append({
        "model": label,
        "max_abs_barrier_error_ev": max_barrier,
        "max_path_abs_error_ev": max_path,
        "all_saddles_correct": saddle_ok,
        "binding_rmse_ev": binding,
        "substitution_rmse_ev": substitution,
        "dft_vacancy_formation_ev": dft_vacancy,
        "predicted_vacancy_formation_ev": vacancy_prediction,
        "vacancy_error_ev": vacancy_error,
        "neb_status": "pass" if neb_ok else "check",
        "property_status": "pass" if property_ok else "check",
        "overall_status": "pass" if neb_ok and property_ok else "check",
    })

with (root / "ensemble_gate.csv").open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(gate_rows[0]))
    writer.writeheader()
    writer.writerows(gate_rows)

elements = [row["element"] for row in neb_by_model[labels[0]]]
committee_rows = []
for element in elements:
    rows = {
        label: next(row for row in neb_by_model[label] if row["element"] == element)
        for label in labels
    }
    values = [float(rows[label]["mace_forward_barrier_ev"]) for label in labels]
    dft = float(rows[labels[0]]["dft_forward_barrier_ev"])
    mean = statistics.fmean(values)
    committee_rows.append({
        "element": element,
        "dft_barrier_ev": dft,
        "seed11_barrier_ev": values[0],
        "seed29_barrier_ev": values[1],
        "seed47_barrier_ev": values[2],
        "ensemble_mean_ev": mean,
        "ensemble_std_ev": statistics.stdev(values),
        "ensemble_mean_error_ev": mean - dft,
        "ensemble_mean_abs_error_ev": abs(mean - dft),
        "all_saddles_correct": all(
            rows[label]["dft_max_image"] == rows[label]["mace_max_image"]
            for label in labels
        ),
    })

with (root / "committee_neb.csv").open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(committee_rows[0]))
    writer.writeheader()
    writer.writerows(committee_rows)

vacancy_values = [float(row["predicted_vacancy_formation_ev"]) for row in gate_rows]
vacancy_mean = statistics.fmean(vacancy_values)
with (root / "committee_vacancy.csv").open("w", newline="") as handle:
    fields = [
        "dft_vacancy_formation_ev", "ensemble_mean_ev", "ensemble_std_ev",
        "ensemble_mean_error_ev", "ensemble_mean_abs_error_ev",
    ]
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    writer.writerow({
        "dft_vacancy_formation_ev": dft_vacancy,
        "ensemble_mean_ev": vacancy_mean,
        "ensemble_std_ev": statistics.stdev(vacancy_values),
        "ensemble_mean_error_ev": vacancy_mean - dft_vacancy,
        "ensemble_mean_abs_error_ev": abs(vacancy_mean - dft_vacancy),
    })

for name in ("ensemble_gate.csv", "committee_neb.csv", "committee_vacancy.csv"):
    print(root / name)
PY

echo "[done] v6 ensemble validation complete"
cat "$OUT/ensemble_gate.csv"
cat "$OUT/committee_neb.csv"
cat "$OUT/committee_vacancy.csv"
