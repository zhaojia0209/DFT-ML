"""Recover NVE statistics from spaced thermo output, without rerunning MD."""
import argparse
import json
import math
from pathlib import Path
import statistics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, required=True)
    args = parser.parse_args()
    path = args.run_dir / 'log.lammps'
    text = path.read_text(encoding='utf-8', errors='replace')
    if '\nNVE_RUN_COMPLETE\n' not in text:
        raise ValueError('Missing completion marker in log')
    header = None
    samples = {}
    required = ('Step', 'Time', 'Atoms', 'Temp', 'Press', 'TotEng', 'Volume')
    for line in text.splitlines():
        fields = line.split()
        if fields and fields[0] == 'Step' and all(k in fields for k in required):
            header = fields
            continue
        if line.startswith('Loop time of'):
            header = None
        if header is None or len(fields) != len(header):
            continue
        try:
            vals = [float(v) for v in fields]
        except ValueError:
            continue
        row = dict(zip(header, vals))
        if not all(math.isfinite(row[k]) for k in required):
            raise ValueError('Non-finite thermo value')
        if row['Atoms'] <= 0:
            raise ValueError('Invalid atom count')
        samples[int(row['Step'])] = row
    rows = [samples[k] for k in sorted(samples)]
    if len(rows) < 3:
        raise ValueError('Fewer than three readable thermo samples')
    counts = {r['Atoms'] for r in rows}
    if len(counts) != 1:
        raise ValueError('Atom count changed')
    times = [r['Time'] for r in rows]
    energies = [r['TotEng']/r['Atoms'] for r in rows]
    if any(b <= a for a,b in zip(times, times[1:])):
        raise ValueError('Time must increase strictly')
    mt, me = statistics.mean(times), statistics.mean(energies)
    slope = sum((t-mt)*(e-me) for t,e in zip(times,energies))/sum((t-mt)**2 for t in times)
    report = dict(run_completed=True, recovered_from='log.lammps thermo output',
        n_atoms=int(rows[0]['Atoms']), n_samples=len(rows),
        first_step=int(rows[0]['Step']), last_step=int(rows[-1]['Step']),
        duration_ps=times[-1]-times[0],
        energy_drift_ev_per_atom_ps=slope,
        energy_endpoint_change_ev_per_atom=energies[-1]-energies[0],
        energy_peak_to_peak_ev_per_atom=max(energies)-min(energies),
        detrended_energy_rms_ev_per_atom=math.sqrt(statistics.mean(
            [(e-me-slope*(t-mt))**2 for t,e in zip(times,energies)])),
        mean_temperature_k=statistics.mean(r['Temp'] for r in rows),
        min_temperature_k=min(r['Temp'] for r in rows),
        max_temperature_k=max(r['Temp'] for r in rows),
        mean_pressure_bar=statistics.mean(r['Press'] for r in rows),
        volume_range_angstrom3=max(r['Volume'] for r in rows)-min(r['Volume'] for r in rows),
        note='Recovered at thermo cadence (normally 100 steps), not original 10-step sampling. High-frequency fluctuations may be missed; no automatic stability verdict.')
    dest = args.run_dir / 'summary_recovered.json'
    dest.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
    print('Summary:', dest)


if __name__ == '__main__':
    main()
