#!/usr/bin/env bash
set -euo pipefail
cd /home/zhaojia/AlZnMgCuV1
# The Python driver passes a separate, controlled runtime environment to VASP.
exec env -u LD_PRELOAD -u PYTHONPATH \
  /home/zhaojia/AlZnMgCuV1/.venv-mace-cpu/bin/python3 -u \
  scripts/cu_dft_workflow.py run sp --ranks 40

