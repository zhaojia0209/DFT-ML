"""Screen saved cubic FCC trajectories for vacancy site changes (not jump rates)."""
import argparse
import csv
import json
from pathlib import Path
import tempfile


def dumps(path):
    import numpy as np
    with path.open() as f:
        while True:
            line = f.readline()
            if not line:
                return
            if not line.strip():
                continue
            if line.strip() != 'ITEM: TIMESTEP':
                raise ValueError('Unexpected dump header')
            step = int(f.readline())
            if f.readline().strip() != 'ITEM: NUMBER OF ATOMS':
                raise ValueError('Missing atom-count header')
            n = int(f.readline())
            if f.readline().strip() != 'ITEM: BOX BOUNDS pp pp pp':
                raise ValueError('Requires orthogonal, fully periodic dump')
            bounds = np.array([[float(x) for x in f.readline().split()] for _ in range(3)])
            cols = f.readline().split()[2:]
            required = ['id', 'type', 'xu', 'yu', 'zu']
            if not all(k in cols for k in required):
                raise ValueError('Requires id type xu yu zu')
            a = np.array([[float(x) for x in f.readline().split()] for _ in range(n)])
            a = a[np.argsort(a[:, cols.index('id')])]
            yield step, bounds, a[:,cols.index('id')].astype(int), a[:,cols.index('type')].astype(int), a[:,[cols.index(k) for k in ['xu','yu','zu']]]


def save_csv(path, rows, fields):
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dump', type=Path, required=True)
    p.add_argument('--output-root', type=Path, required=True)
    p.add_argument('--cells', type=int, default=5)
    p.add_argument('--timestep-fs', type=float, default=1.)
    p.add_argument('--max-site-distance', type=float, default=0.9)
    p.add_argument('--min-distance-gap', type=float, default=0.3)
    args = p.parse_args()
    import numpy as np
    from scipy.spatial import cKDTree
    if args.cells < 1 or args.timestep_fs <= 0:
        p.error('Positive cells and timestep required')
    basis = np.array([[0,0,0],[0,.5,.5],[.5,0,.5],[.5,.5,0]])
    sites = np.array([(b+[i,j,k])/args.cells for i in range(args.cells)
                      for j in range(args.cells) for k in range(args.cells) for b in basis])
    tree = cKDTree(sites, boxsize=1.)
    args.output_root.mkdir(parents=True, exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix='analysis_', dir=args.output_root.resolve()))
    frames, events = [], []
    assignments, vacancies = [], []
    origin_ids = origin_types = None
    shift = np.zeros(3)
    for step, bounds, ids, types, xyz in dumps(args.dump):
        lengths = bounds[:,1]-bounds[:,0]
        if not np.allclose(lengths, lengths[0], rtol=1e-7) or lengths[0] <= 0:
            raise ValueError('This checker requires a cubic FCC cell')
        if len(ids) != len(sites)-1 or len(set(ids)) != len(ids):
            raise ValueError('Requires exactly one missing atom and unique IDs')
        if origin_ids is None:
            origin_ids, origin_types = ids.copy(), types.copy()
        elif not np.array_equal(ids, origin_ids) or not np.array_equal(types, origin_types):
            raise ValueError('Atom IDs or types changed')
        if frames and step <= frames[-1]['step']:
            raise ValueError('Steps must increase; analyze separate stages separately')
        frac = (xyz-bounds[:,0])/lengths
        # Correct uniform translation robustly; the affine cell change is already removed.
        for _ in range(5):
            _, nearest = tree.query((frac-shift)%1., k=1)
            residual = frac-shift-sites[nearest]
            residual -= np.rint(residual)
            update = np.median(residual, axis=0)
            shift += update
            if np.max(np.abs(update)) < 1e-10:
                break
        distances, indices = tree.query((frac-shift)%1., k=2)
        distances *= lengths[0]
        nearest = indices[:,0]
        counts = np.bincount(nearest, minlength=len(sites))
        empty = np.flatnonzero(counts == 0)
        ambiguous = int(np.sum((distances[:,0] > args.max_site_distance) |
                               ((distances[:,1]-distances[:,0]) < args.min_distance_gap)))
        valid = len(empty)==1 and int(counts.max())==1 and ambiguous==0
        vacancy = int(empty[0]) if valid else -1
        occupancy = np.full(len(sites), -1, dtype=int)
        if valid:
            occupancy[nearest] = ids
        assignments.append(occupancy if valid else None)
        vacancies.append(vacancy)
        frames.append(dict(frame=len(frames), step=step, time_ps=step*args.timestep_fs/1000,
            valid=bool(valid), vacancy_site=vacancy, empty_sites=len(empty),
            multiply_occupied_sites=int(np.sum(counts>1)), ambiguous_atoms=ambiguous,
            max_site_distance_angstrom=float(distances[:,0].max()),
            cell_length_angstrom=float(lengths[0]),
            translation_x_fraction=float(shift[0]), translation_y_fraction=float(shift[1]),
            translation_z_fraction=float(shift[2])))
    if not frames:
        raise ValueError('No frames read')
    type_by_id = dict(zip(origin_ids.tolist(), origin_types.tolist()))
    symbols = {1:'Al',2:'Zn',3:'Mg',4:'Cu'}
    for i in range(1,len(frames)):
        before, after = assignments[i-1], assignments[i]
        if before is None or after is None or vacancies[i-1]==vacancies[i]:
            continue
        va,vb = vacancies[i-1], vacancies[i]
        changed = np.flatnonzero(before!=after)
        moved = int(before[vb])
        single = len(changed)==2 and moved>0 and after[va]==moved
        ds = sites[vb]-sites[va]
        ds -= np.rint(ds)
        nearest_neighbor = bool(np.isclose(np.linalg.norm(ds), 1/(args.cells*np.sqrt(2)), atol=1e-8))
        persistent = i+1<len(frames) and vacancies[i+1]==vb and assignments[i+1] is not None
        returned = i+1<len(frames) and vacancies[i+1]==va and assignments[i+1] is not None
        label = ('persistent_sampled_exchange' if persistent else 'immediate_sampled_return' if returned
                 else 'unconfirmed_sampled_exchange') if single and nearest_neighbor else 'unresolved_site_change'
        events.append(dict(from_step=frames[i-1]['step'], to_step=frames[i]['step'],
            interval_start_ps=frames[i-1]['time_ps'], interval_end_ps=frames[i]['time_ps'],
            vacancy_from=va,vacancy_to=vb, exchange_atom_id=moved if single else -1,
            exchange_element=symbols.get(type_by_id.get(moved),'unknown') if single else 'unresolved',
            nearest_neighbor=nearest_neighbor, changed_sites=len(changed), classification=label))
    save_csv(out/'site_frames.csv',frames,list(frames[0]))
    event_fields=['from_step','to_step','interval_start_ps','interval_end_ps','vacancy_from','vacancy_to',
                  'exchange_atom_id','exchange_element','nearest_neighbor','changed_sites','classification']
    save_csv(out/'sampled_events.csv',events,event_fields)
    report=dict(dump=str(args.dump.resolve()),frames=len(frames),valid_frames=sum(r['valid'] for r in frames),
        ambiguous_frames=sum(not r['valid'] for r in frames),
        duration_ps=frames[-1]['time_ps']-frames[0]['time_ps'],
        saved_intervals_ps=sorted(set(round(b['time_ps']-a['time_ps'],10) for a,b in zip(frames,frames[1:]))),
        sampled_vacancy_site_changes=len(events),
        persistent_sampled_exchanges=sum(e['classification']=='persistent_sampled_exchange' for e in events),
        unique_valid_vacancy_sites=len(set(v for v in vacancies if v>=0)),
        persistent_exchange_elements={s:sum(e['classification']=='persistent_sampled_exchange' and
                                          e['exchange_element']==s for e in events) for s in symbols.values()},
        max_site_distance_cutoff_angstrom=args.max_site_distance,
        min_nearest_second_nearest_gap_angstrom=args.min_distance_gap,
        note='FCC nearest-site screening only. No forced one-to-one assignment. Invalid frames break event detection. Persistence means two saved frames, not a resolved physical jump. Sub-frame returns and multi-hop paths may be missed; do not derive rates or diffusion coefficients.',
        output=str(out))
    (out/'summary.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
