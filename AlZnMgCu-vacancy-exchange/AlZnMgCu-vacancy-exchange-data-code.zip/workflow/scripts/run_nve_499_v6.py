"""Run a 2 ps fixed-cell NVE check from the completed 499-atom NPT data."""
import argparse
import json
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import tempfile


def main():
    root = Path('/home/zhaojia/AlZnMgCuV1')
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, default=root / 'work/equilibration_499_v6/run_vmqsw5on/final.data')
    p.add_argument('--steps', type=int, default=2000)
    p.add_argument('--timestep-fs', type=float, default=1.0)
    args = p.parse_args()
    if args.steps < 100 or args.timestep_fs <= 0:
        p.error('Require steps >= 100 and positive timestep')
    model = root / 'work/final_models/alzmcv_v6_seed11_final.model-lammps.pt'
    mpi = Path('/opt/intel/oneapi/mpi/2021.12/bin/mpirun')
    lmp = Path('/home/zhaojia/lammps-mace-cpu/install/bin/lmp')
    for path in (args.source, model, mpi, lmp):
        if not path.is_file():
            raise FileNotFoundError(path)
    if not any(line.strip().split('#')[0].strip() == 'Velocities'
               for line in args.source.read_text().splitlines()):
        raise ValueError('Source data must contain the saved NPT velocities')
    parent = root / 'work/nve_499_v6'
    parent.mkdir(parents=True, exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix='run_', dir=parent))
    shutil.copy2(args.source, out / 'start.data')
    inp = f'''units metal
atom_style atomic
boundary p p p
atom_modify map yes
newton on
read_data start.data
pair_style mace no_domain_decomposition
pair_coeff * * {model} Al Zn Mg Cu
neighbor 2.0 bin
neigh_modify every 1 delay 0 check yes
reset_timestep 0
timestep {args.timestep_fs / 1000:.12g}
thermo 100
thermo_style custom step time atoms temp press pe ke etotal vol cpu
thermo_modify flush yes norm no format float %.16g
variable tt equal time
variable ee equal etotal/count(all)
variable tempv equal temp
variable pp equal press
variable vv equal vol
fix INTEGRATE all nve
fix SAMPLE all ave/time 1 1 10 v_tt v_ee v_tempv v_pp v_vv file nve_samples.dat format %.17g
dump TRAJ all custom 100 nve.dump id type xu yu zu vx vy vz
dump_modify TRAJ sort id format float %.17g
run 0
print "$(time:%.17g) $(v_ee:%.17g) $(temp:%.17g) $(press:%.17g) $(vol:%.17g)" file initial.txt screen no
run {args.steps}
write_data final.data nocoeff
print "NVE_RUN_COMPLETE"
'''
    (out / 'in.nve').write_text(inp, encoding='utf-8')
    env = os.environ.copy()
    for key in ('LD_PRELOAD', 'I_MPI_PIN_DOMAIN', 'I_MPI_PIN_PROCESSOR_LIST', 'KMP_AFFINITY', 'GOMP_CPU_AFFINITY'):
        env.pop(key, None)
    env.update(I_MPI_PIN='0', OMP_PROC_BIND='false', OMP_NUM_THREADS='48',
               MKL_NUM_THREADS='48', OPENBLAS_NUM_THREADS='1',
               LD_LIBRARY_PATH='/home/zhaojia/libtorch-2.5.1-cpu/lib:/opt/intel/oneapi/mpi/2021.12/lib')
    print('Output directory:', out, flush=True)
    print('Source:', args.source, flush=True)
    with (out / 'console.log').open('w') as handle:
        result = subprocess.run([str(mpi), '-np', '1', str(lmp), '-in', 'in.nve', '-log', 'log.lammps'],
                                cwd=out, env=env, stdout=handle, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError('LAMMPS failed; see ' + str(out / 'console.log'))
    rows = [[float(v) for v in (out / 'initial.txt').read_text().split()]]
    for line in (out / 'nve_samples.dat').read_text().splitlines():
        if line.strip() and not line.lstrip().startswith('#'):
            row = [float(v) for v in line.split()]
            if row[1] > rows[-1][0]:
                rows.append(row[1:])
    if len(rows) < 3 or not all(math.isfinite(v) for row in rows for v in row):
        raise ValueError('Insufficient or non-finite samples')
    times, energies, temperatures, pressures, volumes = map(list, zip(*rows))
    mt, me = statistics.mean(times), statistics.mean(energies)
    slope = sum((t-mt)*(e-me) for t,e in zip(times,energies)) / sum((t-mt)**2 for t in times)
    residual = math.sqrt(statistics.mean([(e-me-slope*(t-mt))**2 for t,e in zip(times,energies)]))
    # Diagnostic values only: do not automatically certify an integrator or model.
    report = dict(run_completed=True, source=str(args.source.resolve()), model=str(model),
                  timestep_fs=args.timestep_fs, steps=args.steps, duration_ps=args.steps*args.timestep_fs/1000,
                  n_samples=len(rows), energy_drift_ev_per_atom_ps=slope,
                  energy_endpoint_change_ev_per_atom=energies[-1]-energies[0],
                  energy_peak_to_peak_ev_per_atom=max(energies)-min(energies),
                  detrended_energy_rms_ev_per_atom=residual,
                  mean_temperature_k=statistics.mean(temperatures),
                  min_temperature_k=min(temperatures), max_temperature_k=max(temperatures),
                  mean_pressure_bar=statistics.mean(pressures),
                  volume_range_angstrom3=max(volumes)-min(volumes),
                  note='Numerical stability check only; no automatic equilibrium or diffusion verdict')
    (out / 'summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
    print('Summary:', out / 'summary.json', flush=True)


if __name__ == '__main__':
    main()
