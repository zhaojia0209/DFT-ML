"""Recover only Mg_common_neighbor from complete OUTCAR coordinates (Linux)."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import tempfile


def check_idle():
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        try:
            args = (p / 'cmdline').read_bytes().split(b'\0')
        except (OSError, PermissionError):
            continue
        names = [Path(a.decode(errors='replace')).name for a in args if a]
        if any(n in ('vasp_std', 'vasp_gam', 'cu_dft_workflow.py') for n in names):
            raise RuntimeError(f'Active VASP/workflow PID {p.name}; stop recovery')


def blocks(path, n):
    lines = path.read_bytes().decode(errors='replace').splitlines()
    found = {}
    ordinal = 0
    for i, line in enumerate(lines):
        if 'POSITION' not in line or 'TOTAL-FORCE' not in line:
            continue
        ordinal += 1
        j = i + 1
        while j < len(lines) and (not lines[j].strip() or set(lines[j].strip()) <= {'-'}):
            j += 1
        rows = []
        for text in lines[j:j+n]:
            fields = text.split()
            if len(fields) != 6:
                break
            try:
                values = [float(v) for v in fields]
            except ValueError:
                break
            if not all(math.isfinite(v) for v in values):
                break
            rows.append(values[:3])
        if len(rows) == n:
            found[ordinal] = rows
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--again', action='store_true',
                        help='Archive a subsequent interrupted run and recover it again')
    args = parser.parse_args()
    from ase.io import read, write
    import numpy as np
    from cu_dft_workflow import signature, incar

    root = Path('/home/zhaojia/AlZnMgCuV1/work/cu_environment_dft_v1/neb').resolve()
    task = root / 'tasks/Mg_common_neighbor'
    check_idle()
    if (task / 'recovery.json').exists() and not args.again:
        raise RuntimeError('Already recovered; do not recover twice')
    if all('reached required accuracy' in (task / i / 'OUTCAR').read_text(errors='replace')
           and 'General timing and accounting' in (task / i / 'OUTCAR').read_text(errors='replace')
           for i in ('01', '02', '03', '04', '05') if (task / i / 'OUTCAR').exists()) and all(
           (task / i / 'OUTCAR').exists() for i in ('01', '02', '03', '04', '05')):
        raise RuntimeError('This task already has convergence and termination markers; do not restart it')
    settings = incar(task / 'INCAR')
    for key, value in {'IMAGES': '5', 'ISIF': '2', 'ISTART': '0', 'ICHARG': '2'}.items():
        if settings.get(key) != value:
            raise RuntimeError(f'Expected {key}={value}, got {settings.get(key)}')

    # Ensure the original runner will skip completed work without altering its records.
    for name in ('Mg_no_cu', 'Mg_far_cu'):
        done = root / 'tasks' / name
        record = json.loads((done / 'execution.json').read_text())
        if record.get('exit_code') != 0 or record.get('input_sha256') != signature(done):
            raise RuntimeError(f'{name}: completion record/hash not valid; left untouched')
        for image in ('01', '02', '03', '04', '05'):
            text = (done / image / 'OUTCAR').read_text(errors='replace')
            if 'reached required accuracy' not in text or 'General timing and accounting' not in text:
                raise RuntimeError(f'{name}/{image}: convergence/termination not verified')
        print('[preserve]', name)

    frames, snapshots = {}, {}
    for image in ('00', '01', '02', '03', '04', '05', '06'):
        poscar = task / image / 'POSCAR'
        if b'\0' in poscar.read_bytes():
            raise RuntimeError(f'NUL in {poscar}')
        atoms = read(poscar, format='vasp')
        if len(atoms) != 107 or not np.isfinite(atoms.positions).all():
            raise RuntimeError(f'Invalid original POSCAR: {image}')
        frames[image] = atoms
        if image not in ('00', '06'):
            snapshots[image] = blocks(task / image / 'OUTCAR', 107)
    common = set.intersection(*(set(v) for v in snapshots.values()))
    if not common:
        raise RuntimeError('No common complete coordinate block')
    step = max(common)
    for image, atoms in frames.items():
        if not np.allclose(atoms.cell.array, frames['00'].cell.array, rtol=0, atol=1e-7):
            raise RuntimeError('Cells differ')
        if atoms.get_chemical_symbols() != frames['00'].get_chemical_symbols():
            raise RuntimeError('Species ordering differs')
        if image in snapshots:
            atoms.set_positions(snapshots[image][step], apply_constraint=False)
            distance = atoms.get_all_distances(mic=True)
            np.fill_diagonal(distance, np.inf)
            minimum = float(distance.min())
            if minimum < 1.5:
                raise RuntimeError(f'{image}: suspicious minimum distance {minimum}')
            print(f'[recoverable] image={image} block={step} min_distance={minimum:.6f} A')
    print('Electronic and optimizer history will restart; coordinates are recovered.')
    if not args.apply:
        print('CHECK PASSED. Run again with --apply to archive and replace this task.')
        return

    check_idle()
    archive = Path(tempfile.mkdtemp(prefix='recovery_Mg_common_neighbor_', dir=root))
    clean = archive / 'prepared'
    clean.mkdir()
    for name in ('INCAR', 'KPOINTS', 'POTCAR', 'POSCAR'):
        source = task / name
        if source.exists():
            if not source.stat().st_size or b'\0' in source.read_bytes():
                raise RuntimeError(f'Invalid input {source}')
            shutil.copy2(source, clean / name)
        elif name != 'POSCAR':
            raise FileNotFoundError(source)
    for image, atoms in frames.items():
        dest = clean / image
        dest.mkdir()
        if image in ('00', '06'):
            shutil.copy2(task / image / 'POSCAR', dest / 'POSCAR')
            shutil.copy2(task / image / 'OUTCAR', dest / 'OUTCAR')
        else:
            write(dest / 'POSCAR', atoms, format='vasp', direct=True, sort=False, vasp5=True)
            check = read(dest / 'POSCAR', format='vasp')
            if not np.allclose(check.positions, atoms.positions, atol=1e-9, rtol=0):
                raise RuntimeError('Written coordinates failed verification')
    provenance = {
        'source': str(task), 'coordinate_block': step,
        'source_outcar_sha256': {
            i: hashlib.sha256((task / i / 'OUTCAR').read_bytes()).hexdigest()
            for i in snapshots},
        'backup': str(archive / 'original'),
        'previous_recovery_record': str(archive / 'original/recovery.json')
            if (task / 'recovery.json').exists() else None,
        'note': 'Fixed-cell coordinate restart; fresh SCF and optimizer history.'}
    (clean / 'recovery.json').write_text(json.dumps(provenance, indent=2))
    check_idle()
    task.rename(archive / 'original')
    try:
        clean.rename(task)
    except Exception:
        (archive / 'original').rename(task)
        raise
    lock = root / 'RUNNING.lock'
    if lock.exists():
        lock.rename(archive / 'RUNNING.lock.stale')
    print('[RECOVERED]', task)
    print('[BACKUP]', archive / 'original')
    os.sync()
    print('Recovery saved. MPI rank count is selected by the launcher, not this script.')


if __name__ == '__main__':
    main()
