"""Launch the 499-atom equilibration pilot in a fresh directory (stdlib only)."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def main():
    root = Path('/home/zhaojia/AlZnMgCuV1')
    template = Path(__file__).resolve().with_name('in.equilibrate')
    data = root / 'work/pilot/05_md/runs/pilot_cu10_v1_T500_r1/structure.data'
    model = root / 'work/final_models/alzmcv_v6_seed11_final.model-lammps.pt'
    mpi = Path('/opt/intel/oneapi/mpi/2021.12/bin/mpirun')
    lmp = Path('/home/zhaojia/lammps-mace-cpu/install/bin/lmp')
    for path in (template, data, model, mpi, lmp):
        if not path.is_file():
            raise FileNotFoundError(path)
    parent = root / 'work/equilibration_499_v6'
    parent.mkdir(parents=True, exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix='run_', dir=parent))
    shutil.copy2(data, out / 'structure.data')
    shutil.copy2(template, out / 'in.equilibrate')
    env = os.environ.copy()
    for key in ('LD_PRELOAD', 'I_MPI_PIN_DOMAIN', 'I_MPI_PIN_PROCESSOR_LIST',
                'KMP_AFFINITY', 'GOMP_CPU_AFFINITY'):
        env.pop(key, None)
    env.update(I_MPI_PIN='0', OMP_PROC_BIND='false', OMP_NUM_THREADS='48',
               MKL_NUM_THREADS='48', OPENBLAS_NUM_THREADS='1',
               LD_LIBRARY_PATH='/home/zhaojia/libtorch-2.5.1-cpu/lib:/opt/intel/oneapi/mpi/2021.12/lib')
    command = [str(mpi), '-np', '1', str(lmp), '-in', 'in.equilibrate', '-log', 'log.lammps']
    print('Output directory:', out, flush=True)
    print('Starting fixed-cell minimization, 2 ps NVT, 5 ps isotropic NPT.', flush=True)
    with (out / 'console.log').open('w') as log:
        result = subprocess.run(command, cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT)
    logtext = (out / 'log.lammps').read_text(errors='replace') if (out / 'log.lammps').exists() else ''
    completed = result.returncode == 0 and '\nEQUILIBRATION_RUN_COMPLETE\n' in logtext
    (out / 'execution.json').write_text(json.dumps(dict(exit_code=result.returncode,
        run_completed=completed, equilibrium_assessed=False, output=str(out)), indent=2))
    print('Run completed:', completed, flush=True)
    print('Output directory:', out, flush=True)
    if not completed:
        print('Inspect console.log and log.lammps in that directory.', flush=True)
        return 1
    print('NPT block columns: Step, T(K), P(bar), Volume(A^3), PE/atom(eV), Lx(A)', flush=True)
    print((out / 'npt_blocks.dat').read_text(), flush=True)
    print('Completion is not an equilibrium verdict; inspect block trends.', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
