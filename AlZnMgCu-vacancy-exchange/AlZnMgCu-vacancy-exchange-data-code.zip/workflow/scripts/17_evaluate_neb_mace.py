from _bootstrap import run

run(["neb-mace"])
