"""Generate and run a fixed-volume 3999-atom MACE CPU benchmark."""
import os
import sys
from pathlib import Path
import subprocess
import tempfile
import json


def main():
    # ASE/NumPy must not inherit the standalone LibTorch library search path.
    keys = ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'PYTHONPATH', 'PYTHONHOME')
    if any(os.environ.get(k) for k in keys):
        clean = os.environ.copy()
        for k in keys:
            clean.pop(k, None)
        os.execve(sys.executable, [sys.executable, '-u', *sys.argv], clean)
    import numpy as np
    from ase.build import bulk
    from ase.io import write

    root = Path('/home/zhaojia/AlZnMgCuV1')
    model = root / 'work/final_models/alzmcv_v6_seed11_final.model-lammps.pt'
    mpi = Path('/opt/intel/oneapi/mpi/2021.12/bin/mpirun')
    lmp = Path('/home/zhaojia/lammps-mace-cpu/install/bin/lmp')
    for path in (model, mpi, lmp):
        if not path.is_file():
            raise FileNotFoundError(path)
    parent = root / 'work/md_benchmark_4000_v6'
    parent.mkdir(parents=True, exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix='run_', dir=parent))
    atoms = bulk('Al', 'fcc', a=4.05, cubic=True).repeat((10, 10, 10))
    order = np.random.default_rng(20260908).permutation(len(atoms))
    atoms.symbols[order[:120]] = 'Zn'
    atoms.symbols[order[120:240]] = 'Mg'
    atoms.symbols[order[240:280]] = 'Cu'
    vacancy_site = int(order[280])
    del atoms[vacancy_site]
    write(out / 'structure.data', atoms, format='lammps-data', atom_style='atomic',
          specorder=['Al', 'Zn', 'Mg', 'Cu'], masses=True, units='metal')
    metadata = dict(n_sites=4000, n_atoms=len(atoms), vacancy_count=1,
                    vacancy_site_index=vacancy_site, vacancy_fraction=1 / 4000,
                    element_counts={el: atoms.get_chemical_symbols().count(el)
                                    for el in ('Al', 'Zn', 'Mg', 'Cu')},
                    temperature_k=500, timestep_fs=1, warmup_steps=100,
                    timed_steps=200, threads=48, mpi_ranks=1,
                    purpose='Performance benchmark, not equilibrated production MD',
                    model=str(model))
    (out / 'metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    (out / 'in.benchmark').write_text(f'''units metal
atom_style atomic
boundary p p p
atom_modify map yes
newton on
read_data structure.data
pair_style mace no_domain_decomposition
pair_coeff * * {model} Al Zn Mg Cu
neighbor 2.0 bin
neigh_modify every 1 delay 0 check yes
timestep 0.001
velocity all create 500 20260908 mom yes rot no dist gaussian
thermo 20
thermo_style custom step time temp pe ke etotal press vol cpu
thermo_modify flush yes norm no format float %.12g
fix THERM all nvt temp 500 500 0.1
print "WARMUP_BEGIN"
run 100
print "TIMED_BEGIN"
run 200
print "BENCHMARK_COMPLETE"
write_restart final.restart
write_dump all custom final.dump id type x y z fx fy fz modify sort id format float %.17g
''', encoding='utf-8')
    env = os.environ.copy()
    for k in ('I_MPI_PIN_DOMAIN', 'I_MPI_PIN_PROCESSOR_LIST', 'KMP_AFFINITY', 'GOMP_CPU_AFFINITY'):
        env.pop(k, None)
    env.update(I_MPI_PIN='0', OMP_PROC_BIND='false', OMP_NUM_THREADS='48',
               MKL_NUM_THREADS='48', OPENBLAS_NUM_THREADS='1')
    env['LD_LIBRARY_PATH'] = '/home/zhaojia/libtorch-2.5.1-cpu/lib:/opt/intel/oneapi/mpi/2021.12/lib'
    command = [str(mpi), '-np', '1', str(lmp), '-in', 'in.benchmark', '-log', 'log.lammps']
    if Path('/usr/bin/time').is_file():
        command = ['/usr/bin/time', '-v', '-o', 'resources.txt', *command]
    print('Output directory:', out, flush=True)
    print('3999 atoms: 3719 Al, 120 Zn, 120 Mg, 40 Cu; one vacancy.', flush=True)
    with (out / 'console.log').open('w', encoding='utf-8') as log:
        result = subprocess.run(command, cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT)
    print('Exit code:', result.returncode, flush=True)
    if result.returncode:
        print('Inspect:', out / 'console.log', flush=True)
        return result.returncode
    logtext = (out / 'log.lammps').read_text()
    for line in logtext.splitlines():
        if line.startswith(('Loop time of', 'Performance:', 'Total wall time:')) or 'CPU use with' in line:
            print(line, flush=True)
    print('Result directory:', out, flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
