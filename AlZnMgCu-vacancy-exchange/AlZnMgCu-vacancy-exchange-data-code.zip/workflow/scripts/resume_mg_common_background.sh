#!/usr/bin/env bash
set -euo pipefail
cd /home/zhaojia/AlZnMgCuV1
RANKS=${1:-90}
if ! [[ "$RANKS" =~ ^[0-9]+$ ]] || (( RANKS < 10 || RANKS % 10 != 0 )); then
    echo 'MPI ranks must be a positive multiple of 10.'
    exit 1
fi
PY=/usr/bin/python3.8
# This separate lock protects recovery and launch from duplicate invocations.
exec 9>work/cu_environment_dft_v1/neb/recovery_launch.lock
flock -n 9 || { echo 'Another recovery/launcher is active.'; exit 1; }
ulimit -s unlimited
printf '[start] %s MPI ranks=%s\n' "$(date -Is)" "$RANKS"
env -u LD_LIBRARY_PATH -u LD_PRELOAD -u PYTHONPATH \
    "$PY" -u scripts/recover_mg_common_neb.py --again --apply
sync
echo '[launch] Recovery complete; continuing original NEB batch.'
set +e
env -u LD_PRELOAD -u PYTHONPATH \
    OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    "$PY" -u scripts/cu_dft_workflow.py run neb --ranks "$RANKS"
code=$?
printf '[finished] %s exit_code=%s\n' "$(date -Is)" "$code"
exit "$code"