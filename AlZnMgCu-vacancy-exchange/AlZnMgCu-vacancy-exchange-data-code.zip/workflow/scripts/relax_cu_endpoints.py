"""Fixed-cell MACE endpoint relaxation; never overwrites an existing output."""
import argparse
import csv
import hashlib
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--threads', type=int, default=16)
    p.add_argument('--fmax', type=float, default=0.01)
    p.add_argument('--steps', type=int, default=500)
    args = p.parse_args()
    if args.threads < 1 or args.steps < 1 or not 0 < args.fmax < 1:
        p.error('Invalid threads, steps or fmax')
    if args.output.exists():
        p.error('Output exists: choose a new directory; no previous results are overwritten')
    tasks = sorted((args.input / 'tasks').glob('*/metadata.json'))
    if not tasks or not args.model.is_file():
        p.error('Missing geometry metadata or model file')
    import numpy as np
    import torch
    from ase.io import read, write
    from ase.optimize import BFGS
    from mace.calculators import MACECalculator
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    calc = MACECalculator(model_paths=str(args.model.resolve()), device='cpu', default_dtype='float64')
    args.output.mkdir(parents=True)
    provenance = {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}
    provenance['model_sha256'] = hashlib.sha256(args.model.read_bytes()).hexdigest()
    provenance['cell_relaxed'] = False
    (args.output / 'settings.json').write_text(json.dumps(provenance, indent=2))
    rows = []
    for meta_file in tasks:
        meta = json.loads(meta_file.read_text())
        task = meta_file.parent
        name = task.name
        last = meta['intermediate_images'] + 1
        relaxed = []
        ok = True
        for image in (0, last):
            out = args.output / 'tasks' / name / f'{image:02d}'
            out.mkdir(parents=True)
            row = dict(task=name, endpoint=image, energy_ev='', fmax_ev_A='',
                       max_site_offset_A='', basin_retained=False, status='failed', error='')
            try:
                atoms = read(str(task / f'{image:02d}' / 'POSCAR'))
                ref = atoms.positions.copy()
                cell = atoms.cell.array.copy()
                length = meta['box_length_angstrom']
                atoms.calc = calc
                print('[run]', name, image, flush=True)
                opt = BFGS(atoms, logfile=str(out/'relax.log'), trajectory=str(out/'relax.traj'), maxstep=0.1)
                opt.run(fmax=args.fmax, steps=args.steps)
                forces = atoms.get_forces()
                energy = float(atoms.get_potential_energy())
                force = float(np.linalg.norm(forces, axis=1).max())
                shift = atoms.positions - ref
                shift -= length * np.rint(shift / length)
                # Remove a common translation for site identity screening only.
                translation = np.median(shift, axis=0)
                shift -= translation
                offset = float(np.linalg.norm(shift, axis=1).max())
                vacant = np.array(meta['moving_end_angstrom'] if image == 0 else meta['moving_start_angstrom'])
                all_sites = np.vstack([ref, vacant])
                diff = (atoms.positions-translation)[:, None, :] - all_sites[None, :, :]
                diff -= length*np.rint(diff/length)
                nearest = np.linalg.norm(diff, axis=2).argmin(axis=1)
                retained = bool(np.array_equal(nearest, np.arange(len(atoms))) and offset < 0.9)
                finite = bool(np.isfinite(energy) and np.isfinite(forces).all())
                good = finite and force <= args.fmax and retained and np.allclose(cell, atoms.cell.array)
                row.update(energy_ev=energy, fmax_ev_A=force, max_site_offset_A=offset,
                           basin_retained=retained, status='pass' if good else 'check')
                write(str(out/'POSCAR'), atoms, format='vasp', direct=True, sort=False)
                # Align endpoints by common translation, with unchanged atom order.
                atoms.positions -= translation
                relaxed.append(atoms.copy())
                ok = ok and good
            except Exception as exc:
                row['error'] = repr(exc)
                ok = False
            rows.append(row)
            (out/'summary.json').write_text(json.dumps(row, indent=2))
            print('[%s] %s %02d fmax=%s' % (row['status'],name,image,row['fmax_ev_A']), flush=True)
            with (args.output/'endpoint_summary.csv').open('w', newline='') as f:
                w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
        if ok:
            start, end = relaxed
            displacement = end.positions-start.positions
            displacement -= length*np.rint(displacement/length)
            for i in range(last+1):
                frame = start.copy()
                frame.positions += displacement * (i/last)
                target = args.output/'neb_initial'/name/f'{i:02d}'
                target.mkdir(parents=True)
                write(str(target/'POSCAR'), frame, format='vasp', direct=True, sort=False)
            (args.output/'neb_initial'/name/'metadata.json').write_text(json.dumps(meta, indent=2))
    print('Summary:', args.output/'endpoint_summary.csv', flush=True)
    if any(r['status'] != 'pass' for r in rows):
        raise SystemExit('Some endpoints failed/check: inspect summaries before NEB.')


if __name__ == '__main__':
    main()
