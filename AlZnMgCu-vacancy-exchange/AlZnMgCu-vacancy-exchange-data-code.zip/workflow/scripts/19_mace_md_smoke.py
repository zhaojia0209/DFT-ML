from _bootstrap import run

run(["md-smoke"])
