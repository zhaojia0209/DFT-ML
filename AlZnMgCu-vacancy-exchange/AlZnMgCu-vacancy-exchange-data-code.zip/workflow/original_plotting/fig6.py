#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.transforms import ScaledTranslation


# ============================================================
# 1. Paths
# ============================================================

ROOT = Path("work/cu_environment_v1")

MANIFEST_FILE = (
    ROOT / "01_geometries" / "manifest.csv"
)

NEB_FILE = (
    ROOT / "03_neb_seed11" / "neb_summary.csv"
)

OUT_PNG = Path(
    "Fig6_final_Cu_geometry_barrier_modulation.png"
)

OUT_PDF = Path(
    "Fig6_final_Cu_geometry_barrier_modulation.pdf"
)

OUT_SVG = Path(
    "Fig6_final_Cu_geometry_barrier_modulation.svg"
)

OUT_DATA = Path(
    "Fig6_final_data.csv"
)


# ============================================================
# 2. Check input files
# ============================================================

for path in [
    MANIFEST_FILE,
    NEB_FILE,
]:

    if not path.exists():
        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )


# ============================================================
# 3. Times New Roman under WSL
# ============================================================

font_files = [
    Path("/mnt/c/Windows/Fonts/times.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbd.ttf"),
    Path("/mnt/c/Windows/Fonts/timesi.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbi.ttf"),
]

for path in font_files:

    if path.exists():
        font_manager.fontManager.addfont(
            str(path)
        )


if font_files[0].exists():

    MAIN_FONT = (
        font_manager.FontProperties(
            fname=str(font_files[0])
        ).get_name()
    )

else:

    MAIN_FONT = "DejaVu Serif"

    print(
        "Warning: Times New Roman not found. "
        "Using DejaVu Serif."
    )


print("Using font:", MAIN_FONT)


# ============================================================
# 4. Publication style
# ============================================================

plt.rcParams.update({

    "font.family": "serif",
    "font.serif": [MAIN_FONT],

    "font.size": 10.5,
    "axes.labelsize": 11.5,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 9,

    "axes.linewidth": 1.0,

    "xtick.direction": "in",
    "ytick.direction": "in",

    "xtick.top": True,
    "ytick.right": True,

    "xtick.major.size": 4,
    "ytick.major.size": 4,

    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,

    "mathtext.fontset": "stix",

    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# ============================================================
# 5. Load data
# ============================================================

manifest = pd.read_csv(
    MANIFEST_FILE
)

neb = pd.read_csv(
    NEB_FILE
)

manifest.columns = (
    manifest.columns.str.strip()
)

neb.columns = (
    neb.columns.str.strip()
)


# ============================================================
# 6. Configurations shown in Fig. 6
# ============================================================

elements = [
    "Mg",
    "Zn",
]

environments = [
    "common_neighbor",
    "near_vacancy",
    "near_solute",
    "far_cu",
]

baseline_tasks = {
    "Mg": "Mg_no_cu",
    "Zn": "Zn_no_cu",
}


# ============================================================
# 7. Cu-free reference barriers
# ============================================================

baseline_barrier = {}


for element in elements:

    task = baseline_tasks[element]

    row = neb.loc[
        neb["task"] == task
    ]

    if len(row) != 1:

        raise RuntimeError(
            f"Expected one row for {task}, "
            f"found {len(row)}."
        )

    baseline_barrier[element] = float(
        row.iloc[0]["forward_barrier_ev"]
    )


print("\nCu-free reference barriers")

for element in elements:

    print(
        f"{element}-V: "
        f"{baseline_barrier[element]:.6f} eV"
    )


# ============================================================
# 8. Build plotting table
# ============================================================

records = []


for element in elements:

    for environment in environments:

        task = (
            f"{element}_{environment}"
        )

        geometry = manifest.loc[
            manifest["task_id"] == task
        ]

        result = neb.loc[
            neb["task"] == task
        ]


        if len(geometry) != 1:

            raise RuntimeError(
                f"Geometry not uniquely found: {task}"
            )


        if len(result) != 1:

            raise RuntimeError(
                f"NEB result not uniquely found: {task}"
            )


        geometry = geometry.iloc[0]
        result = result.iloc[0]


        d_cu_v = float(
            geometry[
                "cu_vacancy_distance_A"
            ]
        )

        d_cu_x = float(
            geometry[
                "cu_solute_distance_A"
            ]
        )

        d_cu_mid = float(
            geometry[
                "cu_midpoint_distance_A"
            ]
        )


        barrier = float(
            result[
                "forward_barrier_ev"
            ]
        )


        # Signed geometric asymmetry
        delta_d = (
            d_cu_v
            - d_cu_x
        )


        # Cu-induced barrier shift
        delta_em = (
            barrier
            - baseline_barrier[element]
        )


        records.append({

            "element":
                element,

            "environment":
                environment,

            "task":
                task,

            "d_Cu_V_A":
                d_cu_v,

            "d_Cu_X_A":
                d_cu_x,

            "d_Cu_mid_A":
                d_cu_mid,

            "delta_d_A":
                delta_d,

            "barrier_eV":
                barrier,

            "baseline_barrier_eV":
                baseline_barrier[element],

            "delta_barrier_eV":
                delta_em,
        })


data = pd.DataFrame(
    records
)


# ============================================================
# 9. Save numerical data used in the figure
# ============================================================

data.to_csv(
    OUT_DATA,
    index=False
)


print(
    "\n=== Fig. 6 data ==="
)

print(
    data[
        [
            "element",
            "environment",
            "d_Cu_V_A",
            "d_Cu_X_A",
            "d_Cu_mid_A",
            "delta_d_A",
            "barrier_eV",
            "delta_barrier_eV",
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# 10. Color normalization
#
# Negative ΔEm = barrier reduction
# Positive ΔEm = barrier increase
#
# Use a symmetric scale centered at zero.
# ============================================================

max_abs_delta = float(
    np.max(
        np.abs(
            data[
                "delta_barrier_eV"
            ]
        )
    )
)


# Add small margin to color limits
color_limit = (
    np.ceil(
        max_abs_delta * 100
    )
    / 100
)


norm = TwoSlopeNorm(
    vmin=-color_limit,
    vcenter=0.0,
    vmax=color_limit,
)

cmap = plt.get_cmap(
    "coolwarm"
)


# ============================================================
# 11. Create figure
# ============================================================

fig, ax = plt.subplots(
    figsize=(7.5, 6.0)
)


# ============================================================
# 12. Δd = 0 symmetry reference
# ============================================================

ax.axvline(
    0.0,
    linestyle="--",
    linewidth=0.9,
    color="0.45",
    zorder=1,
)


# ============================================================
# 13. Marker definitions
# ============================================================

marker_map = {
    "Mg": "o",
    "Zn": "s",
}


environment_labels = {

    "common_neighbor":
        "Common neighbor",

    "near_vacancy":
        "Near vacancy",

    "near_solute":
        "Near solute",

    "far_cu":
        "Far Cu",
}


# ============================================================
# 14. Display-only separation of Mg and Zn markers
#
# Mg and Zn share identical geometric coordinates.
#
# The offset is applied in display coordinates only.
# The physical data coordinates are NOT changed.
# ============================================================

point_shift_pt = {
    "Mg": -8.0,
    "Zn": +8.0,
}


def shifted_transform(element):

    return (
        ax.transData
        +
        ScaledTranslation(
            point_shift_pt[element] / 72.0,
            0.0,
            fig.dpi_scale_trans,
        )
    )


# ============================================================
# 15. Plot data points
# ============================================================

scatter_for_colorbar = None


for _, row in data.iterrows():

    element = row["element"]

    trans = shifted_transform(
        element
    )


    scatter_for_colorbar = ax.scatter(

        row["delta_d_A"],
        row["d_Cu_mid_A"],

        c=[
            row["delta_barrier_eV"]
        ],

        cmap=cmap,
        norm=norm,

        marker=marker_map[element],

        s=125,

        edgecolors="black",
        linewidths=0.85,

        transform=trans,

        zorder=4,
    )


# ============================================================
# 16. Environment labels
#
# Only one environment name is shown because Mg and Zn
# have the same geometric coordinates.
# ============================================================

geometry_reference = (
    data[
        data["element"] == "Mg"
    ]
    .set_index("environment")
)


label_offsets = {

    "common_neighbor":
        (22, 17),

    "near_vacancy":
        (-82, 12),

    "near_solute":
        (22, 12),

    "far_cu":
        (22, 11),
}


for environment in environments:

    row = geometry_reference.loc[
        environment
    ]

    dx, dy = (
        label_offsets[
            environment
        ]
    )


    ax.annotate(

        environment_labels[
            environment
        ],

        xy=(
            row["delta_d_A"],
            row["d_Cu_mid_A"],
        ),

        xytext=(
            dx,
            dy,
        ),

        textcoords="offset points",

        ha="left",
        va="center",

        fontsize=9.5,

        zorder=6,
    )


# ============================================================
# 17. Numerical ΔEm labels
#
# Mg and Zn values are intentionally separated.
# ============================================================

value_offsets = {
    "Mg": (-8, -18),
    "Zn": (+8, -18),
}


for _, row in data.iterrows():

    element = row["element"]

    trans = shifted_transform(
        element
    )

    dx, dy = (
        value_offsets[
            element
        ]
    )


    ax.annotate(

        f'{row["delta_barrier_eV"]:+.3f}',

        xy=(
            row["delta_d_A"],
            row["d_Cu_mid_A"],
        ),

        xycoords=trans,

        xytext=(
            dx,
            dy,
        ),

        textcoords="offset points",

        ha="center",
        va="top",

        fontsize=8.3,

        zorder=7,
    )


# ============================================================
# 18. Δd = 0 label
# ============================================================

ax.text(

    0.0,
    1.93,

    r"$\Delta d=0$",

    ha="center",
    va="bottom",

    fontsize=8.5,
)


# ============================================================
# 19. Axes labels
# ============================================================

ax.set_xlabel(

    r"Cu-position asymmetry, "
    r"$\Delta d="
    r"d_{\mathrm{Cu-V}}"
    r"-d_{\mathrm{Cu-X}}$ "
    r"($\mathrm{\AA}$)"
)


ax.set_ylabel(

    r"Distance from Cu to path midpoint, "
    r"$d_{\mathrm{Cu-mid}}$ "
    r"($\mathrm{\AA}$)"
)


# ============================================================
# 20. Axis ranges
# ============================================================

x_extent = float(
    np.max(
        np.abs(
            data[
                "delta_d_A"
            ]
        )
    )
)


ax.set_xlim(
    -x_extent - 0.65,
    x_extent + 0.65,
)


ax.set_ylim(
    1.85,
    data[
        "d_Cu_mid_A"
    ].max()
    + 0.85,
)


# ============================================================
# 21. Cu-free reference information
# ============================================================

baseline_text = (

    rf"$E_m^0$(Mg-V) = "
    rf"{baseline_barrier['Mg']:.3f} eV"

    "\n"

    rf"$E_m^0$(Zn-V) = "
    rf"{baseline_barrier['Zn']:.3f} eV"
)


ax.text(

    0.025,
    0.975,

    baseline_text,

    transform=ax.transAxes,

    ha="left",
    va="top",

    fontsize=9.0,
)


# ============================================================
# 22. Mg / Zn marker legend
# ============================================================

legend_handles = [

    Line2D(
        [0],
        [0],

        marker="o",
        linestyle="none",

        markerfacecolor="white",
        markeredgecolor="black",

        markersize=7.5,

        label="Mg-V exchange",
    ),

    Line2D(
        [0],
        [0],

        marker="s",
        linestyle="none",

        markerfacecolor="white",
        markeredgecolor="black",

        markersize=7.5,

        label="Zn-V exchange",
    ),
]


ax.legend(

    handles=legend_handles,

    frameon=False,

    loc="upper right",

    handletextpad=0.5,
)


# ============================================================
# 23. Colorbar
# ============================================================

cbar = fig.colorbar(

    scatter_for_colorbar,

    ax=ax,

    fraction=0.050,
    pad=0.025,
)


cbar.set_label(

    r"$\Delta E_m"
    r"=E_m^{\mathrm{Cu}}"
    r"-E_m^0$ (eV)"
)


# Explicitly show zero on colorbar
ticks = np.linspace(
    -color_limit,
    color_limit,
    5,
)

cbar.set_ticks(
    ticks
)


# ============================================================
# 24. Directional interpretation
#
# Keep this minimal.
# ============================================================

ax.text(

    0.025,
    0.025,

    r"$\Delta d<0$  Cu closer to vacancy",

    transform=ax.transAxes,

    ha="left",
    va="bottom",

    fontsize=8.3,
)


ax.text(

    0.975,
    0.025,

    r"$\Delta d>0$  Cu closer to solute",

    transform=ax.transAxes,

    ha="right",
    va="bottom",

    fontsize=8.3,
)


# ============================================================
# 25. Common formatting
# ============================================================

ax.tick_params(

    which="both",

    direction="in",

    top=True,
    right=True,
)


for spine in ax.spines.values():

    spine.set_linewidth(
        1.0
    )


# ============================================================
# 26. Save
# ============================================================

fig.subplots_adjust(
    left=0.13,
    right=0.87,
    bottom=0.12,
    top=0.97,
)


fig.savefig(

    OUT_PNG,

    dpi=600,

    bbox_inches="tight",
)


fig.savefig(

    OUT_PDF,

    bbox_inches="tight",
)


fig.savefig(

    OUT_SVG,

    bbox_inches="tight",
)


print(
    "\nSaved final Fig. 6:"
)

print(
    " ",
    OUT_PNG
)

print(
    " ",
    OUT_PDF
)

print(
    " ",
    OUT_SVG
)

print(
    " ",
    OUT_DATA
)


plt.close(fig)