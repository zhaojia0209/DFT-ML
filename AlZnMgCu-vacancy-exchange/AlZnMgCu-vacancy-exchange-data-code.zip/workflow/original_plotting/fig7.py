#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager


# ============================================================
# 1. Paths
# ============================================================

NEB_FILE = Path(
    "work/cu_environment_v1/03_neb_seed11/neb_summary.csv"
)

OUT_PNG = Path(
    "Fig7_final_barrier_screening.png"
)

OUT_PDF = Path(
    "Fig7_final_barrier_screening.pdf"
)

OUT_SVG = Path(
    "Fig7_final_barrier_screening.svg"
)

OUT_DATA = Path(
    "Fig7_final_data.csv"
)


# ============================================================
# 2. Check input file
# ============================================================

if not NEB_FILE.exists():
    raise FileNotFoundError(
        f"Required file not found:\n{NEB_FILE}"
    )


# ============================================================
# 3. Times New Roman under WSL
# ============================================================

font_files = [
    Path("/mnt/c/Windows/Fonts/times.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbd.ttf"),
    Path("/mnt/c/Windows/Fonts/timesi.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbi.ttf"),
]

for path in font_files:
    if path.exists():
        font_manager.fontManager.addfont(str(path))

if font_files[0].exists():

    MAIN_FONT = font_manager.FontProperties(
        fname=str(font_files[0])
    ).get_name()

else:

    MAIN_FONT = "DejaVu Serif"

    print(
        "Warning: Times New Roman not found. "
        "Using DejaVu Serif."
    )

print("Using font:", MAIN_FONT)


# ============================================================
# 4. Publication style
# ============================================================

plt.rcParams.update({

    "font.family": "serif",
    "font.serif": [MAIN_FONT],

    "font.size": 10.5,
    "axes.labelsize": 11,
    "axes.titlesize": 11,

    "xtick.labelsize": 9.0,
    "ytick.labelsize": 9.5,

    "legend.fontsize": 8.5,

    "axes.linewidth": 1.0,

    "xtick.direction": "in",
    "ytick.direction": "in",

    "xtick.top": True,
    "ytick.right": True,

    "xtick.major.size": 4,
    "ytick.major.size": 4,

    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,

    "mathtext.fontset": "stix",

    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# ============================================================
# 5. Load NEB screening data
# ============================================================

neb = pd.read_csv(NEB_FILE)

neb.columns = (
    neb.columns
    .str.strip()
)


required_columns = {
    "task",
    "initial_energy_ev",
    "final_energy_ev",
    "delta_energy_ev",
    "forward_barrier_ev",
    "reverse_barrier_ev",
    "status",
}

missing = (
    required_columns
    - set(neb.columns)
)

if missing:

    raise ValueError(
        f"Missing columns in {NEB_FILE}:\n"
        f"{missing}\n\n"
        f"Available columns:\n"
        f"{list(neb.columns)}"
    )


# ============================================================
# 6. Environment definitions
# ============================================================

environment_order = [
    "no_cu",
    "far_cu",
    "common_neighbor",
    "near_vacancy",
    "near_solute",
]


environment_labels = {

    "no_cu":
        "No Cu",

    "far_cu":
        "Far Cu",

    "common_neighbor":
        "Common\nneighbor",

    "near_vacancy":
        "Near\nvacancy",

    "near_solute":
        "Near\nsolute",
}


elements = [
    "Mg",
    "Zn",
]


# ============================================================
# 7. Extract required data
# ============================================================

records = []


for element in elements:

    for environment in environment_order:

        task = (
            f"{element}_{environment}"
        )

        row = neb.loc[
            neb["task"] == task
        ]

        if len(row) != 1:

            raise RuntimeError(
                f"Expected one row for {task}, "
                f"found {len(row)}."
            )

        row = row.iloc[0]


        status = str(
            row["status"]
        )

        if not status.startswith(
            "converged"
        ):

            raise RuntimeError(
                f"{task} is not converged.\n"
                f"status = {status}"
            )


        initial_energy = float(
            row["initial_energy_ev"]
        )

        final_energy = float(
            row["final_energy_ev"]
        )

        delta_energy = float(
            row["delta_energy_ev"]
        )

        forward = float(
            row["forward_barrier_ev"]
        )

        reverse = float(
            row["reverse_barrier_ev"]
        )


        asymmetry = (
            forward - reverse
        )


        records.append({

            "element":
                element,

            "environment":
                environment,

            "task":
                task,

            "initial_energy_eV":
                initial_energy,

            "final_energy_eV":
                final_energy,

            "delta_energy_eV":
                delta_energy,

            "forward_barrier_eV":
                forward,

            "reverse_barrier_eV":
                reverse,

            "asymmetry_eV":
                asymmetry,

            "status":
                status,
        })


data = pd.DataFrame(
    records
)


# ============================================================
# 8. Consistency check
#
# E_forward - E_reverse = E_f - E_i
# ============================================================

data[
    "consistency_error_eV"
] = (
    data[
        "asymmetry_eV"
    ]
    -
    data[
        "delta_energy_eV"
    ]
)


max_consistency_error = float(
    np.max(
        np.abs(
            data[
                "consistency_error_eV"
            ]
        )
    )
)


print(
    "\nMaximum thermodynamic consistency error:"
)

print(
    f"{max_consistency_error:.3e} eV"
)


if max_consistency_error > 1.0e-8:

    raise RuntimeError(
        "\nForward-reverse barrier difference "
        "does not match endpoint energy difference.\n"
        f"Maximum error = "
        f"{max_consistency_error:.6e} eV"
    )


# ============================================================
# 9. Cu-free reference barriers
# ============================================================

baseline = {}


for element in elements:

    row = data[
        (
            data["element"] == element
        )
        &
        (
            data["environment"] == "no_cu"
        )
    ]

    baseline[element] = float(
        row.iloc[0][
            "forward_barrier_eV"
        ]
    )


# ============================================================
# 10. Save data
# ============================================================

data.to_csv(
    OUT_DATA,
    index=False
)


print(
    "\n=== Fig. 7 data ==="
)

print(
    data[
        [
            "element",
            "environment",
            "forward_barrier_eV",
            "reverse_barrier_eV",
            "asymmetry_eV",
            "delta_energy_eV",
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# 11. Prepare plotting arrays
# ============================================================

x = np.arange(
    len(environment_order)
)


mg = (
    data[
        data["element"] == "Mg"
    ]
    .set_index("environment")
    .loc[environment_order]
)

zn = (
    data[
        data["element"] == "Zn"
    ]
    .set_index("environment")
    .loc[environment_order]
)


mg_forward = (
    mg[
        "forward_barrier_eV"
    ].to_numpy()
)

zn_forward = (
    zn[
        "forward_barrier_eV"
    ].to_numpy()
)


mg_asym = (
    mg[
        "asymmetry_eV"
    ].to_numpy()
)

zn_asym = (
    zn[
        "asymmetry_eV"
    ].to_numpy()
)


# ============================================================
# 12. Common y range for panels (a) and (b)
# ============================================================

all_forward = np.concatenate(
    [
        mg_forward,
        zn_forward,
    ]
)

ymin = float(
    np.min(all_forward)
    - 0.040
)

ymax = float(
    np.max(all_forward)
    + 0.050
)


# ============================================================
# 13. Create figure
# ============================================================

fig, axes = plt.subplots(
    1,
    3,
    figsize=(12.2, 4.25),
)

ax_a, ax_b, ax_c = axes


# ============================================================
# 14. Helper for Mg/Zn forward-barrier panels
# ============================================================

def plot_forward_panel(
    ax,
    element,
    barriers,
    reference,
    panel_label,
):

    # --------------------------------------------------------
    # Cu-free baseline
    # --------------------------------------------------------

    ax.axhline(
        reference,
        linestyle="--",
        linewidth=0.95,
        zorder=1,
    )


    # --------------------------------------------------------
    # Uniform grey vertical deviations
    # --------------------------------------------------------

    for i, barrier in enumerate(
        barriers
    ):

        if i == 0:
            continue

        ax.plot(
            [
                i,
                i,
            ],
            [
                reference,
                barrier,
            ],
            linewidth=1.0,
            color="0.65",
            zorder=2,
        )


    # --------------------------------------------------------
    # Data points
    # --------------------------------------------------------

    ax.scatter(
        x,
        barriers,
        s=58,
        marker="o",
        zorder=4,
    )


    # --------------------------------------------------------
    # Numerical values
    # --------------------------------------------------------

    for i, barrier in enumerate(
        barriers
    ):

        # Strongly reduced barrier
        if (
            barrier
            < reference - 0.08
        ):

            dy = -11
            va = "top"

        else:

            dy = 7
            va = "bottom"


        ax.annotate(
            f"{barrier:.3f}",
            xy=(
                i,
                barrier,
            ),
            xytext=(
                0,
                dy,
            ),
            textcoords="offset points",
            ha="center",
            va=va,
            fontsize=8.2,
        )


    # --------------------------------------------------------
    # Panel label
    # --------------------------------------------------------

    ax.text(
        0.025,
        0.975,
        panel_label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11.5,
        fontweight="bold",
    )


    # --------------------------------------------------------
    # Baseline value
    # --------------------------------------------------------

    ax.text(
        0.045,
        0.885,
        (
            rf"$E_m^0$ = "
            rf"{reference:.3f} eV"
        ),
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8.6,
    )


    # --------------------------------------------------------
    # Axis
    # --------------------------------------------------------

    ax.set_xticks(
        x
    )

    ax.set_xticklabels(
        [
            environment_labels[e]
            for e in environment_order
        ]
    )


    ax.set_ylabel(
        r"Forward migration barrier, "
        r"$E_m^{\mathrm{forward}}$ (eV)"
    )


    ax.set_title(
        f"{element}-V exchange"
    )


    ax.set_ylim(
        ymin,
        ymax
    )


# ============================================================
# 15. Fig. 7(a)
# ============================================================

plot_forward_panel(
    ax_a,
    "Mg",
    mg_forward,
    baseline["Mg"],
    "(a)",
)


# ============================================================
# 16. Fig. 7(b)
# ============================================================

plot_forward_panel(
    ax_b,
    "Zn",
    zn_forward,
    baseline["Zn"],
    "(b)",
)


# ============================================================
# 17. Fig. 7(c)
# Directional barrier asymmetry
# ============================================================

# Zero reference
ax_c.axhline(
    0.0,
    linestyle="--",
    linewidth=0.95,
    zorder=1,
)


# Horizontal separation
offset = 0.11


# ------------------------------------------------------------
# Mg
# ------------------------------------------------------------

ax_c.scatter(
    x - offset,
    mg_asym,
    marker="o",
    s=58,
    label="Mg-V",
    zorder=4,
)


# ------------------------------------------------------------
# Zn
# ------------------------------------------------------------

ax_c.scatter(
    x + offset,
    zn_asym,
    marker="s",
    s=55,
    label="Zn-V",
    zorder=4,
)


# ------------------------------------------------------------
# Uniform grey stems
# ------------------------------------------------------------

for i in range(
    len(environment_order)
):

    if abs(mg_asym[i]) > 1.0e-10:

        ax_c.plot(
            [
                i - offset,
                i - offset,
            ],
            [
                0.0,
                mg_asym[i],
            ],
            linewidth=1.0,
            color="0.65",
            zorder=2,
        )


    if abs(zn_asym[i]) > 1.0e-10:

        ax_c.plot(
            [
                i + offset,
                i + offset,
            ],
            [
                0.0,
                zn_asym[i],
            ],
            linewidth=1.0,
            color="0.65",
            zorder=2,
        )


# ============================================================
# 18. Numerical asymmetry labels
# ============================================================

for i, value in enumerate(
    mg_asym
):

    if abs(value) < 1.0e-4:
        continue

    if value > 0:

        dy = 7
        va = "bottom"

    else:

        dy = -8
        va = "top"


    ax_c.annotate(
        f"{value:+.3f}",
        xy=(
            i - offset,
            value,
        ),
        xytext=(
            -2,
            dy,
        ),
        textcoords="offset points",
        ha="center",
        va=va,
        fontsize=8.1,
    )


for i, value in enumerate(
    zn_asym
):

    if abs(value) < 1.0e-4:
        continue

    if value > 0:

        dy = 7
        va = "bottom"

    else:

        dy = -8
        va = "top"


    ax_c.annotate(
        f"{value:+.3f}",
        xy=(
            i + offset,
            value,
        ),
        xytext=(
            2,
            dy,
        ),
        textcoords="offset points",
        ha="center",
        va=va,
        fontsize=8.1,
    )


# ============================================================
# 19. Panel (c) formatting
# ============================================================

ax_c.set_xticks(
    x
)

ax_c.set_xticklabels(
    [
        environment_labels[e]
        for e in environment_order
    ]
)


ax_c.set_ylabel(
    r"Directional asymmetry, "
    r"$\Delta E_m^{\mathrm{asym}}$ (eV)"
)


ax_c.set_title(
    "Directional barrier asymmetry"
)


asym_limit = max(
    0.075,
    float(
        np.max(
            np.abs(
                np.concatenate(
                    [
                        mg_asym,
                        zn_asym,
                    ]
                )
            )
        )
        * 1.45
    ),
)


ax_c.set_ylim(
    -asym_limit,
    asym_limit
)


ax_c.legend(
    frameon=False,
    loc="upper left",
)


ax_c.text(
    0.025,
    0.975,
    "(c)",
    transform=ax_c.transAxes,
    ha="left",
    va="top",
    fontsize=11.5,
    fontweight="bold",
)


# ============================================================
# 20. Common formatting
# ============================================================

for ax in axes:

    ax.tick_params(
        which="both",
        direction="in",
        top=True,
        right=True,
    )

    for spine in ax.spines.values():

        spine.set_linewidth(
            1.0
        )


# ============================================================
# 21. Layout
# ============================================================

fig.subplots_adjust(
    left=0.072,
    right=0.988,
    bottom=0.185,
    top=0.91,
    wspace=0.285,
)


# ============================================================
# 22. Save
# ============================================================

fig.savefig(
    OUT_PNG,
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    OUT_PDF,
    bbox_inches="tight",
)

fig.savefig(
    OUT_SVG,
    bbox_inches="tight",
)


print(
    "\nSaved final Fig. 7:"
)

print(
    " ",
    OUT_PNG
)

print(
    " ",
    OUT_PDF
)

print(
    " ",
    OUT_SVG
)

print(
    " ",
    OUT_DATA
)


# ============================================================
# 23. Print final numerical summary
# ============================================================

print(
    "\nCu-free reference barriers:"
)

print(
    f"Mg-V = "
    f"{baseline['Mg']:.6f} eV"
)

print(
    f"Zn-V = "
    f"{baseline['Zn']:.6f} eV"
)


print(
    "\nDirectional barrier asymmetry:"
)

for environment in environment_order:

    mg_value = float(
        mg.loc[
            environment,
            "asymmetry_eV"
        ]
    )

    zn_value = float(
        zn.loc[
            environment,
            "asymmetry_eV"
        ]
    )

    print(
        f"{environment:>16s}: "
        f"Mg = {mg_value:+.6f} eV, "
        f"Zn = {zn_value:+.6f} eV"
    )


plt.close(fig)