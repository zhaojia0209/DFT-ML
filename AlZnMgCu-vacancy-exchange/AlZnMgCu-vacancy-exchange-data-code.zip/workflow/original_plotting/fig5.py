#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import json
import re

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D


# ============================================================
# 1. Paths
# ============================================================

DFT_VALIDATION_FILE = Path(
    "work/refined/03_validation/validation_dft.csv"
)

MACE_VALIDATION_FILES = {
    11: Path(
        "work/ensemble_validation_v6/validation_mace_seed11.csv"
    ),
    29: Path(
        "work/ensemble_validation_v6/validation_mace_seed29.csv"
    ),
    47: Path(
        "work/ensemble_validation_v6/validation_mace_seed47.csv"
    ),
}

NEB_PATH_FILES = {
    11: Path(
        "work/ensemble_validation_v6/neb_mace_paths_seed11.csv"
    ),
    29: Path(
        "work/ensemble_validation_v6/neb_mace_paths_seed29.csv"
    ),
    47: Path(
        "work/ensemble_validation_v6/neb_mace_paths_seed47.csv"
    ),
}

METADATA_ROOTS = [
    Path("work/refined/03_validation/tasks"),
    Path("work/calibration/03_validation/tasks"),
]

OUT_PNG = Path(
    "Fig5_final_energy_landscape_validation.png"
)
OUT_PDF = Path(
    "Fig5_final_energy_landscape_validation.pdf"
)
OUT_SVG = Path(
    "Fig5_final_energy_landscape_validation.svg"
)


# ============================================================
# 2. Check files
# ============================================================

required_files = (
    [DFT_VALIDATION_FILE]
    + list(MACE_VALIDATION_FILES.values())
    + list(NEB_PATH_FILES.values())
)

for path in required_files:
    if not path.exists():
        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )


# ============================================================
# 3. Times New Roman under WSL
# ============================================================

font_files = [
    Path("/mnt/c/Windows/Fonts/times.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbd.ttf"),
    Path("/mnt/c/Windows/Fonts/timesi.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbi.ttf"),
]

for path in font_files:
    if path.exists():
        font_manager.fontManager.addfont(str(path))

if font_files[0].exists():
    MAIN_FONT = font_manager.FontProperties(
        fname=str(font_files[0])
    ).get_name()
else:
    MAIN_FONT = "DejaVu Serif"
    print(
        "Warning: Times New Roman not found. "
        "Using DejaVu Serif."
    )

print("Using font:", MAIN_FONT)


# ============================================================
# 4. Publication style
# ============================================================

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": [MAIN_FONT],

    "font.size": 10.5,
    "axes.labelsize": 11,
    "axes.titlesize": 11,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 7.8,

    "axes.linewidth": 1.0,

    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.top": True,
    "ytick.right": True,

    "xtick.major.size": 4,
    "ytick.major.size": 4,
    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,

    "mathtext.fontset": "stix",

    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# ============================================================
# 5. General helpers
# ============================================================

def load_scalar_table(path):

    df = pd.read_csv(path)

    required = {
        "id",
        "family",
        "value_ev",
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"\n{path}\n"
            f"Missing columns: {missing}\n"
            f"Available columns: {list(df.columns)}"
        )

    return df[
        [
            "id",
            "family",
            "value_ev",
        ]
    ].copy()


def load_metadata(task_id):

    for root in METADATA_ROOTS:

        path = root / task_id / "metadata.json"

        if path.exists():
            with open(
                path,
                "r",
                encoding="utf-8"
            ) as f:
                return json.load(f)

    raise FileNotFoundError(
        f"No metadata.json found for {task_id}"
    )


def recursive_find(obj, key_names):

    if isinstance(obj, dict):

        for key, value in obj.items():

            if key.lower() in key_names:
                return value

        for value in obj.values():

            result = recursive_find(
                value,
                key_names
            )

            if result is not None:
                return result

    elif isinstance(obj, list):

        for value in obj:

            result = recursive_find(
                value,
                key_names
            )

            if result is not None:
                return result

    return None


def recursive_numeric(obj, key_names):

    value = recursive_find(
        obj,
        key_names
    )

    if isinstance(
        value,
        (int, float)
    ):
        return float(value)

    return None


# ============================================================
# 6. DFT scalar validation
# ============================================================

dft = load_scalar_table(
    DFT_VALIDATION_FILE
)

dft = dft.rename(
    columns={
        "value_ev": "dft_value_ev"
    }
)

merged = dft.copy()


# ============================================================
# 7. Three v6 MACE models
# ============================================================

for seed, path in MACE_VALIDATION_FILES.items():

    pred = load_scalar_table(path)

    pred = pred.rename(
        columns={
            "value_ev":
                f"seed{seed}_value_ev"
        }
    )

    merged = merged.merge(
        pred[
            [
                "id",
                "family",
                f"seed{seed}_value_ev",
            ]
        ],
        on=[
            "id",
            "family",
        ],
        how="inner",
    )


seed_cols = [
    "seed11_value_ev",
    "seed29_value_ev",
    "seed47_value_ev",
]

merged["mace_mean_ev"] = (
    merged[seed_cols]
    .mean(axis=1)
)

merged["mace_std_ev"] = (
    merged[seed_cols]
    .std(
        axis=1,
        ddof=1
    )
)


# ============================================================
# 8. Extract actual V/V0 for EOS
# ============================================================

def extract_eos_information(task_id):
    """
    Extract the physical EOS coordinate V/V0 from metadata.

    Supported metadata definitions:

    1. volume_strain = (V - V0) / V0
       -> V/V0 = 1 + volume_strain

    2. Direct volume ratio
       volume_ratio, v_over_v0, relative_volume,
       volume_factor, volume_scale

    3. Lattice scaling a/a0
       lattice_scale, lattice_ratio, a_over_a0
       -> V/V0 = (a/a0)^3

    4. Linear hydrostatic strain
       hydrostatic_strain, isotropic_strain,
       linear_strain
       -> V/V0 = (1 + strain)^3

    5. Absolute cell volume
       volume_a3, volume_ang3, volume_angstrom3,
       cell_volume, volume
       -> normalized later using V0
    """

    meta = load_metadata(task_id)

    # ========================================================
    # 1. Volume strain: ΔV / V0
    # ========================================================

    volume_strain = recursive_numeric(
        meta,
        {
            "volume_strain",
            "volumetric_strain",
        }
    )

    if volume_strain is not None:

        return {
            "kind": "ratio",
            "value": 1.0 + volume_strain,
        }


    # ========================================================
    # 2. Direct V/V0
    # ========================================================

    direct_ratio = recursive_numeric(
        meta,
        {
            "volume_ratio",
            "v_over_v0",
            "relative_volume",
            "volume_factor",
            "volume_scale",
        }
    )

    if direct_ratio is not None:

        return {
            "kind": "ratio",
            "value": direct_ratio,
        }


    # ========================================================
    # 3. Lattice scaling a/a0
    # ========================================================

    lattice_ratio = recursive_numeric(
        meta,
        {
            "lattice_scale",
            "lattice_ratio",
            "a_over_a0",
        }
    )

    if lattice_ratio is not None:

        return {
            "kind": "ratio",
            "value": lattice_ratio ** 3,
        }


    # ========================================================
    # 4. Linear hydrostatic strain
    # ========================================================

    linear_strain = recursive_numeric(
        meta,
        {
            "hydrostatic_strain",
            "isotropic_strain",
            "linear_strain",
        }
    )

    if linear_strain is not None:

        return {
            "kind": "ratio",
            "value": (1.0 + linear_strain) ** 3,
        }


    # ========================================================
    # 5. Absolute volume
    # ========================================================

    absolute_volume = recursive_numeric(
        meta,
        {
            "volume_a3",
            "volume_ang3",
            "volume_angstrom3",
            "cell_volume",
            "volume",
        }
    )

    if absolute_volume is not None:

        return {
            "kind": "absolute_volume",
            "value": absolute_volume,
        }


    # ========================================================
    # Nothing recognized
    # ========================================================

    raise RuntimeError(
        f"\nCannot determine physical EOS volume for:\n"
        f"{task_id}\n\n"
        "Metadata content:\n"
        f"{json.dumps(meta, indent=2, ensure_ascii=False)}"
    )

# ============================================================
# 9. Prepare EOS
# ============================================================

eos = merged[
    merged["family"] == "eos"
].copy()

if eos.empty:
    raise RuntimeError(
        "No EOS validation entries found."
    )


eos_info = [
    extract_eos_information(task)
    for task in eos["id"]
]

kinds = {
    item["kind"]
    for item in eos_info
}


# --------------------------------------------
# Direct ratios
# --------------------------------------------

if kinds == {"ratio"}:

    eos["v_over_v0"] = [
        item["value"]
        for item in eos_info
    ]


# --------------------------------------------
# Absolute volumes
# Normalize by volume at minimum DFT energy
# --------------------------------------------

elif kinds == {"absolute_volume"}:

    eos["volume_abs"] = [
        item["value"]
        for item in eos_info
    ]

    equilibrium_index = (
        eos["dft_value_ev"]
        .idxmin()
    )

    v0 = float(
        eos.loc[
            equilibrium_index,
            "volume_abs"
        ]
    )

    eos["v_over_v0"] = (
        eos["volume_abs"]
        / v0
    )


else:

    raise RuntimeError(
        "\nMixed EOS coordinate representations were detected:\n"
        f"{kinds}\n"
        "Please inspect the metadata before plotting."
    )


eos = eos.sort_values(
    "v_over_v0"
)

eos["dft_rel_ev"] = (
    eos["dft_value_ev"]
    - eos["dft_value_ev"].min()
)

eos["mace_rel_ev"] = (
    eos["mace_mean_ev"]
    - eos["mace_mean_ev"].min()
)


print(
    "\n=== EOS coordinates ==="
)

print(
    eos[
        [
            "id",
            "v_over_v0",
            "dft_rel_ev",
            "mace_rel_ev",
            "mace_std_ev",
        ]
    ].to_string(
        index=False
    )
)


# ============================================================
# 10. Elastic data
# ============================================================

def extract_strain(task_id):

    meta = load_metadata(task_id)

    keys = {
        "strain",
        "epsilon",
        "strain_value",
        "strain_amplitude",
        "deformation_value",
    }

    value = recursive_numeric(
        meta,
        keys
    )

    if value is None:
        raise RuntimeError(
            f"Cannot determine strain for {task_id}"
        )

    return value


def elastic_mode(task_id):

    if "shear_xy" in task_id:
        return "Shear"

    if "uniaxial_x" in task_id:
        return "Uniaxial x"

    if "uniaxial_y" in task_id:
        return "Uniaxial y"

    return "Other"


elastic = merged[
    merged["family"] == "elastic"
].copy()

if elastic.empty:
    raise RuntimeError(
        "No elastic validation entries found."
    )

elastic["strain"] = (
    elastic["id"]
    .apply(extract_strain)
)

elastic["mode"] = (
    elastic["id"]
    .apply(elastic_mode)
)


# ============================================================
# 11. Load NEB path data
# ============================================================

required_neb_columns = {
    "task_id",
    "element",
    "image",
    "reaction_coordinate",
    "dft_relative_energy_ev",
    "mace_relative_energy_ev",
    "relative_energy_error_ev",
}

neb_seed_tables = {}


for seed, path in NEB_PATH_FILES.items():

    df = pd.read_csv(path)

    print(
        f"\nNEB seed {seed} columns:\n"
        f"{list(df.columns)}"
    )

    missing = (
        required_neb_columns
        - set(df.columns)
    )

    if missing:
        raise ValueError(
            f"{path} is missing columns:\n"
            f"{missing}"
        )

    current = df[
        [
            "task_id",
            "element",
            "image",
            "reaction_coordinate",
            "dft_relative_energy_ev",
            "mace_relative_energy_ev",
        ]
    ].copy()

    current = current.rename(
        columns={
            "task_id":
                f"task_id_seed{seed}",

            "reaction_coordinate":
                f"reaction_coordinate_seed{seed}",

            "dft_relative_energy_ev":
                f"dft_seed{seed}_relative_energy_ev",

            "mace_relative_energy_ev":
                f"mace_seed{seed}_relative_energy_ev",
        }
    )

    numeric_columns = [
        "image",
        f"reaction_coordinate_seed{seed}",
        f"dft_seed{seed}_relative_energy_ev",
        f"mace_seed{seed}_relative_energy_ev",
    ]

    for col in numeric_columns:

        current[col] = pd.to_numeric(
            current[col],
            errors="coerce"
        )

    current["element"] = (
        current["element"]
        .astype(str)
        .str.strip()
    )

    current = current.dropna()

    neb_seed_tables[seed] = current


# ============================================================
# 12. Merge NEB ensemble by element + image
# ============================================================

neb_path = (
    neb_seed_tables[11]
    .copy()
)

for seed in [29, 47]:

    temp = (
        neb_seed_tables[seed]
        .copy()
    )

    keep_columns = [
        f"task_id_seed{seed}",
        "element",
        "image",
        f"reaction_coordinate_seed{seed}",
        f"dft_seed{seed}_relative_energy_ev",
        f"mace_seed{seed}_relative_energy_ev",
    ]

    neb_path = neb_path.merge(
        temp[
            keep_columns
        ],
        on=[
            "element",
            "image",
        ],
        how="inner",
        validate="one_to_one",
    )


# ============================================================
# 13. DFT consistency across seed files
# ============================================================

for seed in [29, 47]:

    diff = np.abs(
        neb_path[
            f"dft_seed{seed}_relative_energy_ev"
        ]
        -
        neb_path[
            "dft_seed11_relative_energy_ev"
        ]
    )

    max_diff = float(
        diff.max()
    )

    print(
        f"DFT consistency seed11 vs seed{seed}: "
        f"{max_diff:.3e} eV"
    )

    if max_diff > 1.0e-8:
        raise RuntimeError(
            "DFT NEB reference data differ between "
            f"seed files by {max_diff:.6e} eV."
        )


# ============================================================
# 14. MACE NEB ensemble
# ============================================================

mace_neb_cols = [
    "mace_seed11_relative_energy_ev",
    "mace_seed29_relative_energy_ev",
    "mace_seed47_relative_energy_ev",
]

neb_path[
    "mace_mean_relative_energy_ev"
] = (
    neb_path[
        mace_neb_cols
    ].mean(axis=1)
)

neb_path[
    "mace_std_relative_energy_ev"
] = (
    neb_path[
        mace_neb_cols
    ].std(
        axis=1,
        ddof=1
    )
)

neb_path[
    "dft_relative_energy_ev"
] = (
    neb_path[
        "dft_seed11_relative_energy_ev"
    ]
)

neb_path[
    "reaction_coordinate"
] = (
    neb_path[
        "reaction_coordinate_seed11"
    ]
)

neb_path[
    "path_error_ev"
] = (
    neb_path[
        "mace_mean_relative_energy_ev"
    ]
    -
    neb_path[
        "dft_relative_energy_ev"
    ]
)


# ============================================================
# 15. Reconstruct full NEB pathways
# ============================================================

preferred_elements = [
    "Al",
    "Cu",
    "Mg",
    "Zn",
]

processed_paths = []


print(
    "\n=== NEB image counts ==="
)


for element in preferred_elements:

    sub = (
        neb_path[
            neb_path["element"] == element
        ]
        .sort_values("image")
        .copy()
    )

    if sub.empty:

        print(
            f"{element}: no data"
        )

        continue


    if sub["image"].duplicated().any():

        raise RuntimeError(
            f"Duplicated images found for {element}"
        )


    print(
        f"{element}: "
        f"{len(sub)} images, "
        f"{sub['image'].tolist()}"
    )


    # --------------------------------------------
    # Prefer actual reaction coordinate
    # --------------------------------------------

    coord = (
        sub["reaction_coordinate"]
        .to_numpy(dtype=float)
    )

    if (
        len(np.unique(coord)) > 1
        and np.ptp(coord) > 1.0e-12
    ):

        s = (
            coord - coord.min()
        ) / (
            coord.max() - coord.min()
        )

    else:

        image = (
            sub["image"]
            .to_numpy(dtype=float)
        )

        s = (
            image - image.min()
        ) / (
            image.max() - image.min()
        )


    sub["s"] = s

    sub["dft_rel_ev"] = (
        sub[
            "dft_relative_energy_ev"
        ]
    )

    sub["mace_rel_ev"] = (
        sub[
            "mace_mean_relative_energy_ev"
        ]
    )

    sub["mace_std_energy_ev"] = (
        sub[
            "mace_std_relative_energy_ev"
        ]
    )

    processed_paths.append(
        sub
    )


neb_plot = pd.concat(
    processed_paths,
    ignore_index=True
)


# ============================================================
# 16. Path statistics
# ============================================================

all_errors = (
    neb_plot[
        "path_error_ev"
    ].to_numpy(dtype=float)
)

path_mae = np.mean(
    np.abs(all_errors)
)

path_rmse = np.sqrt(
    np.mean(
        all_errors ** 2
    )
)

path_max = np.max(
    np.abs(all_errors)
)


print(
    "\n=== Pathwise energy errors ==="
)

for element in preferred_elements:

    sub = neb_plot[
        neb_plot["element"] == element
    ]

    if sub.empty:
        continue

    error = (
        sub[
            "path_error_ev"
        ].to_numpy(dtype=float)
    )

    print(
        f"{element:>2s}: "
        f"MAE = {np.mean(np.abs(error)):.6f} eV, "
        f"RMSE = {np.sqrt(np.mean(error**2)):.6f} eV, "
        f"Max = {np.max(np.abs(error)):.6f} eV"
    )


# ============================================================
# 17. Create figure
# ============================================================

fig, axes = plt.subplots(
    2,
    2,
    figsize=(10.7, 7.7)
)

ax_a, ax_b, ax_c, ax_d = (
    axes.ravel()
)


# ============================================================
# Fig. 5(a)
# EOS with physical V/V0
# ============================================================

ax_a.plot(
    eos["v_over_v0"],
    eos["dft_rel_ev"],
    marker="o",
    markersize=5.2,
    linewidth=1.25,
    label="DFT",
)

ax_a.errorbar(
    eos["v_over_v0"],
    eos["mace_rel_ev"],
    yerr=eos["mace_std_ev"],
    marker="s",
    markersize=4.6,
    linestyle="--",
    linewidth=1.05,
    capsize=3,
    label="MACE ensemble",
)

ax_a.set_xlabel(
    r"$V/V_0$"
)

ax_a.set_ylabel(
    r"Relative energy, "
    r"$E-E_{\min}$ (eV)"
)

ax_a.set_title(
    "Equation-of-state response"
)

ax_a.legend(
    frameon=False,
    loc="upper left"
)


# ============================================================
# Fig. 5(b)
# Elastic deformation
# ============================================================

elastic_markers = {
    "Shear": "o",
    "Uniaxial x": "s",
    "Uniaxial y": "^",
}


for mode in [
    "Shear",
    "Uniaxial x",
    "Uniaxial y",
]:

    sub = (
        elastic[
            elastic["mode"] == mode
        ]
        .sort_values("strain")
        .copy()
    )

    if sub.empty:
        continue


    line, = ax_b.plot(
        sub["strain"],
        sub["dft_value_ev"],
        marker=elastic_markers[mode],
        markersize=4.8,
        linewidth=1.05,
        label=f"{mode}, DFT",
    )

    color = line.get_color()


    ax_b.errorbar(
        sub["strain"],
        sub["mace_mean_ev"],
        yerr=sub["mace_std_ev"],
        marker=elastic_markers[mode],
        markersize=4.2,
        linestyle="--",
        linewidth=1.0,
        capsize=2.5,
        color=color,
        label=f"{mode}, MACE",
    )


ax_b.set_xlabel(
    r"Strain, $\varepsilon$"
)

ax_b.set_ylabel(
    r"Relative energy, "
    r"$\Delta E$ (eV)"
)

ax_b.set_title(
    "Energy response to elastic deformation"
)

ax_b.legend(
    frameon=False,
    fontsize=6.9,
    ncol=2,
    loc="upper left",
)


# ============================================================
# Fig. 5(c)
# Migration energy profiles
# ============================================================

element_markers = {
    "Al": "o",
    "Cu": "s",
    "Mg": "^",
    "Zn": "D",
}

element_colors = {}


for element in preferred_elements:

    sub = (
        neb_plot[
            neb_plot["element"] == element
        ]
        .sort_values("s")
        .copy()
    )

    if sub.empty:
        continue


    # DFT
    line, = ax_c.plot(
        sub["s"],
        sub["dft_rel_ev"],
        marker=element_markers[element],
        markersize=4.5,
        linewidth=1.25,
    )

    color = line.get_color()

    element_colors[
        element
    ] = color


    # MACE ensemble
    ax_c.plot(
        sub["s"],
        sub["mace_rel_ev"],
        marker=element_markers[element],
        markersize=3.7,
        linestyle="--",
        linewidth=1.05,
        color=color,
    )


    # Ensemble uncertainty
    ax_c.fill_between(
        sub["s"],
        (
            sub["mace_rel_ev"]
            - sub["mace_std_energy_ev"]
        ),
        (
            sub["mace_rel_ev"]
            + sub["mace_std_energy_ev"]
        ),
        color=color,
        alpha=0.10,
        linewidth=0,
    )


ax_c.set_xlim(
    -0.03,
    1.03
)

ax_c.set_xticks(
    [
        0.00,
        0.25,
        0.50,
        0.75,
        1.00,
    ]
)

ax_c.set_xlabel(
    "Normalized reaction coordinate"
)

ax_c.set_ylabel(
    r"Relative energy, "
    r"$E-E_i$ (eV)"
)

ax_c.set_title(
    "Migration energy profiles"
)


# --------------------------------------------
# Compact element legend
# --------------------------------------------

element_handles = []

for element in preferred_elements:

    if element not in element_colors:
        continue

    element_handles.append(
        Line2D(
            [0],
            [0],
            marker=element_markers[element],
            linestyle="none",
            color=element_colors[element],
            markersize=5,
            label=element,
        )
    )


leg1 = ax_c.legend(
    handles=element_handles,
    frameon=False,
    ncol=2,
    loc="upper left",
    fontsize=7.2,
)

ax_c.add_artist(
    leg1
)


# --------------------------------------------
# Method legend
# --------------------------------------------

method_handles = [
    Line2D(
        [0],
        [0],
        linestyle="-",
        linewidth=1.2,
        color="black",
        label="DFT",
    ),
    Line2D(
        [0],
        [0],
        linestyle="--",
        linewidth=1.2,
        color="black",
        label="MACE ensemble",
    ),
]

ax_c.legend(
    handles=method_handles,
    frameon=False,
    loc="upper right",
    fontsize=7.2,
)


# ============================================================
# Fig. 5(d)
# Pathwise MACE-DFT error
# ============================================================

for element in preferred_elements:

    sub = (
        neb_plot[
            neb_plot["element"] == element
        ]
        .sort_values("s")
        .copy()
    )

    if sub.empty:
        continue

    color = element_colors[element]


    ax_d.plot(
        sub["s"],
        sub["path_error_ev"],
        marker=element_markers[element],
        markersize=4.3,
        linewidth=1.15,
        color=color,
        label=element,
    )


    ax_d.fill_between(
        sub["s"],
        (
            sub["path_error_ev"]
            - sub["mace_std_energy_ev"]
        ),
        (
            sub["path_error_ev"]
            + sub["mace_std_energy_ev"]
        ),
        color=color,
        alpha=0.10,
        linewidth=0,
    )


ax_d.axhline(
    0.0,
    linestyle="--",
    linewidth=0.9,
)

ax_d.set_xlim(
    -0.03,
    1.03
)

ax_d.set_xticks(
    [
        0.00,
        0.25,
        0.50,
        0.75,
        1.00,
    ]
)

ax_d.set_xlabel(
    "Normalized reaction coordinate"
)

ax_d.set_ylabel(
    r"$\Delta E_{\mathrm{path}}"
    r"=E_{\mathrm{MACE}}"
    r"-E_{\mathrm{DFT}}$ (eV)"
)

ax_d.set_title(
    "Pathwise energy deviation"
)

ax_d.legend(
    frameon=False,
    ncol=2,
    loc="upper left",
)


ax_d.text(
    0.97,
    0.96,
    (
        f"MAE = {path_mae:.3f} eV\n"
        f"RMSE = {path_rmse:.3f} eV\n"
        f"Max = {path_max:.3f} eV"
    ),
    transform=ax_d.transAxes,
    ha="right",
    va="top",
    fontsize=8.2,
)


# ============================================================
# 18. Panel labels
# ============================================================

for ax, label in zip(
    axes.ravel(),
    [
        "(a)",
        "(b)",
        "(c)",
        "(d)",
    ]
):

    ax.text(
        0.025,
        0.95,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11.5,
        fontweight="bold",
        zorder=10,
    )


# ============================================================
# 19. Common formatting
# ============================================================

for ax in axes.ravel():

    ax.tick_params(
        which="both",
        direction="in",
        top=True,
        right=True,
    )

    for spine in ax.spines.values():
        spine.set_linewidth(1.0)


# ============================================================
# 20. Layout
# ============================================================

fig.subplots_adjust(
    left=0.09,
    right=0.975,
    bottom=0.09,
    top=0.955,
    wspace=0.29,
    hspace=0.33,
)


# ============================================================
# 21. Save
# ============================================================

fig.savefig(
    OUT_PNG,
    dpi=600,
    bbox_inches="tight",
)

fig.savefig(
    OUT_PDF,
    bbox_inches="tight",
)

fig.savefig(
    OUT_SVG,
    bbox_inches="tight",
)


print(
    "\nSaved final Fig. 5:"
)

print(
    " ",
    OUT_PNG
)

print(
    " ",
    OUT_PDF
)

print(
    " ",
    OUT_SVG
)


print(
    f"\nOverall pathwise MAE  = "
    f"{path_mae:.6f} eV"
)

print(
    f"Overall pathwise RMSE = "
    f"{path_rmse:.6f} eV"
)

print(
    f"Overall maximum error = "
    f"{path_max:.6f} eV"
)


plt.show()