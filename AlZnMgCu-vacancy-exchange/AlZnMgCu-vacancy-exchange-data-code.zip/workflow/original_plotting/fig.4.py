#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager


# ============================================================
# 1. Paths
# ============================================================

ROOT = Path("work/ensemble_validation_v6")

SUMMARY_FILES = {
    11: ROOT / "validation_summary_seed11.csv",
    29: ROOT / "validation_summary_seed29.csv",
    47: ROOT / "validation_summary_seed47.csv",
}

VACANCY_FILE = ROOT / "committee_vacancy.csv"
NEB_FILE = ROOT / "committee_neb.csv"
GATE_FILE = ROOT / "ensemble_gate.csv"

OUT_PNG = Path("Fig4_final_ensemble_validation.png")
OUT_PDF = Path("Fig4_final_ensemble_validation.pdf")
OUT_SVG = Path("Fig4_final_ensemble_validation.svg")


# ============================================================
# 2. Check files
# ============================================================

required_files = list(SUMMARY_FILES.values()) + [
    VACANCY_FILE,
    NEB_FILE,
    GATE_FILE,
]

for f in required_files:
    if not f.exists():
        raise FileNotFoundError(f"Missing required file: {f}")


# ============================================================
# 3. Times New Roman for WSL
# ============================================================

font_files = [
    Path("/mnt/c/Windows/Fonts/times.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbd.ttf"),
    Path("/mnt/c/Windows/Fonts/timesi.ttf"),
    Path("/mnt/c/Windows/Fonts/timesbi.ttf"),
]

for f in font_files:
    if f.exists():
        font_manager.fontManager.addfont(str(f))

if font_files[0].exists():
    main_font = font_manager.FontProperties(
        fname=str(font_files[0])
    ).get_name()
else:
    main_font = "DejaVu Serif"
    print("Warning: Times New Roman not found. Using DejaVu Serif.")

print("Using font:", main_font)


# ============================================================
# 4. Publication style
# ============================================================

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": [main_font],

    "font.size": 10.5,
    "axes.labelsize": 11,
    "axes.titlesize": 11,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "legend.fontsize": 8.2,

    "axes.linewidth": 1.0,

    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.top": True,
    "ytick.right": True,

    "xtick.major.size": 4,
    "ytick.major.size": 4,
    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,

    "mathtext.fontset": "stix",

    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
})


# ============================================================
# 5. Load data
# ============================================================

summaries = {}

for seed, path in SUMMARY_FILES.items():
    df = pd.read_csv(path)
    df["seed"] = seed
    summaries[seed] = df

vacancy = pd.read_csv(VACANCY_FILE)
neb = pd.read_csv(NEB_FILE)
gate = pd.read_csv(GATE_FILE)


# ============================================================
# 6. Prepare vacancy data
# ============================================================

gate_plot = gate.copy()

gate_plot["seed"] = (
    gate_plot["model"]
    .str.replace("seed", "", regex=False)
    .astype(int)
)

gate_plot = gate_plot.sort_values("seed")

dft_vacancy = float(
    vacancy.iloc[0]["dft_vacancy_formation_ev"]
)

ensemble_vacancy = float(
    vacancy.iloc[0]["ensemble_mean_ev"]
)

ensemble_vacancy_std = float(
    vacancy.iloc[0]["ensemble_std_ev"]
)


# ============================================================
# 7. Prepare NEB data
# ============================================================

elements = neb["element"].tolist()
x_neb = np.arange(len(elements))

neb_error = (
    neb["ensemble_mean_ev"]
    - neb["dft_barrier_ev"]
)

neb_abs_error = np.abs(neb_error)

neb_mae = neb_abs_error.mean()


# ============================================================
# 8. Create figure
# ============================================================

fig, axes = plt.subplots(
    2,
    2,
    figsize=(10.4, 7.5)
)

ax_a, ax_b, ax_c, ax_d = axes.ravel()


# ============================================================
# Fig. 4(a)
# Property-specific RMSE
# ============================================================

families = [
    "eos",
    "elastic",
    "substitution_delta",
    "binding",
    "vacancy",
]

family_labels = [
    "EOS",
    "Elastic",
    "Substitution",
    "Binding",
    "Vacancy",
]

x = np.arange(len(families))

seed_offsets = {
    11: -0.13,
    29: 0.00,
    47: 0.13,
}


for seed in [11, 29, 47]:

    current = summaries[seed].set_index("family")

    values = [
        float(current.loc[f, "rmse"])
        for f in families
    ]

    ax_a.scatter(
        x + seed_offsets[seed],
        values,
        s=38,
        label=f"Seed {seed}",
        zorder=3
    )


# Ensemble mean ± SD of RMSE across seeds
mean_rmse = []
std_rmse = []

for family in families:

    vals = np.array([
        float(
            summaries[s]
            .set_index("family")
            .loc[family, "rmse"]
        )
        for s in [11, 29, 47]
    ])

    mean_rmse.append(vals.mean())
    std_rmse.append(vals.std(ddof=1))


mean_rmse = np.array(mean_rmse)
std_rmse = np.array(std_rmse)

ax_a.errorbar(
    x,
    mean_rmse,
    yerr=std_rmse,
    fmt="D",
    markersize=5.5,
    capsize=3.5,
    linewidth=1.0,
    label="Mean ± SD",
    zorder=4
)

ax_a.set_yscale("log")

ax_a.set_xticks(x)
ax_a.set_xticklabels(
    family_labels,
    rotation=20,
    ha="right"
)

ax_a.set_ylabel("RMSE (eV)")
ax_a.set_title("Property-specific prediction errors")

ax_a.legend(
    frameon=False,
    loc="upper left",
    ncol=1
)


# ============================================================
# Fig. 4(b)
# Vacancy formation energy
# ============================================================

seed_x = np.arange(3)

ax_b.scatter(
    seed_x,
    gate_plot["predicted_vacancy_formation_ev"],
    s=48,
    label="Individual MACE",
    zorder=3
)

# DFT reference
ax_b.axhline(
    dft_vacancy,
    linestyle="--",
    linewidth=1.1,
    label="DFT"
)

# Ensemble mean ± SD
ax_b.errorbar(
    3,
    ensemble_vacancy,
    yerr=ensemble_vacancy_std,
    fmt="D",
    markersize=6.5,
    capsize=4,
    linewidth=1.0,
    label="Ensemble mean ± SD",
    zorder=4
)

ax_b.set_xticks([0, 1, 2, 3])

ax_b.set_xticklabels([
    "Seed 11",
    "Seed 29",
    "Seed 47",
    "Ensemble"
])

ax_b.set_ylabel(
    r"Vacancy formation energy, $E_{\mathrm{f}}^{\mathrm{V}}$ (eV)"
)

ax_b.set_title("Vacancy formation energy")


# DFT annotation
ax_b.text(
    0.03,
    dft_vacancy + 0.002,
    rf"DFT = {dft_vacancy:.3f} eV",
    transform=ax_b.get_yaxis_transform(),
    va="bottom",
    fontsize=8.5
)


# Ensemble annotation
ax_b.annotate(
    rf"${ensemble_vacancy:.3f}\pm{ensemble_vacancy_std:.3f}$ eV",
    xy=(3, ensemble_vacancy),
    xytext=(-5, 20),
    textcoords="offset points",
    ha="center",
    fontsize=8.5
)

ax_b.legend(
    frameon=False,
    loc="lower right"
)


# ============================================================
# Fig. 4(c)
# Migration barrier validation
# ============================================================

offsets = {
    "DFT": -0.24,
    "seed11": -0.10,
    "seed29": 0.00,
    "seed47": 0.10,
    "ensemble": 0.24,
}

ax_c.scatter(
    x_neb + offsets["DFT"],
    neb["dft_barrier_ev"],
    s=52,
    marker="o",
    label="DFT",
    zorder=5
)

ax_c.scatter(
    x_neb + offsets["seed11"],
    neb["seed11_barrier_ev"],
    s=36,
    label="Seed 11",
    zorder=3
)

ax_c.scatter(
    x_neb + offsets["seed29"],
    neb["seed29_barrier_ev"],
    s=36,
    label="Seed 29",
    zorder=3
)

ax_c.scatter(
    x_neb + offsets["seed47"],
    neb["seed47_barrier_ev"],
    s=36,
    label="Seed 47",
    zorder=3
)

ax_c.errorbar(
    x_neb + offsets["ensemble"],
    neb["ensemble_mean_ev"],
    yerr=neb["ensemble_std_ev"],
    fmt="D",
    markersize=5.8,
    capsize=3.5,
    linewidth=1.0,
    label="Ensemble mean ± SD",
    zorder=4
)

ax_c.set_xticks(x_neb)
ax_c.set_xticklabels(elements)

ax_c.set_ylabel(
    r"Migration barrier, $E_{\mathrm{m}}$ (eV)"
)

ax_c.set_title("Migration-barrier validation")

ax_c.legend(
    frameon=False,
    ncol=2,
    loc="lower left"
)


# ============================================================
# Fig. 4(d)
# Signed ensemble-vs-DFT barrier error
# ============================================================

ax_d.axhline(
    0,
    linestyle="--",
    linewidth=1.0,
    zorder=1
)

ax_d.errorbar(
    x_neb,
    neb_error,
    yerr=neb["ensemble_std_ev"],
    fmt="o",
    markersize=6,
    capsize=4,
    linewidth=1.0,
    zorder=3
)

ax_d.set_xticks(x_neb)
ax_d.set_xticklabels(elements)

ax_d.set_ylabel(
    r"$\Delta E_{\mathrm{m}}"
    r"=E_{\mathrm{m}}^{\mathrm{ensemble}}"
    r"-E_{\mathrm{m}}^{\mathrm{DFT}}$ (eV)"
)

ax_d.set_title("Signed migration-barrier error")


# Annotate signed errors
for i, value in enumerate(neb_error):

    if value >= 0:
        offset_y = 8
        va = "bottom"
    else:
        offset_y = -10
        va = "top"

    ax_d.annotate(
        f"{value:+.3f}",
        xy=(i, value),
        xytext=(0, offset_y),
        textcoords="offset points",
        ha="center",
        va=va,
        fontsize=8.5
    )


# Overall MAE
ax_d.text(
    0.97,
    0.95,
    rf"MAE = {neb_mae:.3f} eV",
    transform=ax_d.transAxes,
    ha="right",
    va="top",
    fontsize=9
)


# Symmetric y range around zero
err_max = np.max(
    np.abs(neb_error)
    + neb["ensemble_std_ev"].to_numpy()
)

ylim = max(0.09, err_max * 1.25)

ax_d.set_ylim(
    -ylim,
    ylim
)


# ============================================================
# 9. Panel labels
# ============================================================

for ax, label in zip(
    [ax_a, ax_b, ax_c, ax_d],
    ["(a)", "(b)", "(c)", "(d)"]
):

    ax.text(
        0.025,
        0.955,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11.5,
        fontweight="bold"
    )


# ============================================================
# 10. Common formatting
# ============================================================

for ax in axes.ravel():

    for spine in ax.spines.values():
        spine.set_linewidth(1.0)

    ax.tick_params(
        which="both",
        direction="in",
        top=True,
        right=True
    )


# ============================================================
# 11. Layout
# ============================================================

fig.subplots_adjust(
    left=0.09,
    right=0.975,
    bottom=0.085,
    top=0.955,
    wspace=0.27,
    hspace=0.32
)


# ============================================================
# 12. Save
# ============================================================

fig.savefig(
    OUT_PNG,
    dpi=600,
    bbox_inches="tight"
)

fig.savefig(
    OUT_PDF,
    bbox_inches="tight"
)

fig.savefig(
    OUT_SVG,
    bbox_inches="tight"
)

print("\nSaved final Fig. 4:")
print(f"PNG : {OUT_PNG}")
print(f"PDF : {OUT_PDF}")
print(f"SVG : {OUT_SVG}")

print("\nNEB ensemble errors:")
for element, error, sd in zip(
    elements,
    neb_error,
    neb["ensemble_std_ev"]
):
    print(
        f"{element:>2s}: "
        f"error = {error:+.6f} eV, "
        f"ensemble SD = {sd:.6f} eV"
    )

print(
    f"\nOverall NEB ensemble MAE = "
    f"{neb_mae:.6f} eV"
)

plt.show()