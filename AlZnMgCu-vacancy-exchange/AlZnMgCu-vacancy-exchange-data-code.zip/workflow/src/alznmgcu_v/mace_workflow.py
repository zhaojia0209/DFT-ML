from __future__ import annotations

import csv
import json
import os
import shlex
from pathlib import Path

import numpy as np

from .config import dump_json, ensure_stage
from .atoms import write_extxyz
from .trajectory import read_lammps_dump


def _require_ase():
    try:
        from ase.io import read, write
    except ImportError as exc:
        raise RuntimeError("This command requires ASE: pip install ase") from exc
    return read, write


def _stress_matrix(value) -> np.ndarray:
    """Return stress as the 3x3 matrix expected in an extxyz info field."""
    stress = np.asarray(value, dtype=float)
    if stress.shape == (3, 3):
        return stress
    flat = stress.reshape(-1)
    if flat.size == 9:
        return flat.reshape(3, 3)
    if flat.size == 6:
        xx, yy, zz, yz, xz, xy = flat
        return np.asarray([[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]], dtype=float)
    raise ValueError(f"Stress must contain 6 or 9 values, received shape {stress.shape}")


def _normalize_reference_keys(atoms, frame_index: int):
    """Move ASE calculator results to collision-safe MACE reference keys.

    ASE >= 3.23 reserves energy/forces/stress when reading extxyz. MACE therefore
    cannot reliably retrieve those names from Atoms.info/arrays, most critically
    for IsolatedAtom E0 records. Store explicit REF_* values and detach the
    SinglePointCalculator before writing the train/valid/test files.
    """
    results = getattr(getattr(atoms, "calc", None), "results", {}) or {}
    energy = atoms.info.get("REF_energy", results.get("energy", atoms.info.get("energy")))
    forces = atoms.arrays.get("REF_forces", results.get("forces", atoms.arrays.get("forces")))
    stress = atoms.info.get("REF_stress", results.get("stress", atoms.info.get("stress")))
    missing = [
        name for name, value in (("energy", energy), ("forces", forces), ("stress", stress))
        if value is None
    ]
    if missing:
        raise ValueError(f"Frame {frame_index} is missing reference {', '.join(missing)}")
    energy = float(energy)
    forces = np.asarray(forces, dtype=float)
    stress = _stress_matrix(stress)
    if not np.isfinite(energy) or not np.all(np.isfinite(forces)) or not np.all(np.isfinite(stress)):
        raise ValueError(f"Frame {frame_index} contains non-finite reference data")
    if forces.shape != (len(atoms), 3):
        raise ValueError(
            f"Frame {frame_index} forces have shape {forces.shape}; expected {(len(atoms), 3)}"
        )
    atoms.info["REF_energy"] = energy
    atoms.arrays["REF_forces"] = forces
    atoms.info["REF_stress"] = stress
    atoms.info.pop("energy", None)
    atoms.info.pop("stress", None)
    atoms.arrays.pop("forces", None)
    atoms.calc = None
    return atoms


def split_dataset(cfg: dict, dataset: str | Path) -> dict[str, int]:
    read, write = _require_ase()
    frames = read(str(dataset), index=":")
    if not frames:
        raise ValueError(f"No frames found in {dataset}")
    frames = [_normalize_reference_keys(atoms, index) for index, atoms in enumerate(frames)]
    groups: dict[str, list] = {}
    required_train = []
    for index, atoms in enumerate(frames):
        if str(atoms.info.get("config_type", "")).lower() == "isolatedatom":
            required_train.append(atoms)
            continue
        group = str(atoms.info.get("group_id", atoms.info.get("task_id", index)))
        groups.setdefault(group, []).append(atoms)
    rng = np.random.default_rng(cfg["seed"])
    names = np.array(sorted(groups), dtype=object)
    rng.shuffle(names)
    mace = cfg["mace"]
    n_test = max(1, int(round(len(names) * mace["test_fraction"])))
    n_valid = max(1, int(round(len(names) * mace["valid_fraction"])))
    if n_test + n_valid >= len(names):
        raise ValueError("Dataset needs at least three independent group_id values")
    assignment = {}
    for group in names[:n_test]:
        assignment[str(group)] = "test"
    for group in names[n_test : n_test + n_valid]:
        assignment[str(group)] = "valid"
    for group in names[n_test + n_valid :]:
        assignment[str(group)] = "train"
    splits = {name: [] for name in ["train", "valid", "test"]}
    splits["train"].extend(required_train)
    for group, atoms_list in groups.items():
        for atoms in atoms_list:
            atoms.info["split"] = assignment[group]
            splits[assignment[group]].append(atoms)
    stage = ensure_stage(cfg, "02_mace")
    for name, subset in splits.items():
        write(stage / f"{name}.extxyz", subset, format="extxyz", write_results=False)
    dump_json(assignment, stage / "split_groups.json")
    summary = {name: len(items) for name, items in splits.items()}
    dump_json(summary, stage / "split_summary.json")
    isolated_energies = {
        atoms.get_chemical_symbols()[0]: float(atoms.info["REF_energy"])
        for atoms in required_train
        if len(atoms) == 1
    }
    dump_json(
        {
            "energy_key": "REF_energy",
            "forces_key": "REF_forces",
            "stress_key": "REF_stress",
            "isolated_atom_energies_ev": isolated_energies,
            "all_reference_values_finite": True,
        },
        stage / "reference_schema.json",
    )
    return summary


def make_training_commands(cfg: dict) -> Path:
    stage = ensure_stage(cfg, "02_mace")
    mace = cfg["mace"]
    runs = stage / "runs"
    runs.mkdir(parents=True, exist_ok=True)
    stage_rel = Path(os.path.relpath(stage, cfg["_project_root"])).as_posix()
    root_from_script = Path(os.path.relpath(cfg["_project_root"], stage)).as_posix()
    lines = ["#!/bin/bash", "set -euo pipefail",
             'SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"',
             f'cd "$SCRIPT_DIR/{root_from_script}"', ""]
    for seed in mace["seeds"]:
        name = f"alzmcv_seed{seed}"
        args = {
            "name": name, "seed": seed, "train_file": f"{stage_rel}/train.extxyz",
            "valid_file": f"{stage_rel}/valid.extxyz", "test_file": f"{stage_rel}/test.extxyz",
            "model": mace["model"], "r_max": mace["r_max"], "num_channels": mace["num_channels"],
            "max_L": mace["max_L"], "correlation": mace["correlation"],
            "batch_size": mace["batch_size"], "valid_batch_size": mace["valid_batch_size"],
            "max_num_epochs": mace["max_num_epochs"], "energy_weight": mace["energy_weight"],
            "forces_weight": mace["forces_weight"], "stress_weight": mace["stress_weight"],
            "loss": mace["loss"], "stage_two": mace["stage_two"],
            "start_stage_two": mace["start_stage_two"], "ema": mace["ema"],
            "ema_decay": mace["ema_decay"], "amsgrad": mace["amsgrad"],
            "error_table": "PerAtomRMSEstressvirials",
            "energy_key": "REF_energy", "forces_key": "REF_forces", "stress_key": "REF_stress",
            "default_dtype": "float64", "device": "cuda", "restart_latest": True,
            "results_dir": f"{stage_rel}/runs/{name}/results",
            "checkpoints_dir": f"{stage_rel}/runs/{name}/checkpoints",
            "model_dir": f"{stage_rel}/runs/{name}/models", "log_dir": f"{stage_rel}/runs/{name}/logs",
        }
        rendered = []
        for key, value in args.items():
            if isinstance(value, bool):
                if value:
                    rendered.append(f"--{key}")
            else:
                rendered.append(f"--{key}={shlex.quote(str(value))}")
        command = "mace_run_train " + " ".join(rendered)
        lines += [f"mkdir -p {shlex.quote(f'{stage_rel}/runs/{name}')}", command, ""]
    script = stage / "train_ensemble.sh"
    script.write_text("\n".join(lines), encoding="utf-8")
    slurm = mace["slurm"]
    gpu_line = f"#SBATCH --gpus={slurm['gpus']}\n" if int(slurm.get("gpus", 0)) else ""
    (stage / "job_train.slurm").write_text(
        f"#!/bin/bash\n#SBATCH --job-name=alzmcv_mace\n#SBATCH --partition={slurm['partition']}\n"
        f"#SBATCH --nodes={slurm['nodes']}\n#SBATCH --ntasks={slurm['ntasks']}\n{gpu_line}"
        f"#SBATCH --time={slurm['time']}\nset -euo pipefail\n"
        "bash \"$(dirname \"$0\")/train_ensemble.sh\"\n",
        encoding="utf-8",
    )
    return script


def make_pool_evaluation_commands(cfg: dict, pool: str, models: list[str]) -> Path:
    if len(models) < 2:
        raise ValueError("Active learning requires at least two independently trained models")
    stage = ensure_stage(cfg, "02_mace")
    predictions = stage / "pool_predictions"
    stage_rel = Path(os.path.relpath(stage, cfg["_project_root"])).as_posix()
    root_from_script = Path(os.path.relpath(cfg["_project_root"], stage)).as_posix()
    lines = ["#!/bin/bash", "set -euo pipefail",
             'SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"',
             f'cd "$SCRIPT_DIR/{root_from_script}"',
             f"mkdir -p {shlex.quote(f'{stage_rel}/pool_predictions')}", ""]
    for index, model in enumerate(models):
        output = f"{stage_rel}/pool_predictions/model_{index:02d}.extxyz"
        lines.append(
            "mace_eval_configs "
            f"--configs={shlex.quote(pool)} --model={shlex.quote(model)} "
            f"--output={shlex.quote(output)} --device=cuda --info_prefix=MACE_"
        )
    lines += ["", f"echo 'Predictions written to {stage_rel}/pool_predictions'"]
    script = stage / "evaluate_pool.sh"
    script.write_text("\n".join(lines) + "\n", encoding="utf-8")
    slurm = cfg["mace"]["slurm"]
    gpu_line = f"#SBATCH --gpus={slurm['gpus']}\n" if int(slurm.get("gpus", 0)) else ""
    (stage / "job_evaluate_pool.slurm").write_text(
        f"#!/bin/bash\n#SBATCH --job-name=alzmcv_al\n#SBATCH --partition={slurm['partition']}\n"
        f"#SBATCH --nodes={slurm['nodes']}\n#SBATCH --ntasks={slurm['ntasks']}\n{gpu_line}"
        f"#SBATCH --time={slurm['time']}\nset -euo pipefail\n"
        "bash \"$(dirname \"$0\")/evaluate_pool.sh\"\n",
        encoding="utf-8",
    )
    return script


def build_candidate_pool(
    cfg: dict, dump: str | Path, output: str | Path, stride: int = 10, max_frames: int | None = None
) -> Path:
    if stride <= 0:
        raise ValueError("stride must be positive")
    dump, output = Path(dump), Path(output)
    metadata_path = dump.parent / "metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.exists() else {}

    def selected_frames():
        selected = 0
        for frame_index, frame in enumerate(read_lammps_dump(dump, cfg["elements"])):
            if frame_index % stride:
                continue
            frame.info.update({"group_id": metadata.get("run_id", dump.parent.name),
                               "run_id": metadata.get("run_id", dump.parent.name),
                               "config_type": "active_learning_pool"})
            yield frame
            selected += 1
            if max_frames is not None and selected >= max_frames:
                break

    write_extxyz(selected_frames(), output)
    dump_json({"source_dump": str(dump.resolve()), "stride": stride, "max_frames": max_frames},
              output.with_suffix(".json"))
    return output


def _composition_descriptor(atoms, elements: list[str]) -> np.ndarray:
    symbols = atoms.get_chemical_symbols()
    n = max(len(symbols), 1)
    volume_atom = atoms.get_volume() / n
    fractions = [symbols.count(el) / n for el in elements]
    pos = atoms.get_positions()
    spread = np.std(pos, axis=0).tolist() if n > 1 else [0.0, 0.0, 0.0]
    return np.asarray([volume_atom, *fractions, *spread], dtype=float)


def _fps(features: np.ndarray, count: int, initial: list[int] | None = None) -> list[int]:
    if len(features) == 0 or count <= 0:
        return []
    scale = np.std(features, axis=0)
    scale[scale < 1e-12] = 1.0
    values = (features - np.mean(features, axis=0)) / scale
    selected = list(initial or [])
    if not selected:
        selected = [int(np.argmax(np.linalg.norm(values, axis=1)))]
    distances = np.min(
        [np.sum((values - values[index]) ** 2, axis=1) for index in selected], axis=0
    )
    while len(selected) < min(count, len(values)):
        distances[selected] = -1.0
        index = int(np.argmax(distances))
        selected.append(index)
        distances = np.minimum(distances, np.sum((values - values[index]) ** 2, axis=1))
    return selected


def select_active_learning(cfg: dict, predictions: list[str], output: str | Path) -> Path:
    """Select configurations from identically ordered ensemble extxyz predictions."""
    read, write = _require_ase()
    if len(predictions) < 2:
        raise ValueError("At least two ensemble prediction files are required")
    ensembles = [read(path, index=":") for path in predictions]
    lengths = {len(x) for x in ensembles}
    if len(lengths) != 1:
        raise ValueError("Ensemble prediction files contain different frame counts")
    n_frames = lengths.pop()
    uncertainty = []
    for frame_index in range(n_frames):
        energies = []
        forces = []
        for model_frames in ensembles:
            atoms = model_frames[frame_index]
            if "MACE_energy" in atoms.info:
                energy = float(atoms.info["MACE_energy"])
            elif "energy" in atoms.info:
                energy = float(atoms.info["energy"])
            else:
                energy = float(atoms.get_potential_energy())
            if "MACE_forces" in atoms.arrays:
                force = np.asarray(atoms.arrays["MACE_forces"])
            elif "forces" in atoms.arrays:
                force = np.asarray(atoms.arrays["forces"])
            else:
                force = np.asarray(atoms.get_forces())
            energies.append(energy / len(atoms))
            forces.append(force)
        force_std = np.std(np.stack(forces), axis=0)
        uncertainty.append({
            "frame": frame_index,
            "energy_std_ev_per_atom": float(np.std(energies)),
            "max_force_std_ev_per_angstrom": float(np.max(np.linalg.norm(force_std, axis=1))),
            "mean_force_std_ev_per_angstrom": float(np.mean(np.linalg.norm(force_std, axis=1))),
        })
    settings = cfg["mace"]["active_learning"]
    total = min(int(settings["select"]), n_frames)
    n_uncertain = min(total, int(round(total * settings["uncertainty_fraction"])))
    ranked = sorted(range(n_frames), key=lambda i: uncertainty[i]["max_force_std_ev_per_angstrom"], reverse=True)
    threshold = float(settings["min_force_std_ev_per_angstrom"])
    first = [i for i in ranked if uncertainty[i]["max_force_std_ev_per_angstrom"] >= threshold][:n_uncertain]
    features = np.vstack([_composition_descriptor(atoms, cfg["elements"]) for atoms in ensembles[0]])
    selected = _fps(features, total, initial=first)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    chosen = []
    for rank, index in enumerate(selected):
        atoms = ensembles[0][index].copy()
        atoms.calc = None
        atoms.info.update({"pool_index": index, "selection_rank": rank, **uncertainty[index]})
        chosen.append(atoms)
    write(output, chosen, format="extxyz")
    report = output.with_suffix(".csv")
    with report.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(uncertainty[0]))
        writer.writeheader()
        writer.writerows(uncertainty)
    dump_json({"models": predictions, "selected_indices": selected, "settings": settings}, output.with_suffix(".json"))
    return output
