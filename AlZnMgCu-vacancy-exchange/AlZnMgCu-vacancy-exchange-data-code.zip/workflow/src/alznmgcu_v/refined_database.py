from __future__ import annotations

from collections import Counter
from pathlib import Path

import numpy as np

from .atoms import Frame, decorate_alloy, fcc_conventional, minimum_image
from .config import dump_json, ensure_stage, stable_seed
from .vasp import write_campaign_files, write_vasp_task


def neighbor_shells(frame: Frame, center_index: int, shell_count: int = 4) -> dict[int, list[int]]:
    """Return periodic neighbor indices grouped into the first distance shells."""
    distances = []
    for index, position in enumerate(frame.positions):
        if index == center_index:
            continue
        delta = minimum_image(position - frame.positions[center_index], frame.cell)
        distances.append((float(np.linalg.norm(delta)), index))
    distances.sort()
    shells: dict[int, list[int]] = {}
    shell_distance = None
    shell = 0
    for distance, index in distances:
        if shell_distance is None or not np.isclose(distance, shell_distance, atol=1e-6):
            shell += 1
            shell_distance = distance
            if shell > shell_count:
                break
            shells[shell] = []
        shells[shell].append(index)
    if len(shells) != shell_count:
        raise ValueError(f"Requested {shell_count} shells but found {len(shells)}")
    return shells


def _remove_site(frame: Frame, vacancy_index: int) -> Frame:
    out = frame.copy()
    keep = np.ones(len(out.symbols), dtype=bool)
    keep[vacancy_index] = False
    out.symbols = [symbol for index, symbol in enumerate(out.symbols) if keep[index]]
    out.positions = out.positions[keep]
    out.ids = np.arange(1, len(out.symbols) + 1, dtype=int)
    out.info["vacancy_site_indices"] = [int(vacancy_index)]
    return out


def _displace(frame: Frame, sigma: float, seed: int) -> None:
    rng = np.random.default_rng(seed)
    frame.positions += rng.normal(0.0, sigma, frame.positions.shape)


def build_refined_database(cfg: dict, limit: int | None = None) -> Path:
    """Build a targeted, non-overwriting vacancy/solute database for the second DFT round."""
    if "refined_database" not in cfg:
        raise ValueError("Configuration is missing refined_database")
    stage = ensure_stage(cfg, "01_refined_database")
    tasks = stage / "tasks"
    tasks.mkdir(parents=True, exist_ok=True)
    rc = cfg["refined_database"]
    base = fcc_conventional(rc["supercell"], cfg["lattice"]["a0_angstrom"])
    sigmas = [float(value) for value in rc["displacement_sigma_angstrom"]]
    records: list[dict] = []

    def add(task_id: str, category: str, frame: Frame, seed: int, extra: dict) -> bool:
        if limit is not None and len(records) >= limit:
            return False
        metadata = {
            "task_id": task_id,
            "category": category,
            "config_type": extra.get("config_type", category),
            "group_id": extra.get("group_id", task_id),
            "seed": int(seed),
            "n_atoms": len(frame.symbols),
            "composition": {element: frame.symbols.count(element) for element in cfg["elements"]},
            "campaign": "refined_targeted_defects_v1",
            **extra,
        }
        write_vasp_task(
            frame,
            tasks / task_id,
            cfg,
            metadata,
            overrides=extra.get("vasp_overrides"),
        )
        records.append(metadata)
        return True

    # Add the four shear signs/directions absent from the original 17-strain campaign.
    missing_shears = [(0, 1, -0.02), (0, 2, 0.02), (1, 2, -0.02), (1, 2, 0.02)]
    for index, (axis_a, axis_b, epsilon) in enumerate(missing_shears):
        frame = base.copy()
        deformation = np.eye(3)
        deformation[axis_a, axis_b] = epsilon
        frame.cell = frame.cell @ deformation
        frame.positions = frame.positions @ deformation
        seed = stable_seed(cfg["seed"], "missing_shear", index)
        add(
            f"missing_shear_{index:04d}",
            "missing_shear",
            frame,
            seed,
            {"strain_type": f"shear_{axis_a}{axis_b}", "strain": epsilon},
        )

    # Pure-Al vacancy environments with four displacement amplitudes.
    for index in range(int(rc["vacancy_displaced_count"])):
        seed = stable_seed(cfg["seed"], "vacancy_displaced", index)
        rng = np.random.default_rng(seed)
        vacancy_index = int(rng.integers(len(base.symbols)))
        sigma = sigmas[index % len(sigmas)]
        frame = _remove_site(base, vacancy_index)
        _displace(frame, sigma, seed)
        add(
            f"vacancy_displaced_{index:04d}",
            "vacancy_displaced",
            frame,
            seed,
            {"vacancy_site_index": vacancy_index, "displacement_sigma_angstrom": sigma},
        )

    # Explicit X-vacancy pairs at the first through fourth fcc neighbor shells.
    local_index = 0
    for solute in rc["target_solutes"]:
        for shell in rc["solute_vacancy_shells"]:
            for variant in range(int(rc["solute_vacancy_variants"])):
                seed = stable_seed(cfg["seed"], "solute_vacancy_shell", solute, shell, variant)
                rng = np.random.default_rng(seed)
                center = int(rng.integers(len(base.symbols)))
                shells = neighbor_shells(base, center, max(rc["solute_vacancy_shells"]))
                vacancy_index = shells[int(shell)][variant % len(shells[int(shell)])]
                frame = base.copy()
                frame.symbols[center] = str(solute)
                pair_distance = float(
                    np.linalg.norm(minimum_image(
                        base.positions[vacancy_index] - base.positions[center], base.cell
                    ))
                )
                frame = _remove_site(frame, vacancy_index)
                sigma = sigmas[variant % len(sigmas)]
                _displace(frame, sigma, seed)
                add(
                    f"solute_vacancy_shell_{local_index:04d}",
                    "solute_vacancy_shell",
                    frame,
                    seed,
                    {
                        "config_type": "TargetedSoluteVacancy",
                        "solute": solute,
                        "neighbor_shell": int(shell),
                        "pair_distance_angstrom": pair_distance,
                        "solute_site_index": center,
                        "vacancy_site_index": vacancy_index,
                        "orientation_variant": variant,
                        "displacement_sigma_angstrom": sigma,
                    },
                )
                local_index += 1

    # Two-solute plus vacancy complexes. Half the variants swap which solute binds 1NN to V.
    local_index = 0
    for pair in rc["ternary_solute_pairs"]:
        solute_a, solute_b = pair
        for variant in range(int(rc["ternary_vacancy_variants_per_pair"])):
            seed = stable_seed(cfg["seed"], "ternary_vacancy", solute_a, solute_b, variant)
            rng = np.random.default_rng(seed)
            center = int(rng.integers(len(base.symbols)))
            shells = neighbor_shells(base, center, 4)
            if variant >= int(rc["ternary_vacancy_variants_per_pair"]) // 2:
                central_solute, second_solute = solute_b, solute_a
            else:
                central_solute, second_solute = solute_a, solute_b
            vacancy_index = shells[1][variant % len(shells[1])]
            second_shell = variant % 4 + 1
            candidates = [site for site in shells[second_shell] if site != vacancy_index]
            second_index = candidates[(variant // 4) % len(candidates)]
            frame = base.copy()
            frame.symbols[center] = str(central_solute)
            frame.symbols[second_index] = str(second_solute)
            frame = _remove_site(frame, vacancy_index)
            sigma = sigmas[variant % len(sigmas)]
            _displace(frame, sigma, seed)
            add(
                f"ternary_vacancy_{local_index:04d}",
                "ternary_vacancy",
                frame,
                seed,
                {
                    "config_type": "TargetedTernaryVacancy",
                    "solute_pair": list(pair),
                    "central_solute": central_solute,
                    "second_solute": second_solute,
                    "second_solute_shell": second_shell,
                    "central_site_index": center,
                    "second_solute_site_index": second_index,
                    "vacancy_site_index": vacancy_index,
                    "orientation_variant": variant,
                    "displacement_sigma_angstrom": sigma,
                },
            )
            local_index += 1

    # Eight short vacancy-containing AIMD seeds: four Cu levels by two temperatures.
    aimd_index = 0
    for alloy in cfg["alloys"]:
        for temperature in rc["vacancy_aimd_temperatures_k"]:
            seed = stable_seed(cfg["seed"], "vacancy_aimd", alloy["name"], temperature)
            frame = decorate_alloy(base, alloy["fractions"], 1.0 / len(base.symbols), seed)
            _displace(frame, float(rc["vacancy_aimd_initial_sigma_angstrom"]), seed)
            add(
                f"vacancy_aimd_{aimd_index:04d}",
                "aimd",
                frame,
                seed,
                {
                    "config_type": "VacancyAIMD",
                    "alloy": alloy["name"],
                    "fractions": alloy["fractions"],
                    "vacancy_count": 1,
                    "temperature_k": int(temperature),
                    "vasp_overrides": {
                        "IBRION": 0,
                        "NSW": int(rc["vacancy_aimd_steps"]),
                        "POTIM": float(rc["vacancy_aimd_timestep_fs"]),
                        "TEBEG": int(temperature),
                        "TEEND": int(temperature),
                        "MDALGO": 2,
                        "SMASS": 0,
                        "ISIF": 2,
                        "NELMIN": 4,
                    },
                },
            )
            aimd_index += 1

    manifest = write_campaign_files(stage, records)
    static_ids = [record["task_id"] for record in records if record["category"] != "aimd"]
    aimd_ids = [record["task_id"] for record in records if record["category"] == "aimd"]
    (stage / "task_ids_static.txt").write_text("\n".join(static_ids) + "\n", encoding="utf-8")
    (stage / "task_ids_aimd.txt").write_text("\n".join(aimd_ids) + "\n", encoding="utf-8")
    summary = Counter(record["category"] for record in records)
    dump_json(
        {
            "config": cfg["_config_path"],
            "generated_tasks": len(records),
            "counts_by_category": dict(sorted(summary.items())),
            "base_sites": len(base.symbols),
            "output_is_separate_from_original_campaign": True,
        },
        stage / "generation.json",
    )
    return manifest
