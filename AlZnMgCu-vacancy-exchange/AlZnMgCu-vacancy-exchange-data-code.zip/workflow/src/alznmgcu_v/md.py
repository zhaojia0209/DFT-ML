from __future__ import annotations

import csv
from pathlib import Path

from .atoms import decorate_alloy, fcc_conventional, write_lammps_data
from .config import dump_json, ensure_stage, stable_seed


def generate_md(cfg: dict, model: str | Path) -> Path:
    stage = ensure_stage(cfg, "05_md")
    runs = stage / "runs"
    md = cfg["md"]
    elements = cfg["elements"]
    base = fcc_conventional(md["supercell"], cfg["lattice"]["a0_angstrom"])
    # Keep cluster-side absolute paths verbatim; resolving on a Windows submit
    # workstation would corrupt a Linux path supplied by the user.
    model = str(model)
    records = []
    for alloy in cfg["alloys"]:
        for vacancy in cfg["vacancy_conditions"]:
            for temperature in md["temperatures_k"]:
                for replicate in range(int(md["replicates"])):
                    run_id = f"{alloy['name']}_{vacancy['name']}_T{temperature}_r{replicate + 1}"
                    seed = stable_seed(cfg["seed"], "md", run_id)
                    frame = decorate_alloy(base, alloy["fractions"], vacancy["fraction"], seed)
                    directory = runs / run_id
                    directory.mkdir(parents=True, exist_ok=True)
                    write_lammps_data(frame, directory / "structure.data", elements)
                    timestep = float(md["timestep_fs"])
                    equil_steps = int(round(float(md["equilibration_ps"]) * 1000 / timestep))
                    prod_steps = int(round(float(md["production_ps"]) * 1000 / timestep))
                    lammps = f"""# {run_id}
units metal
dimension 3
boundary p p p
atom_style atomic
atom_modify map yes
newton on
read_data structure.data

pair_style mace no_domain_decomposition
pair_coeff * * {model} {' '.join(elements)}

neighbor 2.0 bin
neigh_modify every 1 delay 0 check yes
timestep {timestep / 1000:.8f}
velocity all create {temperature} {seed} mom yes rot no dist gaussian

thermo {md['thermo_interval_steps']}
thermo_style custom step temp press pe ke etotal vol density
thermo_modify flush yes

fix EQ all npt temp {temperature} {temperature} 0.1 iso {md['pressure_bar']} {md['pressure_bar']} 1.0
run {equil_steps}
unfix EQ
reset_timestep 0

fix PROD all nvt temp {temperature} {temperature} 0.1
dump TRAJ all custom {md['dump_interval_steps']} trajectory.dump id type xu yu zu vx vy vz
dump_modify TRAJ sort id element {' '.join(elements)}
run {prod_steps}
unfix PROD
write_restart final.restart
"""
                    (directory / "in.md").write_text(lammps, encoding="utf-8")
                    slurm = md["slurm"]
                    gpu_line = f"#SBATCH --gpus={slurm['gpus']}\n" if int(slurm.get("gpus", 0)) else ""
                    (directory / "job.slurm").write_text(
                        f"#!/bin/bash\n#SBATCH --job-name={run_id[:40]}\n#SBATCH --partition={slurm['partition']}\n"
                        f"#SBATCH --nodes={slurm['nodes']}\n#SBATCH --ntasks={slurm['ntasks']}\n{gpu_line}"
                        f"#SBATCH --time={slurm['time']}\nset -euo pipefail\n"
                        f"{md['lammps_command']} > lammps.log\n",
                        encoding="utf-8",
                    )
                    record = {
                        "run_id": run_id, "alloy": alloy["name"], "vacancy": vacancy["name"],
                        "temperature_k": temperature, "replicate": replicate + 1, "seed": seed,
                        "n_sites": len(base.symbols), "n_atoms": len(frame.symbols),
                        "fractions": alloy["fractions"], "vacancy_fraction": vacancy["fraction"],
                        "model": model,
                    }
                    dump_json(record, directory / "metadata.json")
                    records.append(record)
    manifest = stage / "manifest.csv"
    keys = list(records[0])
    with manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        for row in records:
            writer.writerow({k: str(v) if isinstance(v, dict) else v for k, v in row.items()})
    return manifest
