from __future__ import annotations

from collections import Counter
from pathlib import Path

import numpy as np

from .atoms import Frame, fcc_conventional
from .config import dump_json, ensure_stage, stable_seed
from .vasp import write_campaign_files, write_vasp_task


def _strain_volume(frame: Frame, volume_strain: float) -> None:
    factor = (1.0 + float(volume_strain)) ** (1.0 / 3.0)
    frame.cell *= factor
    frame.positions *= factor


def _displace(frame: Frame, sigma: float, seed: int) -> None:
    frame.positions += np.random.default_rng(seed).normal(0.0, sigma, frame.positions.shape)


def _remove_site(frame: Frame, site: int) -> None:
    keep = np.ones(len(frame.symbols), dtype=bool)
    keep[int(site)] = False
    frame.symbols = [symbol for index, symbol in enumerate(frame.symbols) if keep[index]]
    frame.positions = frame.positions[keep]
    frame.ids = np.arange(1, len(frame.symbols) + 1, dtype=int)


def build_calibration_database(cfg: dict, limit: int | None = None) -> Path:
    """Build a held-out-safe calibration campaign for composition and vacancy offsets."""
    if "calibration_database" not in cfg:
        raise ValueError("Configuration is missing calibration_database")
    cc = cfg["calibration_database"]
    stage = ensure_stage(cfg, "01_calibration_database")
    tasks = stage / "tasks"
    tasks.mkdir(parents=True, exist_ok=True)
    base = fcc_conventional(cc["supercell"], cfg["lattice"]["a0_angstrom"])
    strains = [float(value) for value in cc["volume_strains"]]
    records: list[dict] = []

    def add(task_id: str, category: str, frame: Frame, seed: int, extra: dict) -> bool:
        if limit is not None and len(records) >= limit:
            return False
        metadata = {
            "task_id": task_id,
            "group_id": task_id,
            "category": category,
            "config_type": extra.get("config_type", category),
            "campaign": "defect_energy_calibration_v1",
            "seed": int(seed),
            "n_atoms": len(frame.symbols),
            "composition": {
                element: frame.symbols.count(element) for element in cfg["elements"]
            },
            "excluded_from_validation": True,
            **extra,
        }
        write_vasp_task(frame, tasks / task_id, cfg, metadata)
        records.append(metadata)
        return True

    # Four matched Al controls. Every structure has non-zero strain and displacement,
    # so none duplicates the unperturbed validation bulk configuration.
    pure_sigma = float(cc["pure_displacement_sigma_angstrom"])
    for index, strain in enumerate(strains):
        seed = stable_seed(cfg["seed"], "calibration_pure", index)
        frame = base.copy()
        _strain_volume(frame, strain)
        _displace(frame, pure_sigma, seed)
        add(
            f"calibration_pure_{index:04d}",
            "calibration_pure",
            frame,
            seed,
            {"volume_strain": strain, "displacement_sigma_angstrom": pure_sigma},
        )

    # Twenty-four one-solute cells: three elements, four small non-zero strains,
    # and two displacement amplitudes. These constrain element-dependent offsets
    # without training on the exact substitution validation geometries.
    substitution_index = 0
    substitution_sigmas = [
        float(value) for value in cc["substitution_displacement_sigma_angstrom"]
    ]
    for element in cc["substitution_elements"]:
        for strain in strains:
            for sigma in substitution_sigmas:
                seed = stable_seed(
                    cfg["seed"], "calibration_substitution", element, strain, sigma
                )
                frame = base.copy()
                site = int(np.random.default_rng(seed).integers(len(frame.symbols)))
                frame.symbols[site] = str(element)
                _strain_volume(frame, strain)
                _displace(frame, sigma, seed)
                add(
                    f"calibration_substitution_{substitution_index:04d}",
                    "calibration_substitution",
                    frame,
                    seed,
                    {
                        "config_type": "CalibrationSubstitution",
                        "solute": str(element),
                        "solute_site_index": site,
                        "volume_strain": strain,
                        "displacement_sigma_angstrom": sigma,
                    },
                )
                substitution_index += 1

    # Twelve near-equilibrium vacancies. Existing refined vacancies start at larger
    # random distortions; these low-amplitude cells anchor the ideal vacancy limit.
    vacancy_index = 0
    vacancy_sigmas = [float(value) for value in cc["vacancy_displacement_sigma_angstrom"]]
    for strain in strains:
        for sigma in vacancy_sigmas:
            seed = stable_seed(cfg["seed"], "calibration_vacancy", strain, sigma)
            frame = base.copy()
            site = int(np.random.default_rng(seed).integers(len(frame.symbols)))
            _remove_site(frame, site)
            _strain_volume(frame, strain)
            _displace(frame, sigma, seed)
            add(
                f"calibration_vacancy_{vacancy_index:04d}",
                "calibration_vacancy",
                frame,
                seed,
                {
                    "config_type": "CalibrationVacancy",
                    "vacancy_site_index": site,
                    "volume_strain": strain,
                    "displacement_sigma_angstrom": sigma,
                },
            )
            vacancy_index += 1

    manifest = write_campaign_files(stage, records)
    dump_json(
        {
            "config": cfg["_config_path"],
            "generated_tasks": len(records),
            "counts_by_category": dict(sorted(Counter(r["category"] for r in records).items())),
            "validation_geometries_included": False,
            "scientific_purpose": [
                "reduce element-dependent substitution energy offsets",
                "anchor the near-equilibrium Al vacancy formation energy",
            ],
        },
        stage / "generation.json",
    )
    return manifest
