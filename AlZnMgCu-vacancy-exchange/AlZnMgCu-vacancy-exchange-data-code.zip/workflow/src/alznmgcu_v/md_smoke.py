from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from .atoms import decorate_alloy, fcc_conventional
from .config import stable_seed


def _minimum_distance(atoms) -> float:
    distances = np.asarray(atoms.get_all_distances(mic=True), dtype=float)
    np.fill_diagonal(distances, np.inf)
    return float(np.min(distances))


def _drift_ev_per_atom_ps(records: list[dict]) -> float:
    if len(records) < 2:
        return float("nan")
    time = np.asarray([float(row["time_ps"]) for row in records])
    energy = np.asarray([float(row["total_energy_ev_per_atom"]) for row in records])
    return float(np.polyfit(time, energy, 1)[0])


def run_mace_md_smoke(
    cfg: dict,
    model: str | Path,
    output: str | Path,
    temperatures: list[int],
    nvt_steps: int = 1000,
    nve_steps: int = 3000,
    timestep_fs: float = 1.0,
    sample_interval: int = 20,
) -> Path:
    """Run small CPU NVT->NVE stability checks using ASE and MACE."""
    try:
        from ase import Atoms, units
        from ase.io.trajectory import Trajectory
        from ase.md.langevin import Langevin
        from ase.md.velocitydistribution import (
            MaxwellBoltzmannDistribution,
            Stationary,
            ZeroRotation,
        )
        from ase.md.verlet import VelocityVerlet
        from mace.calculators import MACECalculator
    except ImportError as exc:
        raise RuntimeError("MD smoke testing requires ASE and mace-torch") from exc

    if min(nvt_steps, nve_steps, sample_interval) <= 0 or timestep_fs <= 0:
        raise ValueError("steps, sample interval, and timestep must be positive")
    model_path = Path(model).expanduser().resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MACE model not found: {model_path}")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    calculator = MACECalculator(
        model_paths=str(model_path), device="cpu", default_dtype="float64"
    )

    alloy = max(cfg["alloys"], key=lambda item: float(item["fractions"].get("Cu", 0.0)))
    base = fcc_conventional([3, 3, 3], float(cfg["lattice"]["a0_angstrom"]))
    summary: list[dict] = []
    for temperature in temperatures:
        print(
            f"[run] T{int(temperature)} K: {nvt_steps} NVT + {nve_steps} NVE steps",
            flush=True,
        )
        run_dir = output / f"T{int(temperature)}"
        run_dir.mkdir(parents=True, exist_ok=True)
        seed = stable_seed(int(cfg["seed"]), "md_smoke", int(temperature))
        frame = decorate_alloy(
            base, alloy["fractions"], 1.0 / len(base.symbols), seed
        )
        atoms = Atoms(
            symbols=frame.symbols,
            positions=frame.positions,
            cell=frame.cell,
            pbc=True,
        )
        atoms.calc = calculator
        rng = np.random.default_rng(seed)
        MaxwellBoltzmannDistribution(atoms, temperature_K=temperature, rng=rng)
        Stationary(atoms)
        ZeroRotation(atoms)

        records: list[dict] = []
        phase = "nvt"
        phase_step = 0
        trajectory = Trajectory(run_dir / "trajectory.traj", mode="w", atoms=atoms)

        def observe() -> None:
            forces = np.asarray(atoms.get_forces(), dtype=float)
            potential = float(atoms.get_potential_energy())
            kinetic = float(atoms.get_kinetic_energy())
            n_atoms = len(atoms)
            records.append({
                "phase": phase,
                "phase_step": phase_step,
                "time_ps": (
                    (phase_step if phase == "nvt" else nvt_steps + phase_step)
                    * timestep_fs / 1000.0
                ),
                "temperature_k": float(atoms.get_temperature()),
                "potential_energy_ev_per_atom": potential / n_atoms,
                "kinetic_energy_ev_per_atom": kinetic / n_atoms,
                "total_energy_ev_per_atom": (potential + kinetic) / n_atoms,
                "force_max_ev_per_angstrom": float(
                    np.max(np.linalg.norm(forces, axis=1))
                ),
                "minimum_distance_angstrom": _minimum_distance(atoms),
            })
            trajectory.write(atoms)

        try:
            observe()
            nvt = Langevin(
                atoms,
                timestep=timestep_fs * units.fs,
                temperature_K=temperature,
                friction=0.01 / units.fs,
            )
            for step in range(1, nvt_steps + 1):
                nvt.run(1)
                phase_step = step
                if step % sample_interval == 0 or step == nvt_steps:
                    observe()

            phase = "nve"
            phase_step = 0
            nve_records: list[dict] = []
            nve = VelocityVerlet(atoms, timestep=timestep_fs * units.fs)
            observe()
            nve_records.append(records[-1])
            for step in range(1, nve_steps + 1):
                nve.run(1)
                phase_step = step
                if step % sample_interval == 0 or step == nve_steps:
                    observe()
                    nve_records.append(records[-1])
            numeric = np.asarray([
                [float(row[key]) for key in (
                    "temperature_k", "total_energy_ev_per_atom",
                    "force_max_ev_per_angstrom", "minimum_distance_angstrom"
                )]
                for row in records
            ])
            finite = bool(np.all(np.isfinite(numeric)))
            drift = _drift_ev_per_atom_ps(nve_records)
            minimum_distance = float(np.min(numeric[:, 3]))
            maximum_force = float(np.max(numeric[:, 2]))
            passed = (
                finite
                and abs(drift) <= 1.0e-3
                and minimum_distance >= 1.8
                and maximum_force <= 20.0
            )
            status = "pass" if passed else "check"
            message = ""
        except Exception as exc:
            finite, drift, minimum_distance, maximum_force = False, np.nan, np.nan, np.nan
            status = "failed"
            message = str(exc).replace("\n", " ")[:500]
        finally:
            trajectory.close()

        if records:
            with (run_dir / "thermo.csv").open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(records[0]))
                writer.writeheader()
                writer.writerows(records)
        summary.append({
            "temperature_k": int(temperature),
            "n_atoms": len(atoms),
            "n_vacancies": 1,
            "nvt_steps": nvt_steps,
            "nve_steps": nve_steps,
            "timestep_fs": timestep_fs,
            "nve_energy_drift_ev_per_atom_ps": drift,
            "minimum_distance_angstrom": minimum_distance,
            "maximum_force_ev_per_angstrom": maximum_force,
            "all_values_finite": finite,
            "status": status,
            "message": message,
        })
        print(
            f"[{status}] T{int(temperature)} K: drift={drift:.6g} "
            f"eV/(atom ps), min_distance={minimum_distance:.4g} A, "
            f"max_force={maximum_force:.4g} eV/A",
            flush=True,
        )

    summary_path = output / "md_smoke_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    (output / "md_smoke_metadata.json").write_text(
        json.dumps({
            "model": str(model_path),
            "alloy": alloy,
            "supercell": [3, 3, 3],
            "thresholds": {
                "absolute_nve_drift_ev_per_atom_ps": 1.0e-3,
                "minimum_distance_angstrom": 1.8,
                "maximum_force_ev_per_angstrom": 20.0,
            },
        }, indent=2) + "\n",
        encoding="utf-8",
    )
    return summary_path
