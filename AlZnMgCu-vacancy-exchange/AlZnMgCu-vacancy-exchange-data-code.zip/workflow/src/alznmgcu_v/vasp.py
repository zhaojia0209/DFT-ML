from __future__ import annotations

import csv
import json
import os
import re
import shlex
from pathlib import Path
from typing import Any

import numpy as np

from .atoms import Frame, decorate_alloy, fcc_conventional, write_poscar
from .config import dump_json, ensure_stage, stable_seed


def _format_incar_value(value: Any) -> str:
    if isinstance(value, bool):
        return ".TRUE." if value else ".FALSE."
    return str(value)


def _gamma_kpoint_mesh(cell: np.ndarray, spacing: float) -> list[int]:
    if spacing <= 0:
        raise ValueError("kspacing_inv_angstrom must be positive")
    reciprocal = 2.0 * np.pi * np.linalg.inv(np.asarray(cell, dtype=float)).T
    return np.maximum(1, np.ceil(np.linalg.norm(reciprocal, axis=1) / spacing)).astype(int).tolist()


def write_vasp_task(
    frame: Frame,
    directory: str | Path,
    cfg: dict,
    metadata: dict,
    overrides: dict | None = None,
) -> None:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    vasp = cfg["vasp"]
    incar = {
        "SYSTEM": metadata.get("task_id", cfg["project"]),
        "ENCUT": vasp["encut_ev"], "EDIFF": vasp["ediff"], "EDIFFG": vasp["ediffg"],
        "PREC": vasp["prec"], "ALGO": vasp["algo"], "LREAL": vasp["lreal"],
        "ISMEAR": vasp["ismear"], "SIGMA": vasp["sigma_ev"], "NELM": vasp["nelm"],
        "NCORE": vasp["ncore"], "ISPIN": 1, "LASPH": True, "ADDGRID": True,
        "ISYM": 0, "IBRION": -1, "NSW": 0, "LCHARG": False, "LWAVE": False,
        "KSPACING": vasp["kspacing_inv_angstrom"], "KGAMMA": True,
    }
    incar.update(overrides or {})
    kpoints_mode = vasp.get("kpoints_mode", "kspacing")
    kpoint_spacing = float(incar["KSPACING"])
    kpoint_mesh = None
    if kpoints_mode == "explicit_gamma":
        kpoint_mesh = _gamma_kpoint_mesh(frame.cell, kpoint_spacing)
        incar.pop("KSPACING", None)
        incar.pop("KGAMMA", None)
    elif kpoints_mode != "kspacing":
        raise ValueError(f"Unsupported vasp.kpoints_mode: {kpoints_mode}")
    (directory / "INCAR").write_text(
        "\n".join(f"{key} = {_format_incar_value(value)}" for key, value in incar.items()) + "\n",
        encoding="utf-8",
    )
    write_poscar(frame, directory / "POSCAR", comment=metadata.get("task_id", "AlZnMgCuV"))
    if kpoint_mesh is not None:
        (directory / "KPOINTS").write_text(
            "Automatic Gamma-centered mesh\n0\nGamma\n"
            + " ".join(str(value) for value in kpoint_mesh)
            + "\n0 0 0\n",
            encoding="utf-8",
        )
    element_order = [element for element in cfg["elements"] if element in frame.symbols]
    potcar_root_text = str(vasp["potcar_root"])
    potcar_source_texts = [
        f"{potcar_root_text.rstrip('/')}/{vasp['potentials'][element]}/POTCAR"
        for element in element_order
    ]
    local_path_compatible = not (os.name == "nt" and potcar_root_text.startswith("/"))
    potcar_sources = [Path(source).expanduser() for source in potcar_source_texts]
    (directory / "POTCAR.spec").write_text(
        "\n".join(f"{element} {source}" for element, source in zip(element_order, potcar_source_texts)) + "\n",
        encoding="utf-8",
    )
    potcar_created = False
    if local_path_compatible and all(source.is_file() for source in potcar_sources):
        with (directory / "POTCAR").open("wb") as output:
            for source in potcar_sources:
                with source.open("rb") as input_handle:
                    while chunk := input_handle.read(1024 * 1024):
                        output.write(chunk)
        potcar_created = True
    # In kspacing mode KPOINTS is omitted; explicit_gamma writes a reproducible mesh.
    metadata.update({
        "potcar_root": potcar_root_text,
        "potcar_sequence": [vasp["potentials"][element] for element in element_order],
        "potcar_created_during_generation": potcar_created,
        "kpoints_mode": kpoints_mode,
        "kpoint_spacing_target_inv_angstrom": kpoint_spacing,
        "kpoint_mesh": kpoint_mesh,
    })
    dump_json(metadata, directory / "metadata.json")
    source_lines = "\n".join(f"append_potcar {shlex.quote(source)}" for source in potcar_source_texts)
    kpoints_check = (
        "test -s KPOINTS || { echo 'KPOINTS missing' >&2; exit 2; }"
        if kpoint_mesh is not None else ""
    )
    runner = f"""#!/usr/bin/env bash
set -euo pipefail
append_potcar() {{
  local source="$1"
  test -s "$source" || {{ echo "Missing licensed PAW dataset: $source" >&2; exit 2; }}
  cat "$source" >> POTCAR.tmp
}}
if [[ ! -s POTCAR ]]; then
  : > POTCAR.tmp
{source_lines}
  mv POTCAR.tmp POTCAR
fi
test -s INCAR || {{ echo 'INCAR missing' >&2; exit 2; }}
test -s POSCAR || {{ echo 'POSCAR missing' >&2; exit 2; }}
{kpoints_check}
{vasp['command']} > vasp.stdout 2> vasp.stderr
"""
    (directory / "run.sh").write_text(runner, encoding="utf-8")
    if vasp.get("execution_mode") == "slurm":
        slurm = vasp["slurm"]
        job = f"""#!/usr/bin/env bash
#SBATCH --job-name={metadata.get('task_id', 'alzmcv')[:40]}
#SBATCH --partition={slurm['partition']}
#SBATCH --nodes={slurm['nodes']}
#SBATCH --ntasks={slurm['ntasks']}
#SBATCH --time={slurm['time']}
#SBATCH --output=slurm-%j.out
set -euo pipefail
bash run.sh
"""
        (directory / "job.slurm").write_text(job, encoding="utf-8")


def _random_fractions(rng: np.random.Generator) -> dict[str, float]:
    total = float(rng.uniform(0.02, 0.12))
    weights = rng.dirichlet([2.0, 2.0, 1.2])
    return {el: total * float(w) for el, w in zip(["Zn", "Mg", "Cu"], weights)}


def write_campaign_files(stage: str | Path, records: list[dict]) -> Path:
    """Write a deterministic manifest and a workstation-safe sequential runner."""
    stage = Path(stage)
    manifest = stage / "manifest.csv"
    keys = sorted({key for record in records for key in record})
    with manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        for record in records:
            writer.writerow(
                {key: json.dumps(value) if isinstance(value, (dict, list)) else value
                 for key, value in record.items()}
            )
    (stage / "task_ids.txt").write_text(
        "\n".join(record["task_id"] for record in records) + "\n", encoding="utf-8"
    )
    run_all = r'''#!/usr/bin/env bash
set -uo pipefail
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TASK_ROOT="$SCRIPT_DIR/tasks"
TASK_LIST="${1:-$SCRIPT_DIR/task_ids.txt}"
test -s "$TASK_LIST" || { echo "Task list missing or empty: $TASK_LIST" >&2; exit 2; }
if (( $# > 0 )); then
  list_name="$(basename -- "$TASK_LIST" .txt)"
  SUMMARY="$SCRIPT_DIR/run_summary_${list_name}.tsv"
else
  SUMMARY="$SCRIPT_DIR/run_summary.tsv"
fi
printf 'task_id\tstatus\n' > "$SUMMARY"
failed=0

show_log_tail() {
  local task_dir="$1"
  for log in vasp.stderr vasp.stdout; do
    if [[ -s "$task_dir/$log" ]]; then
      echo "----- tail: $task_dir/$log -----" >&2
      tail -n 30 "$task_dir/$log" >&2
    fi
  done
}

while IFS= read -r task_id; do
  [[ -n "$task_id" ]] || continue
  task_dir="$TASK_ROOT/$task_id"
  if [[ -s "$task_dir/OUTCAR" ]] && grep -q 'General timing and accounting' "$task_dir/OUTCAR"; then
    echo "[skip] $task_id already complete"
    printf '%s\tcomplete\n' "$task_id" >> "$SUMMARY"
    continue
  fi
  echo "[run] $task_id"
  # MPI launchers may otherwise consume the remaining task_ids.txt from stdin.
  if (cd "$task_dir" && bash run.sh </dev/null); then
    if [[ -s "$task_dir/OUTCAR" ]] && grep -q 'General timing and accounting' "$task_dir/OUTCAR"; then
      printf '%s\tcomplete\n' "$task_id" >> "$SUMMARY"
    else
      echo "[failed] $task_id: VASP returned without a complete OUTCAR" >&2
      show_log_tail "$task_dir"
      printf '%s\tfailed_incomplete_outcar\n' "$task_id" >> "$SUMMARY"
      failed=$((failed + 1))
    fi
  else
    echo "[failed] $task_id: VASP command failed" >&2
    show_log_tail "$task_dir"
    printf '%s\tfailed_command\n' "$task_id" >> "$SUMMARY"
    failed=$((failed + 1))
  fi
done < "$TASK_LIST"
echo "Run summary: $SUMMARY"
if (( failed > 0 )); then
  echo "$failed task(s) failed; all remaining tasks were still attempted." >&2
  exit 1
fi
'''
    (stage / "run_all.sh").write_text(run_all, encoding="utf-8")
    return manifest


def build_dft_database(cfg: dict, limit: int | None = None) -> Path:
    stage = ensure_stage(cfg, "01_dft_database")
    tasks = stage / "tasks"
    tasks.mkdir(parents=True, exist_ok=True)
    dc = cfg["dft_database"]
    base = fcc_conventional(dc["supercell"], cfg["lattice"]["a0_angstrom"])
    requested = dc["counts"]
    records: list[dict] = []

    def add(category: str, frame: Frame, local_index: int, meta: dict) -> bool:
        if limit is not None and len(records) >= limit:
            return False
        task_id = f"{category}_{local_index:04d}"
        seed = stable_seed(cfg["seed"], category, local_index)
        metadata = {
            "task_id": task_id, "category": category, "seed": seed,
            "group_id": meta.get("group_id", task_id), "n_atoms": len(frame.symbols),
            "composition": {el: frame.symbols.count(el) for el in cfg["elements"]},
            **meta,
        }
        overrides = meta.get("vasp_overrides")
        write_vasp_task(frame, tasks / task_id, cfg, metadata, overrides=overrides)
        records.append(metadata)
        return True

    # Isolated atoms provide stable per-element E0 references for MACE.
    for i, element in enumerate(cfg["elements"]):
        isolated = Frame([element], np.array([[7.5, 7.5, 7.5]]), np.eye(3) * 15.0)
        add("isolated_atom", isolated, i, {
            "element": element, "config_type": "IsolatedAtom",
            "config_forces_weight": 0.0, "config_stress_weight": 0.0,
            "vasp_overrides": {"KSPACING": 100.0, "ISMEAR": 0, "SIGMA": 0.05,
                               "ISPIN": 2, "MAGMOM": 1.0},
        })

    # Hydrostatic and symmetry-breaking strains around fcc Al.
    strain_values = dc["volume_strains"]
    i = 0
    for volumetric in strain_values:
        if i >= requested["pure_strain"]:
            break
        frame = base.copy()
        linear = (1.0 + float(volumetric)) ** (1.0 / 3.0)
        frame.cell *= linear
        frame.positions *= linear
        add("pure_strain", frame, i, {"strain_type": "hydrostatic", "volume_strain": volumetric})
        i += 1
    for axis in range(3):
        for epsilon in (-0.02, 0.02):
            if i >= requested["pure_strain"]:
                break
            frame = base.copy()
            deformation = np.eye(3)
            deformation[axis, axis] += epsilon
            frame.cell = frame.cell @ deformation
            frame.positions = frame.positions @ deformation
            add("pure_strain", frame, i, {"strain_type": f"uniaxial_{axis}", "strain": epsilon})
            i += 1
        if i >= requested["pure_strain"]:
            break
    shear_axis = 0
    while i < requested["pure_strain"]:
        epsilon = -0.02 if i % 2 == 0 else 0.02
        frame = base.copy()
        deformation = np.eye(3)
        a, b = [(0, 1), (0, 2), (1, 2)][shear_axis % 3]
        deformation[a, b] = epsilon
        frame.cell = frame.cell @ deformation
        frame.positions = frame.positions @ deformation
        add("pure_strain", frame, i, {"strain_type": f"shear_{a}{b}", "strain": epsilon})
        shear_axis += 1
        i += 1

    for i in range(requested["pure_displaced"]):
        rng = np.random.default_rng(stable_seed(cfg["seed"], "pure_displaced", i))
        frame = base.copy()
        sigma = float(dc["displacement_sigma_angstrom"][i % len(dc["displacement_sigma_angstrom"])])
        frame.positions += rng.normal(0.0, sigma, frame.positions.shape)
        add("pure_displaced", frame, i, {"displacement_sigma_angstrom": sigma})

    for i in range(requested["random_alloy"]):
        seed = stable_seed(cfg["seed"], "random_alloy", i)
        rng = np.random.default_rng(seed)
        fractions = _random_fractions(rng)
        frame = decorate_alloy(base, fractions, 0.0, seed)
        sigma = float(rng.choice(dc["displacement_sigma_angstrom"]))
        frame.positions += rng.normal(0.0, sigma, frame.positions.shape)
        add("random_alloy", frame, i, {"fractions": fractions, "displacement_sigma_angstrom": sigma})

    # Short NVT AIMD seeds sample finite-temperature, off-equilibrium regions.
    # Every trajectory retains one group_id during extraction to prevent leakage.
    compositions = [{"name": "pure_Al", "fractions": {}}] + [
        {"name": alloy["name"], "fractions": alloy["fractions"]} for alloy in cfg["alloys"]
    ]
    temperatures = dc["aimd_temperatures_k"]
    for i in range(int(requested.get("aimd", 0))):
        seed = stable_seed(cfg["seed"], "aimd", i)
        rng = np.random.default_rng(seed)
        composition = compositions[(i // len(temperatures)) % len(compositions)]
        temperature = int(temperatures[i % len(temperatures)])
        frame = decorate_alloy(base, composition["fractions"], 0.0, seed)
        frame.positions += rng.normal(0.0, 0.02, frame.positions.shape)
        add("aimd", frame, i, {
            "alloy": composition["name"], "fractions": composition["fractions"],
            "temperature_k": temperature,
            "vasp_overrides": {
                "IBRION": 0, "NSW": int(dc["aimd_steps"]),
                "POTIM": float(dc["aimd_timestep_fs"]), "TEBEG": temperature,
                "TEEND": temperature, "MDALGO": 2, "SMASS": 0, "ISIF": 2,
                "NELMIN": 4,
            },
        })

    for category, count, targeted in [
        ("vacancy", requested["vacancy"], False),
        ("solute_vacancy", requested["solute_vacancy"], True),
    ]:
        for i in range(count):
            seed = stable_seed(cfg["seed"], category, i)
            rng = np.random.default_rng(seed)
            fractions = _random_fractions(rng) if targeted else {}
            frame = decorate_alloy(base, fractions, 1 / len(base.symbols), seed)
            sigma = float(rng.choice(dc["displacement_sigma_angstrom"]))
            frame.positions += rng.normal(0.0, sigma, frame.positions.shape)
            add(category, frame, i, {"fractions": fractions, "displacement_sigma_angstrom": sigma})

    manifest = write_campaign_files(stage, records)
    dump_json({"config": cfg["_config_path"], "generated_tasks": len(records)}, stage / "generation.json")
    return manifest


def _outcar_complete(path: Path) -> bool:
    if not path.exists():
        return False
    tail = path.read_bytes()[-20000:].decode(errors="ignore")
    return "General timing and accounting" in tail


def extract_vasp(
    tasks: str | Path,
    output: str | Path,
    all_ionic_steps: bool = False,
    ionic_stride: int = 10,
) -> tuple[int, int]:
    try:
        from ase.io import read, write
    except ImportError as exc:
        raise RuntimeError("VASP extraction requires ASE: pip install ase") from exc
    if ionic_stride <= 0:
        raise ValueError("ionic_stride must be positive")
    tasks = Path(tasks)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frames = []
    report = []
    manifest_path = tasks.parent / "manifest.csv"
    if manifest_path.exists():
        with manifest_path.open(newline="", encoding="utf-8") as handle:
            task_ids = [row["task_id"] for row in csv.DictReader(handle)]
        metadata_paths = [tasks / task_id / "metadata.json" for task_id in task_ids]
    else:
        metadata_paths = sorted(tasks.glob("*/metadata.json"))
    for metadata_path in metadata_paths:
        if not metadata_path.exists():
            report.append({"task_id": metadata_path.parent.name, "status": "failed",
                           "message": "metadata.json listed in manifest but missing"})
            continue
        directory = metadata_path.parent
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        status, message = "failed", ""
        try:
            if not _outcar_complete(directory / "OUTCAR"):
                raise RuntimeError("OUTCAR missing or incomplete")
            if all_ionic_steps and metadata.get("category") == "aimd":
                ionic_frames = list(read(directory / "OUTCAR", index=":"))
                selected = ionic_frames[::ionic_stride]
                if ionic_frames and (not selected or selected[-1] is not ionic_frames[-1]):
                    selected.append(ionic_frames[-1])
            else:
                selected = [read(directory / "OUTCAR", index=-1)]
            for ionic_index, atoms in enumerate(selected):
                atoms.info.update({
                    "task_id": metadata["task_id"], "group_id": metadata["group_id"],
                    "category": metadata["category"],
                    "config_type": metadata.get("config_type", metadata["category"]),
                    "ionic_frame": ionic_index,
                })
                for key in ("config_forces_weight", "config_stress_weight", "config_energy_weight"):
                    if key in metadata:
                        atoms.info[key] = metadata[key]
                # Force evaluation here so incomplete calculator results fail explicitly.
                _ = atoms.get_potential_energy(), atoms.get_forces(), atoms.get_stress(voigt=True)
                frames.append(atoms)
            status = "ok"
        except Exception as exc:  # the report retains exact per-task failure reasons
            message = str(exc).replace("\n", " ")[:500]
        report.append({"task_id": metadata.get("task_id"), "status": status, "message": message})
    if frames:
        write(output, frames, format="extxyz", write_results=True)
    report_path = output.parent / "extraction_report.csv"
    with report_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["task_id", "status", "message"])
        writer.writeheader()
        writer.writerows(report)
    completed_tasks = sum(row["status"] == "ok" for row in report)
    return len(frames), len(report) - completed_tasks


def collect_neb_energies(task: Path) -> list[float]:
    energies = []
    pattern = re.compile(r"energy\s+without entropy=\s*([-+0-9.Ee]+)")
    for image in sorted(p for p in task.iterdir() if p.is_dir() and p.name.isdigit()):
        outcar = image / "OUTCAR"
        matches = pattern.findall(outcar.read_text(errors="ignore")) if outcar.exists() else []
        if not matches:
            raise RuntimeError(f"No energy in {outcar}")
        energies.append(float(matches[-1]))
    return energies
