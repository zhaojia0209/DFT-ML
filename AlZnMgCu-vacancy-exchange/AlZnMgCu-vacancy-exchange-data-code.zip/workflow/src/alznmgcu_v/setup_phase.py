from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import sys
from importlib import metadata
from pathlib import Path

from .config import dump_json, ensure_stage


PYTHON_PACKAGES = {
    "numpy": "numpy",
    "yaml": "PyYAML",
    "ase": "ase",
    "matplotlib": "matplotlib",
    "torch": "torch",
    "mace": "mace-torch",
}


def initialize_phase01(cfg: dict, strict: bool = False) -> Path:
    """Create Phase 0/1 folders and record, without changing the host environment."""
    setup_dir = ensure_stage(cfg, "00_setup")
    dft_dir = ensure_stage(cfg, "01_dft_database")
    for path in [dft_dir / "tasks", dft_dir / "datasets", dft_dir / "reports"]:
        path.mkdir(parents=True, exist_ok=True)

    packages = {}
    for import_name, distribution_name in PYTHON_PACKAGES.items():
        available = importlib.util.find_spec(import_name) is not None
        version = None
        if available:
            try:
                version = metadata.version(distribution_name)
            except metadata.PackageNotFoundError:
                version = "installed (version unavailable)"
        packages[import_name] = {"available": available, "version": version}

    executables = {
        name: shutil.which(name)
        for name in ["vasp_std", "mpirun", "lmp", "mace_run_train", "mace_eval_configs"]
    }
    required_phase01 = ["numpy", "ase"]
    missing_required = [name for name in required_phase01 if not packages[name]["available"]]
    potcar_root_text = str(cfg["vasp"]["potcar_root"])
    potcar_root = Path(potcar_root_text).expanduser()
    local_path_compatible = not (os.name == "nt" and potcar_root_text.startswith("/"))
    potcar_sources = {
        element: {
            "potential": potential,
            "path": f"{potcar_root_text.rstrip('/')}/{potential}/POTCAR",
            "available_here": local_path_compatible and (potcar_root / potential / "POTCAR").is_file(),
        }
        for element, potential in cfg["vasp"]["potentials"].items()
    }
    report = {
        "project": cfg["project"],
        "config": cfg["_config_path"],
        "project_root": cfg["_project_root"],
        "workdir": cfg["_workdir"],
        "python": {"version": sys.version, "executable": sys.executable},
        "platform": platform.platform(),
        "packages": packages,
        "executables": executables,
        "vasp_pp_path": os.environ.get("VASP_PP_PATH"),
        "configured_potcar_root": potcar_root_text,
        "potcar_sources": potcar_sources,
        "phase01_ready": not missing_required,
        "missing_required_packages": missing_required,
        "notes": [
            "VASP and licensed POTCAR files are not installed by this command.",
            "Generated run.sh files assemble POTCAR from configured_potcar_root when needed.",
            "Phase 0/1 is configured for a workstation and does not require Slurm.",
        ],
    }
    output = setup_dir / "environment_report.json"
    dump_json(report, output)
    (setup_dir / "resolved_config.json").write_text(
        json.dumps({k: v for k, v in cfg.items() if not k.startswith("_")}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    if strict and missing_required:
        raise RuntimeError(f"Missing required Phase 0/1 packages: {', '.join(missing_required)}")
    return output
