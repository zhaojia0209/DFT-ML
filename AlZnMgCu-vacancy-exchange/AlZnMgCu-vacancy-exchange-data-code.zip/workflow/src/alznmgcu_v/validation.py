from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from .atoms import decorate_alloy, fcc_conventional, minimum_image
from .config import dump_json, ensure_stage, stable_seed
from .vasp import write_vasp_task


def generate_validation(cfg: dict) -> Path:
    stage = ensure_stage(cfg, "03_validation")
    tasks = stage / "tasks"
    base = fcc_conventional(cfg["validation"]["supercell"], cfg["lattice"]["a0_angstrom"])
    records = []

    def add(task_id: str, frame, family: str, metadata: dict) -> None:
        meta = {"task_id": task_id, "group_id": task_id, "category": "validation", "family": family,
                "n_atoms": len(frame.symbols), **metadata}
        write_vasp_task(frame, tasks / task_id, cfg, meta)
        records.append(meta)

    for index, strain in enumerate(cfg["validation"]["eos_strains"]):
        frame = base.copy()
        factor = (1.0 + float(strain)) ** (1 / 3)
        frame.cell *= factor
        frame.positions *= factor
        add(f"eos_{index:02d}", frame, "eos", {"volume_strain": strain})

    for mode in ["uniaxial_x", "uniaxial_y", "shear_xy"]:
        for index, strain in enumerate(cfg["validation"]["elastic_strains"]):
            deformation = np.eye(3)
            if mode == "uniaxial_x":
                deformation[0, 0] += strain
            elif mode == "uniaxial_y":
                deformation[1, 1] += strain
            else:
                deformation[0, 1] += strain
            frame = base.copy()
            frame.cell = frame.cell @ deformation
            frame.positions = frame.positions @ deformation
            add(f"elastic_{mode}_{index:02d}", frame, "elastic", {"mode": mode, "strain": strain})

    for element in ["Zn", "Mg", "Cu"]:
        seed = stable_seed(cfg["seed"], "validation_substitution", element)
        frame = decorate_alloy(base, {element: 1 / len(base.symbols)}, 0.0, seed)
        add(f"substitution_{element}", frame, "substitution", {"solute": element})

    vacancy = decorate_alloy(base, {}, 1 / len(base.symbols), stable_seed(cfg["seed"], "vacancy"))
    add("vacancy_Al", vacancy, "vacancy", {})

    # Solute-vacancy local environments at several separations. These are explicit
    # target-property probes, not a random holdout from the training distribution.
    box_center = 0.5 * np.sum(base.cell, axis=0)
    center = int(np.argmin(np.linalg.norm(minimum_image(base.positions - box_center, base.cell), axis=1)))
    distances = np.linalg.norm(minimum_image(base.positions - base.positions[center], base.cell), axis=1)
    shell_distances = sorted({round(float(x), 6) for x in distances if x > 1e-8})[:3]
    for element in ["Zn", "Mg", "Cu"]:
        for shell, shell_distance in enumerate(shell_distances, 1):
            frame = base.copy()
            solute_index = int(np.argmin(np.where(np.arange(len(distances)) == center, np.inf,
                                                  np.abs(distances - shell_distance))))
            frame.symbols[solute_index] = element
            keep = np.ones(len(frame.symbols), dtype=bool)
            keep[center] = False
            frame.symbols = [s for i, s in enumerate(frame.symbols) if keep[i]]
            frame.positions = frame.positions[keep]
            frame.ids = np.arange(1, len(frame.symbols) + 1)
            add(f"binding_{element}_shell{shell}", frame, "binding",
                {"solute": element, "shell": shell, "separation_angstrom": shell_distance})

    manifest = stage / "manifest.csv"
    keys = sorted({k for row in records for k in row})
    with manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        writer.writerows(records)
    return manifest


def summarize_validation(cfg: dict, reference: str | Path, prediction: str | Path) -> Path:
    """Compare tidy tables with columns id,family and numeric property columns."""
    def load(path: str | Path) -> dict[str, dict]:
        with Path(path).open(newline="", encoding="utf-8") as handle:
            return {row["id"]: row for row in csv.DictReader(handle)}

    ref, pred = load(reference), load(prediction)
    shared = sorted(set(ref) & set(pred))
    if not shared:
        raise ValueError("Reference and prediction tables have no shared id")
    properties = sorted((set(ref[shared[0]]) & set(pred[shared[0]])) - {"id", "family"})
    rows = []
    for family in sorted({ref[key].get("family", "all") for key in shared} | {"all"}):
        ids = shared if family == "all" else [key for key in shared if ref[key].get("family") == family]
        for prop in properties:
            pairs = []
            for key in ids:
                try:
                    pairs.append((float(ref[key][prop]), float(pred[key][prop])))
                except (ValueError, TypeError, KeyError):
                    pass
            if not pairs:
                continue
            a, b = np.asarray(pairs).T
            error = b - a
            rows.append({"family": family, "property": prop, "n": len(error),
                         "mae": float(np.mean(np.abs(error))),
                         "rmse": float(np.sqrt(np.mean(error**2))),
                         "max_abs": float(np.max(np.abs(error)))})
    output = ensure_stage(cfg, "03_validation") / "validation_summary.csv"
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    dump_json({"reference": str(reference), "prediction": str(prediction),
               "thresholds": cfg["validation"]["thresholds"]}, output.with_suffix(".json"))
    return output


def evaluate_validation(
    cfg: dict, engine: str, model: str | None = None, device: str = "cpu"
) -> Path:
    """Evaluate validation POSCARs and reduce energies to physical observables."""
    try:
        from ase.io import read
    except ImportError as exc:
        raise RuntimeError("Validation evaluation requires ASE: pip install ase") from exc
    calculator = None
    if engine == "mace":
        if not model:
            raise ValueError("--model is required for the MACE engine")
        try:
            from mace.calculators import MACECalculator
        except ImportError as exc:
            raise RuntimeError("MACE evaluation requires mace-torch") from exc
        calculator = MACECalculator(model_paths=model, device=device, default_dtype="float64")
    stage = ensure_stage(cfg, "03_validation")
    raw, failures = [], []
    for task in sorted((stage / "tasks").glob("*")):
        if not task.is_dir() or not (task / "metadata.json").exists():
            continue
        metadata = json.loads((task / "metadata.json").read_text(encoding="utf-8"))
        try:
            if engine == "dft":
                atoms = read(task / "OUTCAR", index=-1)
            else:
                atoms = read(task / "POSCAR")
                atoms.calc = calculator
            energy = float(atoms.get_potential_energy())
            forces = np.asarray(atoms.get_forces())
            stress = np.asarray(atoms.get_stress(voigt=True)) * 160.21766208
            raw.append({
                "id": metadata["task_id"], "family": metadata["family"], "n_atoms": len(atoms),
                "energy_ev": energy, "energy_ev_per_atom": energy / len(atoms),
                "force_rms_ev_per_angstrom": float(np.sqrt(np.mean(forces**2))),
                "stress_rms_gpa": float(np.sqrt(np.mean(stress**2))),
            })
        except Exception as exc:
            failures.append({"id": metadata["task_id"], "message": str(exc).replace("\n", " ")[:500]})
    if not raw:
        raise RuntimeError(f"No {engine} validation results could be evaluated")
    raw_path = stage / f"validation_{engine}_raw.csv"
    with raw_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(raw[0]))
        writer.writeheader()
        writer.writerows(raw)
    by_id = {row["id"]: row for row in raw}
    eos_meta = []
    for task in (stage / "tasks").glob("eos_*"):
        meta = json.loads((task / "metadata.json").read_text(encoding="utf-8"))
        if meta["task_id"] in by_id:
            eos_meta.append(meta)
    equilibrium = min(eos_meta, key=lambda row: abs(float(row["volume_strain"])))
    bulk = by_id[equilibrium["task_id"]]
    properties = []

    def prop(identifier: str, family: str, value: float) -> None:
        properties.append({"id": identifier, "family": family, "value_ev": float(value)})

    for meta in eos_meta:
        row = by_id[meta["task_id"]]
        value = row["energy_ev_per_atom"] - bulk["energy_ev_per_atom"]
        prop(meta["task_id"], "eos", value)
    for identifier, row in by_id.items():
        if row["family"] == "elastic":
            prop(identifier, "elastic", row["energy_ev_per_atom"] - bulk["energy_ev_per_atom"])
        elif row["family"] == "substitution":
            prop(identifier, "substitution_delta", row["energy_ev"] - bulk["energy_ev"])
    if "vacancy_Al" in by_id:
        vacancy = by_id["vacancy_Al"]
        e_form = vacancy["energy_ev"] - vacancy["n_atoms"] * bulk["energy_ev_per_atom"]
        prop("vacancy_formation", "vacancy", e_form)
    for identifier, row in by_id.items():
        if row["family"] != "binding":
            continue
        element = identifier.split("_")[1]
        solute = by_id.get(f"substitution_{element}")
        vacancy = by_id.get("vacancy_Al")
        if solute and vacancy:
            # Positive below means attraction (energy gained by bringing defects together).
            binding = solute["energy_ev"] + vacancy["energy_ev"] - bulk["energy_ev"] - row["energy_ev"]
            prop(identifier, "binding", binding)
    output = stage / f"validation_{engine}.csv"
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["id", "family", "value_ev"])
        writer.writeheader()
        writer.writerows(properties)
    if failures:
        failure_path = stage / f"validation_{engine}_failures.csv"
        with failure_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["id", "message"])
            writer.writeheader()
            writer.writerows(failures)
    return output
