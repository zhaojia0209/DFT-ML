from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterator

import numpy as np

from .atoms import Frame, minimum_image


def neighbor_pairs(frame: Frame, cutoff: float) -> Iterator[tuple[int, int, float]]:
    """Yield unique periodic neighbor pairs using an orthorhombic linked-cell list."""
    lengths = np.diag(frame.cell)
    if not np.allclose(frame.cell, np.diag(lengths)):
        # Correct fallback for small non-orthorhombic validation cells.
        for i in range(len(frame.symbols)):
            delta = minimum_image(frame.positions[i + 1 :] - frame.positions[i], frame.cell)
            distances = np.linalg.norm(delta, axis=1)
            for offset in np.where(distances < cutoff)[0]:
                yield i, i + 1 + int(offset), float(distances[offset])
        return
    if cutoff <= 0 or cutoff >= 0.5 * min(lengths):
        raise ValueError("cutoff must be positive and smaller than half the shortest box length")
    wrapped = frame.positions % lengths
    nbin = np.maximum(np.floor(lengths / cutoff).astype(int), 1)
    scaled = wrapped / lengths
    bins = np.floor(scaled * nbin).astype(int) % nbin
    buckets: dict[tuple[int, int, int], list[int]] = defaultdict(list)
    for atom_index, key in enumerate(map(tuple, bins)):
        buckets[key].append(atom_index)
    offsets = [(a, b, c) for a in (-1, 0, 1) for b in (-1, 0, 1) for c in (-1, 0, 1)]
    for key, members in buckets.items():
        # A set avoids duplicate wrapped keys when a box has only 1–2 bins.
        neighbor_keys = {tuple((np.asarray(key) + offset) % nbin) for offset in offsets}
        for other_key in neighbor_keys:
            for i in members:
                for j in buckets.get(other_key, []):
                    if i >= j:
                        continue
                    delta = wrapped[j] - wrapped[i]
                    delta -= np.round(delta / lengths) * lengths
                    distance = float(np.linalg.norm(delta))
                    if distance < cutoff:
                        yield i, j, distance


class UnionFind:
    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.size = [1] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        a, b = self.find(a), self.find(b)
        if a == b:
            return
        if self.size[a] < self.size[b]:
            a, b = b, a
        self.parent[b] = a
        self.size[a] += self.size[b]
