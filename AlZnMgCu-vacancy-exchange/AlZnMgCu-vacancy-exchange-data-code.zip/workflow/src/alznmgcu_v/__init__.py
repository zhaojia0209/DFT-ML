"""Al-Zn-Mg-Cu-vacancy multiscale workflow."""

__version__ = "0.1.0"

