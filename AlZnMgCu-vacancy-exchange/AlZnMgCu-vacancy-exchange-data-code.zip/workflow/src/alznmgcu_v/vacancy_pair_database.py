from __future__ import annotations

from collections import Counter
from pathlib import Path

import numpy as np

from .atoms import Frame, fcc_conventional
from .config import dump_json, ensure_stage, stable_seed
from .vasp import write_campaign_files, write_vasp_task


def _strain_volume(frame: Frame, volume_strain: float) -> None:
    factor = (1.0 + float(volume_strain)) ** (1.0 / 3.0)
    frame.cell *= factor
    frame.positions *= factor


def _remove_site(frame: Frame, site: int) -> None:
    keep = np.ones(len(frame.symbols), dtype=bool)
    keep[int(site)] = False
    frame.symbols = [symbol for index, symbol in enumerate(frame.symbols) if keep[index]]
    frame.positions = frame.positions[keep]
    frame.ids = np.arange(1, len(frame.symbols) + 1, dtype=int)


def build_vacancy_pair_database(cfg: dict, limit: int | None = None) -> Path:
    """Build matched bulk/vacancy DFT pairs for vacancy-formation-energy calibration.

    Each pair shares the cell strain and the displacement field of every retained atom.
    A shared group_id guarantees that train/valid/test splitting cannot separate the two
    members. All strains and displacements are non-zero, keeping the ideal validation
    geometry outside the training database.
    """
    if "vacancy_pair_database" not in cfg:
        raise ValueError("Configuration is missing vacancy_pair_database")
    pc = cfg["vacancy_pair_database"]
    stage = ensure_stage(cfg, "01_vacancy_pair_database")
    tasks = stage / "tasks"
    tasks.mkdir(parents=True, exist_ok=True)
    base = fcc_conventional(pc["supercell"], cfg["lattice"]["a0_angstrom"])
    strains = [float(value) for value in pc["volume_strains"]]
    sigmas = [float(value) for value in pc["displacement_sigma_angstrom"]]
    if any(value == 0.0 for value in strains) or any(value == 0.0 for value in sigmas):
        raise ValueError("Vacancy-pair strains and displacement sigmas must be non-zero")
    records: list[dict] = []

    def add(task_id: str, frame: Frame, metadata: dict) -> bool:
        if limit is not None and len(records) >= limit:
            return False
        full_metadata = {
            "task_id": task_id,
            "category": "vacancy_energy_pair",
            "campaign": "vacancy_pair_calibration_v3",
            "n_atoms": len(frame.symbols),
            "composition": {
                element: frame.symbols.count(element) for element in cfg["elements"]
            },
            "excluded_from_validation": True,
            **metadata,
        }
        write_vasp_task(frame, tasks / task_id, cfg, full_metadata)
        records.append(full_metadata)
        return True

    pair_index = 0
    for strain in strains:
        for sigma in sigmas:
            pair_id = f"vacancy_pair_{pair_index:04d}"
            seed = stable_seed(cfg["seed"], "vacancy_pair", strain, sigma)
            rng = np.random.default_rng(seed)
            paired_bulk = base.copy()
            _strain_volume(paired_bulk, strain)
            paired_bulk.positions += rng.normal(0.0, sigma, paired_bulk.positions.shape)
            vacancy_site = int(rng.integers(len(paired_bulk.symbols)))

            common = {
                "group_id": pair_id,
                "pair_id": pair_id,
                "seed": int(seed),
                "volume_strain": strain,
                "displacement_sigma_angstrom": sigma,
                "vacancy_site_index": vacancy_site,
            }
            if not add(
                f"{pair_id}_bulk",
                paired_bulk.copy(),
                {**common, "config_type": "VacancyPairBulk", "pair_role": "bulk"},
            ):
                break
            paired_vacancy = paired_bulk.copy()
            _remove_site(paired_vacancy, vacancy_site)
            if not add(
                f"{pair_id}_vacancy",
                paired_vacancy,
                {**common, "config_type": "VacancyPairDefect", "pair_role": "vacancy"},
            ):
                break
            pair_index += 1
        if limit is not None and len(records) >= limit:
            break

    manifest = write_campaign_files(stage, records)
    dump_json(
        {
            "config": cfg["_config_path"],
            "generated_tasks": len(records),
            "complete_pairs": sum(1 for row in records if row["pair_role"] == "vacancy"),
            "counts_by_role": dict(sorted(Counter(r["pair_role"] for r in records).items())),
            "validation_geometries_included": False,
            "scientific_purpose": (
                "reduce the correlated bulk/vacancy energy offset controlling "
                "Al vacancy formation energy"
            ),
        },
        stage / "generation.json",
    )
    return manifest
