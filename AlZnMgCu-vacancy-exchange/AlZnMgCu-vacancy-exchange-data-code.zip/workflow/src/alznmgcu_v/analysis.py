from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from .config import dump_json
from .neighbors import UnionFind, neighbor_pairs
from .trajectory import iter_strided, read_lammps_dump


def _write_csv(path: Path, rows: list[dict], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0]) if rows else []
    with path.open("w", newline="", encoding="utf-8") as handle:
        if fieldnames:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)


def compute_msd(
    frames, timestep_fs: float, dump_interval: int, fit_fraction: list[float],
    drift_reference: str | None = None,
):
    iterator = iter(frames)
    try:
        reference = next(iterator)
    except StopIteration as exc:
        raise ValueError("MSD needs at least three frames") from exc
    if not reference.info.get("unwrapped", False):
        raise ValueError("MSD requires unwrapped xu/yu/zu coordinates")
    reference_symbols = np.asarray(reference.symbols)
    drift_mask = reference_symbols == drift_reference if drift_reference else np.zeros(len(reference.symbols), bool)
    if drift_reference and not np.any(drift_mask):
        raise ValueError(f"MSD drift-reference species {drift_reference!r} is absent")
    elements = sorted(set(reference.symbols))
    masks = {element: reference_symbols == element for element in elements}
    values = {element: [] for element in elements}
    times = []
    for frame in _prepend(reference, iterator):
        if not frame.info.get("unwrapped", False):
            raise ValueError("MSD requires unwrapped xu/yu/zu coordinates")
        if not np.array_equal(frame.ids, reference.ids):
            raise ValueError("Atom IDs/order changed between frames")
        times.append((frame.info["timestep"] - reference.info["timestep"]) * timestep_fs / 1000.0)
        displacement_all = frame.positions - reference.positions
        drift = np.mean(displacement_all[drift_mask], axis=0) if drift_reference else 0.0
        for element in elements:
            displacement = displacement_all[masks[element]] - drift
            values[element].append(float(np.mean(np.sum(displacement**2, axis=1))))
    if len(times) < 3:
        raise ValueError("MSD needs at least three frames")
    times = np.asarray(times)
    rows = []
    diffusivity = []
    for element in elements:
        start = max(1, int(len(times) * fit_fraction[0]))
        end = max(start + 2, int(len(times) * fit_fraction[1]))
        end = min(end, len(times))
        slope, intercept = np.polyfit(times[start:end], np.asarray(values[element])[start:end], 1)
        d_a2_ps = slope / 6.0
        diffusivity.append({"element": element, "D_angstrom2_per_ps": d_a2_ps,
                            "D_m2_per_s": d_a2_ps * 1e-8, "fit_start_ps": times[start],
                            "fit_end_ps": times[end - 1], "intercept_angstrom2": intercept})
        rows.extend({"time_ps": t, "element": element, "msd_angstrom2": value}
                    for t, value in zip(times, values[element]))
    return rows, diffusivity


def _prepend(first, iterator):
    yield first
    yield from iterator


def compute_rdf(frames, elements: list[str], rmax: float, bins: int):
    edges = np.linspace(0.0, rmax, bins + 1)
    counts = {tuple(sorted((a, b))): np.zeros(bins) for i, a in enumerate(elements) for b in elements[i:]}
    normalization = {pair: np.zeros(bins) for pair in counts}
    for frame in frames:
        composition = Counter(frame.symbols)
        shell_volume = 4 * np.pi / 3 * (edges[1:] ** 3 - edges[:-1] ** 3)
        for pair in counts:
            a, b = pair
            possible = composition[a] * composition[b]
            if a == b:
                possible = composition[a] * (composition[a] - 1) / 2
            normalization[pair] += possible * shell_volume / frame.volume
        for i, j, distance in neighbor_pairs(frame, rmax):
            pair = tuple(sorted((frame.symbols[i], frame.symbols[j])))
            if pair in counts:
                index = min(int(np.searchsorted(edges, distance, side="right") - 1), bins - 1)
                if index >= 0:
                    counts[pair][index] += 1
    centers = 0.5 * (edges[:-1] + edges[1:])
    rows = []
    for pair in sorted(counts):
        g = np.divide(counts[pair], normalization[pair], out=np.zeros(bins), where=normalization[pair] > 0)
        rows.extend({"pair": f"{pair[0]}-{pair[1]}", "r_angstrom": r, "g_r": value,
                     "pair_count": int(count)} for r, value, count in zip(centers, g, counts[pair]))
    return rows


def compute_sro(frames, elements: list[str], cutoff: float):
    directed = defaultdict(int)
    centers = Counter()
    bulk = Counter()
    total_atoms = 0
    for frame in frames:
        bulk.update(frame.symbols)
        total_atoms += len(frame.symbols)
        for i, j, _ in neighbor_pairs(frame, cutoff):
            a, b = frame.symbols[i], frame.symbols[j]
            directed[(a, b)] += 1
            directed[(b, a)] += 1
            centers[a] += 1
            centers[b] += 1
    rows = []
    for a in elements:
        for b in elements:
            concentration = bulk[b] / total_atoms if total_atoms else np.nan
            conditional = directed[(a, b)] / centers[a] if centers[a] else np.nan
            alpha = 1.0 - conditional / concentration if concentration > 0 and np.isfinite(conditional) else np.nan
            rows.append({"center": a, "neighbor": b, "alpha": alpha,
                         "conditional_probability": conditional, "bulk_fraction": concentration,
                         "directed_neighbor_count": directed[(a, b)]})
    return rows


def compute_clusters(frames, solutes: list[str], cutoff: float):
    cluster_rows, frame_rows = [], []
    solute_set = set(solutes)
    for frame_index, frame in enumerate(frames):
        selected = [i for i, symbol in enumerate(frame.symbols) if symbol in solute_set]
        lookup = {atom: local for local, atom in enumerate(selected)}
        union = UnionFind(len(selected))
        for i, j, _ in neighbor_pairs(frame, cutoff):
            if i in lookup and j in lookup:
                union.union(lookup[i], lookup[j])
        groups = defaultdict(list)
        for local, atom_index in enumerate(selected):
            groups[union.find(local)].append(atom_index)
        sizes = []
        for cluster_id, members in enumerate(sorted(groups.values(), key=len, reverse=True), 1):
            composition = Counter(frame.symbols[index] for index in members)
            sizes.append(len(members))
            cluster_rows.append({
                "frame": frame_index, "timestep": frame.info.get("timestep", frame_index),
                "cluster_id": cluster_id, "size": len(members),
                **{f"n_{el}": composition[el] for el in solutes},
            })
        frame_rows.append({
            "frame": frame_index, "timestep": frame.info.get("timestep", frame_index),
            "n_clusters": len(sizes), "largest_cluster": max(sizes, default=0),
            "mean_cluster_size": float(np.mean(sizes)) if sizes else 0.0,
            "fraction_in_clusters_ge_2": float(sum(x for x in sizes if x >= 2) / max(len(selected), 1)),
            "fraction_in_clusters_ge_5": float(sum(x for x in sizes if x >= 5) / max(len(selected), 1)),
        })
    return cluster_rows, frame_rows


def analyze_dump(cfg: dict, dump: str | Path, out: str | Path) -> Path:
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    settings = cfg["analysis"]
    def frames():
        return iter_strided(read_lammps_dump(dump, cfg["elements"]), int(settings["frame_stride"]))

    msd, diffusion = compute_msd(
        frames(), cfg["md"]["timestep_fs"], cfg["md"]["dump_interval_steps"],
        settings["msd_fit_fraction"], settings.get("remove_drift_reference"),
    )
    run_metadata_path = Path(dump).resolve().parent / "metadata.json"
    run_metadata = json.loads(run_metadata_path.read_text(encoding="utf-8")) if run_metadata_path.exists() else {}
    for row in diffusion:
        row.update({key: run_metadata[key] for key in
                    ["run_id", "alloy", "vacancy", "temperature_k", "replicate"] if key in run_metadata})
    rdf = compute_rdf(frames(), cfg["elements"], settings["rdf_rmax_angstrom"], settings["rdf_bins"])
    sro = compute_sro(frames(), cfg["elements"], settings["sro_cutoff_angstrom"])
    clusters, cluster_frames = compute_clusters(frames(), settings["cluster_elements"],
                                                settings["cluster_cutoff_angstrom"])
    _write_csv(out / "msd.csv", msd)
    _write_csv(out / "diffusivity.csv", diffusion)
    _write_csv(out / "rdf.csv", rdf)
    _write_csv(out / "sro.csv", sro)
    _write_csv(out / "clusters.csv", clusters,
               ["frame", "timestep", "cluster_id", "size", *[f"n_{x}" for x in settings["cluster_elements"]]])
    _write_csv(out / "clusters_by_frame.csv", cluster_frames)
    dump_json({"source_dump": str(Path(dump).resolve()), "n_frames": len(cluster_frames), "settings": settings,
               "run_metadata": run_metadata},
              out / "analysis_metadata.json")
    return out


def analyze_campaign(cfg: dict, md_root: str | Path, out_root: str | Path) -> Path:
    """Analyze every run directory, retaining failures in a campaign report."""
    md_root, out_root = Path(md_root), Path(out_root)
    out_root.mkdir(parents=True, exist_ok=True)
    rows = []
    run_dirs = sorted(path for path in md_root.iterdir() if path.is_dir())
    for run in run_dirs:
        trajectory = run / "trajectory.dump"
        if not trajectory.exists():
            rows.append({"run_id": run.name, "status": "missing", "message": "trajectory.dump not found"})
            continue
        try:
            analyze_dump(cfg, trajectory, out_root / run.name)
            rows.append({"run_id": run.name, "status": "ok", "message": ""})
        except Exception as exc:
            rows.append({"run_id": run.name, "status": "failed", "message": str(exc).replace("\n", " ")[:500]})
    report = out_root / "campaign_report.csv"
    _write_csv(report, rows, ["run_id", "status", "message"])
    return report
