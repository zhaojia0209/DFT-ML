from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import numpy as np

from .atoms import Frame


def read_lammps_dump(path: str | Path, elements: list[str]) -> Iterator[Frame]:
    """Stream orthorhombic LAMMPS custom dumps with id/type and x/y/z or xu/yu/zu."""
    type_to_symbol = {i + 1: element for i, element in enumerate(elements)}
    with Path(path).open("r", encoding="utf-8") as handle:
        while True:
            line = handle.readline()
            if not line:
                return
            if not line.startswith("ITEM: TIMESTEP"):
                raise ValueError(f"Expected TIMESTEP marker, found {line.strip()!r}")
            timestep = int(handle.readline())
            if not handle.readline().startswith("ITEM: NUMBER OF ATOMS"):
                raise ValueError("Missing NUMBER OF ATOMS marker")
            n_atoms = int(handle.readline())
            box_header = handle.readline()
            if not box_header.startswith("ITEM: BOX BOUNDS"):
                raise ValueError("Missing BOX BOUNDS marker")
            if any(flag in box_header.split() for flag in ("xy", "xz", "yz")):
                raise NotImplementedError("Triclinic dump parsing is not yet supported")
            bounds = np.array([[float(x) for x in handle.readline().split()[:2]] for _ in range(3)])
            atom_header = handle.readline().split()[2:]
            required = {"id", "type"}
            if not required.issubset(atom_header):
                raise ValueError(f"Dump requires columns {sorted(required)}")
            coord_names = None
            wrapped = True
            for candidate, is_wrapped in [(('xu', 'yu', 'zu'), False), (('x', 'y', 'z'), True)]:
                if all(name in atom_header for name in candidate):
                    coord_names, wrapped = candidate, is_wrapped
                    break
            if coord_names is None:
                raise ValueError("Dump requires x/y/z or xu/yu/zu coordinates")
            table = np.array([[float(x) for x in handle.readline().split()] for _ in range(n_atoms)])
            col = {name: atom_header.index(name) for name in atom_header}
            ids = table[:, col["id"]].astype(int)
            order = np.argsort(ids)
            ids = ids[order]
            types = table[order, col["type"]].astype(int)
            positions = table[order][:, [col[x] for x in coord_names]]
            origin = bounds[:, 0]
            cell = np.diag(bounds[:, 1] - origin)
            positions -= origin
            symbols = [type_to_symbol[int(t)] for t in types]
            yield Frame(
                symbols, positions, cell, ids=ids,
                info={"timestep": timestep, "unwrapped": not wrapped, "origin": origin.tolist()},
            )


def write_lammps_dump(frames: list[Frame], path: str | Path) -> None:
    """Write a small custom dump, primarily for tests and synthetic demonstrations."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    elements = [el for el in ["Al", "Zn", "Mg", "Cu"] if any(el in f.symbols for f in frames)]
    type_map = {el: i + 1 for i, el in enumerate(elements)}
    with path.open("w", encoding="utf-8") as handle:
        for frame_index, frame in enumerate(frames):
            step = int(frame.info.get("timestep", frame_index))
            lengths = np.diag(frame.cell)
            handle.write(f"ITEM: TIMESTEP\n{step}\nITEM: NUMBER OF ATOMS\n{len(frame.symbols)}\n")
            handle.write("ITEM: BOX BOUNDS pp pp pp\n")
            for length in lengths:
                handle.write(f"0 {length:.12g}\n")
            handle.write("ITEM: ATOMS id type xu yu zu\n")
            for atom_id, symbol, xyz in zip(frame.ids, frame.symbols, frame.positions):
                handle.write(
                    f"{int(atom_id)} {type_map[symbol]} {xyz[0]:.12g} {xyz[1]:.12g} {xyz[2]:.12g}\n"
                )


def iter_strided(frames: Iterator[Frame], stride: int) -> Iterator[Frame]:
    for index, frame in enumerate(frames):
        if index % stride == 0:
            yield frame

