from __future__ import annotations

import csv
import json
import os
import shlex
from pathlib import Path

import numpy as np

from .atoms import Frame, fcc_conventional, minimum_image, read_poscar, write_poscar
from .config import dump_json, ensure_stage
from .vasp import collect_neb_energies, write_campaign_files, write_vasp_task


def _write_neb_potcar(task: Path, frame: Frame, cfg: dict) -> None:
    """Create the licensed POTCAR locally when available, plus a portable recipe."""
    vasp = cfg["vasp"]
    order = [element for element in cfg["elements"] if element in frame.symbols]
    root_text = str(vasp["potcar_root"])
    source_texts = [
        f"{root_text.rstrip('/')}/{vasp['potentials'][element]}/POTCAR" for element in order
    ]
    (task / "POTCAR.spec").write_text(
        "\n".join(f"{element} {source}" for element, source in zip(order, source_texts)) + "\n",
        encoding="utf-8",
    )
    local_compatible = not (os.name == "nt" and root_text.startswith("/"))
    sources = [Path(value).expanduser() for value in source_texts]
    if local_compatible and all(source.is_file() for source in sources):
        with (task / "POTCAR").open("wb") as output:
            for source in sources:
                with source.open("rb") as input_handle:
                    while chunk := input_handle.read(1024 * 1024):
                        output.write(chunk)
    source_lines = "\n".join(f"append_potcar {shlex.quote(value)}" for value in source_texts)
    (task / "prepare_potcar.sh").write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\n"
        "append_potcar() {\n"
        "  local source=\"$1\"\n"
        "  test -s \"$source\" || { echo \"Missing POTCAR: $source\" >&2; exit 2; }\n"
        "  cat \"$source\" >> POTCAR.tmp\n"
        "}\n"
        "if [[ ! -s POTCAR ]]; then\n"
        "  : > POTCAR.tmp\n"
        f"{source_lines}\n"
        "  mv POTCAR.tmp POTCAR\n"
        "fi\n",
        encoding="utf-8",
    )


def _write_workstation_campaign_scripts(stage: Path, cfg: dict) -> None:
    n_images = int(cfg["neb"]["images"])
    last = f"{n_images + 1:02d}"
    endpoints = f'''#!/usr/bin/env bash
set -uo pipefail
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
failed=0
for task in "$SCRIPT_DIR"/tasks/vacancy_exchange_*; do
  name="$(basename -- "$task")"
  if [[ -s "$task/00/OUTCAR" && -s "$task/{last}/OUTCAR" ]] \\
     && grep -q 'General timing and accounting' "$task/00/OUTCAR" \\
     && grep -q 'General timing and accounting' "$task/{last}/OUTCAR"; then
    echo "[skip] endpoints $name already complete"
    continue
  fi
  echo "[run] endpoints $name"
  if ! (cd "$task" && bash run_endpoints.sh </dev/null); then
    echo "[failed] endpoints $name" >&2
    failed=$((failed + 1))
  fi
done
exit "$failed"
'''
    neb = f'''#!/usr/bin/env bash
set -uo pipefail
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
failed=0
for task in "$SCRIPT_DIR"/tasks/vacancy_exchange_*; do
  name="$(basename -- "$task")"
  complete=true
  for image in $(seq -f '%02g' 1 {n_images}); do
    if [[ ! -s "$task/$image/OUTCAR" ]] \\
       || ! grep -q 'General timing and accounting' "$task/$image/OUTCAR"; then
      complete=false
      break
    fi
  done
  if [[ "$complete" == true ]]; then
    echo "[skip] NEB $name already complete"
    continue
  fi
  echo "[run] NEB $name"
  if ! (cd "$task" && bash run_neb.sh </dev/null); then
    echo "[failed] NEB $name" >&2
    failed=$((failed + 1))
  fi
done
exit "$failed"
'''
    (stage / "run_all_endpoints.sh").write_text(endpoints, encoding="utf-8")
    (stage / "run_all_neb.sh").write_text(neb, encoding="utf-8")


def _exchange_endpoints(cfg: dict, element: str) -> tuple[Frame, Frame, dict]:
    base = fcc_conventional(cfg["neb"]["supercell"], cfg["lattice"]["a0_angstrom"])
    box_center = 0.5 * np.sum(base.cell, axis=0)
    center = int(np.argmin(np.linalg.norm(minimum_image(base.positions - box_center, base.cell), axis=1)))
    delta = minimum_image(base.positions - base.positions[center], base.cell)
    distances = np.linalg.norm(delta, axis=1)
    distances[center] = np.inf
    neighbor = int(np.argmin(distances))
    base.symbols[neighbor] = element
    vacancy_position = base.positions[center].copy()
    moving_position = base.positions[neighbor].copy()
    keep = np.ones(len(base.symbols), dtype=bool)
    keep[center] = False
    initial = Frame([s for i, s in enumerate(base.symbols) if keep[i]], base.positions[keep], base.cell.copy())
    # Find the moving atom after deletion and move it along its nearest periodic vector.
    moving_new_index = neighbor - (1 if center < neighbor else 0)
    final = initial.copy()
    hop = minimum_image(vacancy_position - moving_position, base.cell)
    final.positions[moving_new_index] += hop
    return initial, final, {"moving_element": element, "hop_distance_angstrom": float(np.linalg.norm(hop)),
                            "vacancy_site_index": center, "moving_site_index": neighbor}


def generate_neb(cfg: dict) -> Path:
    stage = ensure_stage(cfg, "04_neb")
    tasks = stage / "tasks"
    records = []
    n_images = int(cfg["neb"]["images"])
    for element in ["Al", "Zn", "Mg", "Cu"]:
        initial, final, metadata = _exchange_endpoints(cfg, element)
        task = tasks / f"vacancy_exchange_{element}"
        task.mkdir(parents=True, exist_ok=True)
        # VASP IMAGES counts intermediate images; endpoints are 00 and N+1.
        for image in range(n_images + 2):
            fraction = image / (n_images + 1)
            frame = initial.copy()
            displacement = minimum_image(final.positions - initial.positions, initial.cell)
            frame.positions = initial.positions + fraction * displacement
            write_poscar(frame, task / f"{image:02d}" / "POSCAR", f"{element}-vacancy image {image}")
        vasp = cfg["vasp"]
        neb = cfg["neb"]
        neb_ncore = int(neb.get("ncore", 2))
        neb_command = str(neb.get("command", "mpirun -np 42 vasp_std"))
        incar = f"""SYSTEM = vacancy_exchange_{element}
ENCUT = {vasp['encut_ev']}
EDIFF = {vasp['ediff']}
EDIFFG = -{neb['force_tolerance_ev_per_angstrom']}
PREC = {vasp['prec']}
ALGO = {vasp['algo']}
LREAL = {vasp['lreal']}
NCORE = {neb_ncore}
ISMEAR = {vasp['ismear']}
SIGMA = {vasp['sigma_ev']}
ISYM = 0
IBRION = 3
POTIM = 0
NSW = 300
IMAGES = {n_images}
SPRING = {neb['spring_ev_per_angstrom2']}
LCLIMB = .TRUE.
ICHAIN = 0
LCHARG = .FALSE.
LWAVE = .FALSE.
KSPACING = {vasp['kspacing_inv_angstrom']}
KGAMMA = .TRUE.
"""
        (task / "INCAR").write_text(incar, encoding="utf-8")
        _write_neb_potcar(task, initial, cfg)
        endpoint_incar = incar.replace("IBRION = 3", "IBRION = 2").replace(
            f"IMAGES = {n_images}\nSPRING = {neb['spring_ev_per_angstrom2']}\nLCLIMB = .TRUE.\nICHAIN = 0\n", ""
        ).replace("POTIM = 0", "POTIM = 0.2")
        (task / "INCAR.relax").write_text(endpoint_incar, encoding="utf-8")
        last = f"{n_images + 1:02d}"
        endpoint_job = f"""#!/usr/bin/env bash
set -euo pipefail
bash prepare_potcar.sh
for image in 00 {last}; do
  (
    cd "$image"
    cp ../INCAR.relax INCAR
    ln -sf ../POTCAR POTCAR
    {vasp['command']}
    test -s CONTCAR
    cp CONTCAR POSCAR
    rm -f INCAR POTCAR
  )
done
echo 'Endpoints relaxed. Run: python scripts/06_neb.py --config <config> interpolate'
"""
        (task / "run_endpoints.sh").write_text(endpoint_job, encoding="utf-8")
        (task / "run_neb.sh").write_text(
            "#!/usr/bin/env bash\nset -euo pipefail\n"
            "bash prepare_potcar.sh\n"
            + "\n".join(
                f"test -s {image:02d}/POSCAR || {{ echo 'Missing {image:02d}/POSCAR' >&2; exit 2; }}"
                for image in range(n_images + 2)
            )
            + f"\n{neb_command} > vasp.stdout 2> vasp.stderr\n",
            encoding="utf-8",
        )
        record = {"task_id": task.name, **metadata, "images": n_images}
        dump_json(record, task / "metadata.json")
        records.append(record)
    manifest = stage / "manifest.csv"
    with manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    _write_workstation_campaign_scripts(stage, cfg)
    return manifest


def interpolate_relaxed_neb(cfg: dict) -> Path:
    """Rebuild intermediate images from relaxed endpoint CONTCAR/POSCAR files."""
    stage = ensure_stage(cfg, "04_neb")
    updated = []
    for task in sorted((stage / "tasks").glob("vacancy_exchange_*")):
        metadata = json.loads((task / "metadata.json").read_text(encoding="utf-8"))
        n_images = int(metadata["images"])
        last = task / f"{n_images + 1:02d}"
        initial_path = task / "00" / ("CONTCAR" if (task / "00" / "CONTCAR").exists() else "POSCAR")
        final_path = last / ("CONTCAR" if (last / "CONTCAR").exists() else "POSCAR")
        initial, final = read_poscar(initial_path), read_poscar(final_path)
        if initial.symbols != final.symbols:
            raise ValueError(f"Endpoint atom order differs in {task}")
        if not np.allclose(initial.cell, final.cell, atol=1e-6):
            raise ValueError(f"Endpoint cells differ in {task}; use fixed-cell endpoint relaxation")
        displacement = minimum_image(final.positions - initial.positions, initial.cell)
        write_poscar(initial, task / "00" / "POSCAR", f"{task.name} relaxed initial")
        write_poscar(final, last / "POSCAR", f"{task.name} relaxed final")
        for image in range(1, n_images + 1):
            fraction = image / (n_images + 1)
            frame = initial.copy()
            frame.positions = initial.positions + fraction * displacement
            write_poscar(frame, task / f"{image:02d}" / "POSCAR", f"{task.name} image {image}")
        updated.append(task.name)
    report = stage / "interpolation.json"
    dump_json({"updated_tasks": updated, "source": "relaxed CONTCAR when available"}, report)
    return report


def collect_neb(cfg: dict) -> Path:
    stage = ensure_stage(cfg, "04_neb")
    summary, paths = [], []
    for task in sorted((stage / "tasks").glob("vacancy_exchange_*")):
        metadata = json.loads((task / "metadata.json").read_text(encoding="utf-8"))
        try:
            energies = np.asarray(collect_neb_energies(task))
            relative = energies - energies[0]
            status = "ok"
            forward = float(np.max(relative))
            reverse = float(np.max(energies) - energies[-1])
            for image, value in enumerate(relative):
                paths.append({"task_id": task.name, "element": metadata["moving_element"],
                              "reaction_coordinate": image / (len(relative) - 1),
                              "relative_energy_ev": float(value)})
        except Exception as exc:
            status, forward, reverse = f"failed: {exc}", np.nan, np.nan
        summary.append({"task_id": task.name, "element": metadata["moving_element"],
                        "forward_barrier_ev": forward, "reverse_barrier_ev": reverse, "status": status})
    output = stage / "neb_barriers.csv"
    for path, rows in [(output, summary), (stage / "neb_paths.csv", paths)]:
        if rows:
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
    return output


def generate_neb_dense_singlepoints(cfg: dict) -> Path:
    """Generate consistent dense-k static calculations on converged NEB images."""
    neb_stage = ensure_stage(cfg, "04_neb")
    stage = ensure_stage(cfg, "04_neb_dense_singlepoints")
    tasks = stage / "tasks"
    tasks.mkdir(parents=True, exist_ok=True)
    records: list[dict] = []
    n_images = int(cfg["neb"]["images"])
    for source_task in sorted((neb_stage / "tasks").glob("vacancy_exchange_*")):
        if not source_task.is_dir():
            continue
        source_metadata = json.loads((source_task / "metadata.json").read_text(encoding="utf-8"))
        element = str(source_metadata["moving_element"])
        for image in range(n_images + 2):
            image_dir = source_task / f"{image:02d}"
            if 0 < image < n_images + 1:
                geometry = image_dir / "CONTCAR"
            else:
                geometry = image_dir / "POSCAR"
            if not geometry.is_file() or geometry.stat().st_size == 0:
                raise FileNotFoundError(f"Missing converged NEB geometry: {geometry}")
            frame = read_poscar(geometry)
            task_id = f"vacancy_exchange_{element}_image_{image:02d}"
            metadata = {
                "task_id": task_id,
                "group_id": f"vacancy_exchange_{element}",
                "category": "neb_dense_singlepoint",
                "config_type": "NEBDenseSinglePoint",
                "moving_element": element,
                "image": image,
                "reaction_coordinate": image / (n_images + 1),
                "source_geometry": str(geometry.resolve()),
                "n_atoms": len(frame.symbols),
            }
            write_vasp_task(
                frame,
                tasks / task_id,
                cfg,
                metadata,
                overrides={"IBRION": -1, "NSW": 0, "ISTART": 0, "ICHARG": 2},
            )
            records.append(metadata)
    if not records:
        raise RuntimeError(f"No converged NEB tasks found below {neb_stage / 'tasks'}")
    manifest = write_campaign_files(stage, records)
    dump_json(
        {
            "generated_tasks": len(records),
            "source_neb_stage": str(neb_stage.resolve()),
            "purpose": "consistent dense-k static energies on all converged NEB images",
            "expected_kpoint_mesh": "derived from vasp.kspacing_inv_angstrom",
        },
        stage / "generation.json",
    )
    return manifest


def _read_static_energy(outcar: Path) -> tuple[float, float]:
    import re

    pattern = re.compile(
        r"energy\s+without entropy=\s*([-+0-9.Ee]+)\s+energy\(sigma->0\)\s*=\s*([-+0-9.Ee]+)"
    )
    matches = pattern.findall(outcar.read_text(errors="ignore"))
    if not matches:
        raise RuntimeError(f"No final static energy found in {outcar}")
    without_entropy, sigma_zero = matches[-1]
    return float(without_entropy), float(sigma_zero)


def collect_neb_dense_singlepoints(cfg: dict) -> Path:
    """Collect dense-k energies and reduce them to forward/reverse barriers."""
    stage = ensure_stage(cfg, "04_neb_dense_singlepoints")
    rows: list[dict] = []
    failures: list[dict] = []
    for task in sorted((stage / "tasks").glob("vacancy_exchange_*_image_*")):
        metadata_path = task / "metadata.json"
        if not metadata_path.is_file():
            continue
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        outcar = task / "OUTCAR"
        try:
            if "General timing and accounting" not in outcar.read_text(errors="ignore"):
                raise RuntimeError("OUTCAR is incomplete")
            without_entropy, sigma_zero = _read_static_energy(outcar)
            rows.append(
                {
                    "task_id": metadata["task_id"],
                    "element": metadata["moving_element"],
                    "image": int(metadata["image"]),
                    "reaction_coordinate": float(metadata["reaction_coordinate"]),
                    "energy_sigma0_ev": sigma_zero,
                    "energy_without_entropy_ev": without_entropy,
                }
            )
        except Exception as exc:
            failures.append({"task_id": metadata["task_id"], "message": str(exc)})
    if failures:
        failure_path = stage / "dense_failures.csv"
        with failure_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["task_id", "message"])
            writer.writeheader()
            writer.writerows(failures)
        raise RuntimeError(f"{len(failures)} dense-k NEB tasks are incomplete; see {failure_path}")
    if not rows:
        raise RuntimeError("No dense-k NEB energies were collected")

    paths: list[dict] = []
    barriers: list[dict] = []
    for element in sorted({str(row["element"]) for row in rows}):
        group = sorted((row for row in rows if row["element"] == element), key=lambda row: row["image"])
        expected = list(range(int(cfg["neb"]["images"]) + 2))
        observed = [int(row["image"]) for row in group]
        if observed != expected:
            raise RuntimeError(f"Dense-k image sequence for {element} is {observed}; expected {expected}")
        energies = np.asarray([float(row["energy_sigma0_ev"]) for row in group])
        relative = energies - energies[0]
        for row, value in zip(group, relative):
            paths.append({**row, "relative_energy_ev": float(value)})
        endpoint_mismatch = float(energies[-1] - energies[0])
        barriers.append(
            {
                "element": element,
                "forward_barrier_ev": float(np.max(energies) - energies[0]),
                "reverse_barrier_ev": float(np.max(energies) - energies[-1]),
                "endpoint_mismatch_ev": endpoint_mismatch,
                "max_image": int(group[int(np.argmax(energies))]["image"]),
                "status": "ok" if abs(endpoint_mismatch) <= 0.05 else "check_endpoints",
            }
        )

    for path, data in [
        (stage / "neb_dense_energies.csv", rows),
        (stage / "neb_paths_dense.csv", paths),
        (stage / "neb_barriers_dense.csv", barriers),
    ]:
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)
    return stage / "neb_barriers_dense.csv"


def evaluate_neb_with_mace(cfg: dict, model: str | Path, device: str = "cpu") -> Path:
    """Evaluate converged DFT-NEB geometries with MACE and compare the paths."""
    try:
        from ase.io import read
        from mace.calculators import MACECalculator
    except ImportError as exc:
        raise RuntimeError("MACE NEB evaluation requires ASE and mace-torch") from exc

    stage = ensure_stage(cfg, "04_neb_dense_singlepoints")
    model_path = Path(model).expanduser().resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MACE model not found: {model_path}")
    calculator = MACECalculator(
        model_paths=str(model_path), device=device, default_dtype="float64"
    )
    rows: list[dict] = []
    for task in sorted((stage / "tasks").glob("vacancy_exchange_*_image_*")):
        metadata_path = task / "metadata.json"
        if not metadata_path.is_file():
            continue
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        atoms = read(task / "POSCAR")
        atoms.calc = calculator
        energy = float(atoms.get_potential_energy())
        forces = np.asarray(atoms.get_forces())
        rows.append({
            "task_id": metadata["task_id"],
            "element": metadata["moving_element"],
            "image": int(metadata["image"]),
            "reaction_coordinate": float(metadata["reaction_coordinate"]),
            "energy_mace_ev": energy,
            "force_rms_ev_per_angstrom": float(np.sqrt(np.mean(forces**2))),
            "force_max_ev_per_angstrom": float(np.max(np.linalg.norm(forces, axis=1))),
        })
    if not rows:
        raise RuntimeError(f"No dense NEB geometries found below {stage / 'tasks'}")

    dft_path = stage / "neb_dense_energies.csv"
    if not dft_path.is_file():
        raise FileNotFoundError(f"Collect DFT dense energies first: {dft_path}")
    with dft_path.open(newline="", encoding="utf-8") as handle:
        dft = {row["task_id"]: row for row in csv.DictReader(handle)}

    path_rows: list[dict] = []
    summary: list[dict] = []
    threshold = float(
        cfg.get("validation", {}).get("thresholds", {}).get("barrier_error_ev", 0.08)
    )
    for element in sorted({str(row["element"]) for row in rows}):
        group = sorted(
            (row for row in rows if row["element"] == element),
            key=lambda row: row["image"],
        )
        mace_energy = np.asarray([float(row["energy_mace_ev"]) for row in group])
        dft_energy = np.asarray([
            float(dft[row["task_id"]]["energy_sigma0_ev"]) for row in group
        ])
        mace_relative = mace_energy - mace_energy[0]
        dft_relative = dft_energy - dft_energy[0]
        error = mace_relative - dft_relative
        for row, mace_rel, dft_rel, delta in zip(
            group, mace_relative, dft_relative, error
        ):
            path_rows.append({
                **row,
                "dft_relative_energy_ev": float(dft_rel),
                "mace_relative_energy_ev": float(mace_rel),
                "relative_energy_error_ev": float(delta),
            })
        dft_barrier = float(np.max(dft_relative))
        mace_barrier = float(np.max(mace_relative))
        barrier_error = mace_barrier - dft_barrier
        dft_max = int(group[int(np.argmax(dft_relative))]["image"])
        mace_max = int(group[int(np.argmax(mace_relative))]["image"])
        summary.append({
            "element": element,
            "dft_forward_barrier_ev": dft_barrier,
            "mace_forward_barrier_ev": mace_barrier,
            "barrier_error_ev": barrier_error,
            "abs_barrier_error_ev": abs(barrier_error),
            "dft_max_image": dft_max,
            "mace_max_image": mace_max,
            "path_rmse_ev": float(np.sqrt(np.mean(error**2))),
            "path_max_abs_error_ev": float(np.max(np.abs(error))),
            "mace_endpoint_mismatch_ev": float(mace_relative[-1]),
            "status": (
                "pass"
                if abs(barrier_error) <= threshold and dft_max == mace_max
                else "check"
            ),
        })

    for output, data in [
        (stage / "neb_mace_energies.csv", rows),
        (stage / "neb_mace_paths.csv", path_rows),
        (stage / "neb_mace_vs_dft.csv", summary),
    ]:
        with output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)
    dump_json(
        {"model": str(model_path), "device": device,
         "barrier_error_threshold_ev": threshold},
        stage / "neb_mace_evaluation.json",
    )
    return stage / "neb_mace_vs_dft.csv"
