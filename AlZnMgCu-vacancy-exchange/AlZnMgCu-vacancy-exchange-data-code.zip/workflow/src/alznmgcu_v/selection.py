from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from .atoms import write_poscar
from .config import dump_json
from .trajectory import read_lammps_dump


def _farthest_points(features: np.ndarray, count: int) -> list[int]:
    if count <= 0:
        return []
    if len(features) <= count:
        return list(range(len(features)))
    if count == 1:
        return [0]
    std = np.std(features, axis=0)
    std[std < 1e-12] = 1.0
    z = (features - np.mean(features, axis=0)) / std
    selected = [0, len(z) - 1]
    distances = np.minimum(np.sum((z - z[0]) ** 2, axis=1), np.sum((z - z[-1]) ** 2, axis=1))
    while len(selected) < count:
        distances[selected] = -1
        index = int(np.argmax(distances))
        selected.append(index)
        distances = np.minimum(distances, np.sum((z - z[index]) ** 2, axis=1))
    return sorted(selected)


def select_representatives(
    cfg: dict, dump: str | Path, cluster_summary: str | Path, out: str | Path, count: int | None = None
) -> Path:
    with Path(cluster_summary).open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError("Cluster summary is empty")
    feature_names = ["n_clusters", "largest_cluster", "mean_cluster_size",
                     "fraction_in_clusters_ge_2", "fraction_in_clusters_ge_5"]
    features = np.asarray([[float(row[name]) for name in feature_names] for row in rows])
    count = int(count or cfg["analysis"]["representatives"])
    selected_rows = _farthest_points(features, min(count, len(rows)))
    requested_timesteps = {int(float(rows[i]["timestep"])): i for i in selected_rows}
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    selected_manifest = []
    for frame_index, frame in enumerate(read_lammps_dump(dump, cfg["elements"])):
        timestep = int(frame.info.get("timestep", frame_index))
        if timestep not in requested_timesteps:
            continue
        source_index = requested_timesteps[timestep]
        rank = selected_rows.index(source_index) + 1
        filename = f"representative_{rank:02d}_frame{frame_index:06d}.vasp"
        write_poscar(frame, out / filename, f"representative frame {frame_index}")
        source = rows[source_index]
        selected_manifest.append({"rank": rank, "frame": frame_index, "analysis_frame": source["frame"],
                                  "timestep": timestep, "file": filename,
                                  **{name: source[name] for name in feature_names}})
    selected_manifest.sort(key=lambda row: row["rank"])
    manifest = out / "manifest.csv"
    with manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(selected_manifest[0]))
        writer.writeheader()
        writer.writerows(selected_manifest)
    dump_json({"source_dump": str(Path(dump).resolve()), "features": feature_names,
               "selected_frames": [row["frame"] for row in selected_manifest]}, out / "selection.json")
    return manifest
