from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

from .config import dump_json


def _require_ase():
    try:
        from ase.io import read, write
    except ImportError as exc:
        raise RuntimeError("Dataset merging requires ASE: python3 -m pip install ase") from exc
    return read, write


def _structure_digest(atoms) -> str:
    digest = hashlib.sha256()
    digest.update(np.asarray(atoms.get_atomic_numbers(), dtype=np.int16).tobytes())
    digest.update(np.round(atoms.get_cell().array, 8).astype(np.float64).tobytes())
    digest.update(np.round(atoms.get_positions(), 8).astype(np.float64).tobytes())
    return digest.hexdigest()


def merge_datasets(inputs: list[str | Path], output: str | Path) -> Path:
    """Merge extxyz files, prefix split groups by source, and remove exact structures."""
    read, write = _require_ase()
    if len(inputs) < 2:
        raise ValueError("Dataset merge requires at least two input files")
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    merged = []
    seen = set()
    source_counts = {}
    duplicate_counts = {}
    for source_index, source_value in enumerate(inputs):
        source = Path(source_value)
        if not source.is_file():
            raise FileNotFoundError(source)
        source_label = f"{source_index:02d}_{source.stem}"
        frames = list(read(str(source), index=":"))
        source_counts[source_label] = len(frames)
        duplicate_counts[source_label] = 0
        for frame_index, atoms in enumerate(frames):
            if atoms.calc is None:
                raise ValueError(f"{source}:{frame_index} has no calculator results")
            missing = [key for key in ("energy", "forces", "stress") if key not in atoms.calc.results]
            if missing:
                raise ValueError(f"{source}:{frame_index} missing {', '.join(missing)}")
            structure_hash = _structure_digest(atoms)
            if structure_hash in seen:
                duplicate_counts[source_label] += 1
                continue
            seen.add(structure_hash)
            old_group = str(atoms.info.get("group_id", atoms.info.get("task_id", frame_index)))
            atoms.info["original_group_id"] = old_group
            atoms.info["group_id"] = f"{source_label}:{old_group}"
            atoms.info["source_dataset"] = str(source.resolve())
            atoms.info["source_frame_index"] = frame_index
            merged.append(atoms)
    if not merged:
        raise ValueError("No frames remained after merging")
    write(output, merged, format="extxyz", write_results=True)
    dump_json(
        {
            "inputs": [str(Path(value).resolve()) for value in inputs],
            "source_frame_counts": source_counts,
            "duplicates_removed": duplicate_counts,
            "merged_frames": len(merged),
            "group_ids_prefixed_by_source": True,
        },
        output.with_suffix(".merge.json"),
    )
    return output
