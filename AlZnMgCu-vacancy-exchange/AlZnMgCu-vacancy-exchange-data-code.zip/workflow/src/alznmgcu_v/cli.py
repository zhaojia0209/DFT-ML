from __future__ import annotations

import argparse
from pathlib import Path

from .analysis import analyze_campaign, analyze_dump
from .active_pool import (
    build_targeted_active_pool,
    generate_active_learning_vasp,
    select_targeted_active_pool,
)
from .calibration_database import build_calibration_database
from .config import load_config
from .dataset import merge_datasets
from .demo import smoke_demo
from .figures import make_figures
from .mace_workflow import (
    build_candidate_pool,
    make_pool_evaluation_commands,
    make_training_commands,
    select_active_learning,
    split_dataset,
)
from .md import generate_md
from .md_smoke import run_mace_md_smoke
from .neb import (
    collect_neb,
    collect_neb_dense_singlepoints,
    evaluate_neb_with_mace,
    generate_neb,
    generate_neb_dense_singlepoints,
    interpolate_relaxed_neb,
)
from .refined_database import build_refined_database
from .selection import select_representatives
from .setup_phase import initialize_phase01
from .validation import evaluate_validation, generate_validation, summarize_validation
from .vasp import build_dft_database, extract_vasp
from .vacancy_pair_database import build_vacancy_pair_database


def parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--config", default="configs/project.yaml", help="project YAML/JSON config")
    root = argparse.ArgumentParser(prog="alzmcv", description="Al-Zn-Mg-Cu-V paper workflow")
    sub = root.add_subparsers(dest="command", required=True)

    p = sub.add_parser("setup", parents=[common])
    p.add_argument("--strict", action="store_true", help="fail when required Phase 0/1 packages are missing")
    p = sub.add_parser("smoke", parents=[common])
    p = sub.add_parser("dft-build", parents=[common])
    p.add_argument("--limit", type=int, help="generate only N tasks for a pilot")
    p = sub.add_parser("refined-build", parents=[common])
    p.add_argument("--limit", type=int, help="generate only N refined tasks for inspection")
    p = sub.add_parser("calibration-build", parents=[common])
    p.add_argument("--limit", type=int, help="generate only N calibration tasks for inspection")
    p = sub.add_parser("vacancy-pair-build", parents=[common])
    p.add_argument("--limit", type=int, help="generate only N paired tasks for inspection")
    p = sub.add_parser("vasp-extract", parents=[common])
    p.add_argument("--tasks", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--all-ionic-steps", action="store_true", help="extract strided AIMD ionic frames")
    p.add_argument("--ionic-stride", type=int, default=10)
    p = sub.add_parser("dataset-merge", parents=[common])
    p.add_argument("--inputs", nargs="+", required=True, help="two or more extxyz datasets")
    p.add_argument("--output", required=True)

    p = sub.add_parser("mace", parents=[common])
    psub = p.add_subparsers(dest="action", required=True)
    prep = psub.add_parser("prepare")
    prep.add_argument("--dataset", required=True)
    psub.add_parser("commands")

    p = sub.add_parser("active-learn", parents=[common])
    p.add_argument("--predictions", nargs="+")
    p.add_argument("--output")
    p.add_argument("--pool", help="candidate extxyz; generate ensemble evaluation commands")
    p.add_argument("--models", nargs="+", help="model files for --pool")
    p.add_argument("--dump-to-pool", help="convert a LAMMPS dump to candidate extxyz")
    p.add_argument("--stride", type=int, default=10)
    p.add_argument("--max-frames", type=int)

    p = sub.add_parser("active-pool", parents=[common])
    pool_actions = p.add_subparsers(dest="action", required=True)
    generate_pool = pool_actions.add_parser("generate")
    generate_pool.add_argument("--neb-tasks", required=True)
    generate_pool.add_argument("--output", required=True)
    select_pool = pool_actions.add_parser("select")
    select_pool.add_argument("--predictions", nargs="+", required=True)
    select_pool.add_argument("--output", required=True)
    label_pool = pool_actions.add_parser("vasp")
    label_pool.add_argument("--selected", required=True)

    p = sub.add_parser("validate", parents=[common])
    psub = p.add_subparsers(dest="action", required=True)
    psub.add_parser("generate")
    evaluate = psub.add_parser("evaluate")
    evaluate.add_argument("--engine", choices=["dft", "mace"], required=True)
    evaluate.add_argument("--model")
    evaluate.add_argument("--device", default="cpu")
    summary = psub.add_parser("summarize")
    summary.add_argument("--reference", required=True)
    summary.add_argument("--prediction", required=True)

    p = sub.add_parser("neb", parents=[common])
    p.add_subparsers(dest="action", required=True).add_parser("generate")
    # argparse only allows adding each sibling explicitly.
    # Retrieve the action subparser and add collect through its choices' container.
    action = next(x for x in p._actions if isinstance(x, argparse._SubParsersAction))
    action.add_parser("interpolate")
    action.add_parser("collect")

    p = sub.add_parser("neb-dense", parents=[common])
    dense_actions = p.add_subparsers(dest="action", required=True)
    dense_actions.add_parser("generate")
    dense_actions.add_parser("collect")

    p = sub.add_parser("neb-mace", parents=[common])
    p.add_argument("--model", required=True)
    p.add_argument("--device", default="cpu")

    p = sub.add_parser("md-generate", parents=[common])
    p.add_argument("--model", required=True)
    p = sub.add_parser("md-smoke", parents=[common])
    p.add_argument("--model", required=True)
    p.add_argument("--output", default="work/md_smoke_v4")
    p.add_argument("--temperatures", nargs="+", type=int, default=[300, 600, 900, 1200])
    p.add_argument("--nvt-steps", type=int, default=1000)
    p.add_argument("--nve-steps", type=int, default=3000)
    p.add_argument("--timestep-fs", type=float, default=1.0)
    p.add_argument("--sample-interval", type=int, default=20)
    p = sub.add_parser("analyze", parents=[common])
    p.add_argument("--dump")
    p.add_argument("--out")
    p.add_argument("--md-root", help="batch mode: directory containing run directories")
    p.add_argument("--out-root", help="batch mode: analysis campaign directory")
    p = sub.add_parser("select", parents=[common])
    p.add_argument("--dump", required=True)
    p.add_argument("--cluster-summary", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--count", type=int)
    p = sub.add_parser("figures", parents=[common])
    p.add_argument("--analysis-root", required=True)
    p.add_argument("--out", required=True)
    return root


def main(argv: list[str] | None = None) -> None:
    args = parser().parse_args(argv)
    cfg = load_config(args.config)
    if args.command == "setup":
        result = initialize_phase01(cfg, args.strict)
    elif args.command == "smoke":
        result = smoke_demo(cfg)
    elif args.command == "dft-build":
        result = build_dft_database(cfg, args.limit)
    elif args.command == "refined-build":
        result = build_refined_database(cfg, args.limit)
    elif args.command == "calibration-build":
        result = build_calibration_database(cfg, args.limit)
    elif args.command == "vacancy-pair-build":
        result = build_vacancy_pair_database(cfg, args.limit)
    elif args.command == "vasp-extract":
        extracted, failed = extract_vasp(
            args.tasks, args.output, args.all_ionic_steps, args.ionic_stride
        )
        result = f"{args.output} ({extracted} frames extracted, {failed} tasks failed)"
    elif args.command == "dataset-merge":
        result = merge_datasets(args.inputs, args.output)
    elif args.command == "mace":
        result = split_dataset(cfg, args.dataset) if args.action == "prepare" else make_training_commands(cfg)
    elif args.command == "active-learn":
        if args.dump_to_pool:
            if not args.output:
                raise SystemExit("--dump-to-pool requires --output")
            result = build_candidate_pool(cfg, args.dump_to_pool, args.output, args.stride, args.max_frames)
        elif args.pool:
            if not args.models:
                raise SystemExit("--pool requires --models")
            result = make_pool_evaluation_commands(cfg, args.pool, args.models)
        else:
            if not args.predictions or not args.output:
                raise SystemExit("selection requires --predictions and --output")
            result = select_active_learning(cfg, args.predictions, args.output)
    elif args.command == "active-pool":
        if args.action == "generate":
            result = build_targeted_active_pool(cfg, args.neb_tasks, args.output)
        elif args.action == "select":
            result = select_targeted_active_pool(args.predictions, args.output)
        else:
            result = generate_active_learning_vasp(cfg, args.selected)
    elif args.command == "validate":
        if args.action == "generate":
            result = generate_validation(cfg)
        elif args.action == "evaluate":
            result = evaluate_validation(cfg, args.engine, args.model, args.device)
        else:
            result = summarize_validation(cfg, args.reference, args.prediction)
    elif args.command == "neb":
        if args.action == "generate":
            result = generate_neb(cfg)
        elif args.action == "interpolate":
            result = interpolate_relaxed_neb(cfg)
        else:
            result = collect_neb(cfg)
    elif args.command == "neb-dense":
        if args.action == "generate":
            result = generate_neb_dense_singlepoints(cfg)
        else:
            result = collect_neb_dense_singlepoints(cfg)
    elif args.command == "neb-mace":
        result = evaluate_neb_with_mace(cfg, args.model, args.device)
    elif args.command == "md-generate":
        result = generate_md(cfg, args.model)
    elif args.command == "md-smoke":
        result = run_mace_md_smoke(
            cfg, args.model, args.output, args.temperatures,
            args.nvt_steps, args.nve_steps, args.timestep_fs, args.sample_interval,
        )
    elif args.command == "analyze":
        if args.md_root:
            if not args.out_root:
                raise SystemExit("--md-root requires --out-root")
            result = analyze_campaign(cfg, args.md_root, args.out_root)
        else:
            if not args.dump or not args.out:
                raise SystemExit("single-run analysis requires --dump and --out")
            result = analyze_dump(cfg, args.dump, args.out)
    elif args.command == "select":
        result = select_representatives(cfg, args.dump, args.cluster_summary, args.out, args.count)
    elif args.command == "figures":
        result = make_figures(cfg, args.analysis_root, args.out)
    else:  # pragma: no cover
        raise AssertionError(args.command)
    print(result)
