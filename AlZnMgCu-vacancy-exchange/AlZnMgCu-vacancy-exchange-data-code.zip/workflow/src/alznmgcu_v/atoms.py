from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import numpy as np


@dataclass
class Frame:
    symbols: list[str]
    positions: np.ndarray
    cell: np.ndarray
    ids: np.ndarray | None = None
    forces: np.ndarray | None = None
    energy: float | None = None
    stress: np.ndarray | None = None
    info: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.positions = np.asarray(self.positions, dtype=float).reshape(-1, 3)
        self.cell = np.asarray(self.cell, dtype=float).reshape(3, 3)
        if len(self.symbols) != len(self.positions):
            raise ValueError("symbols and positions have different lengths")
        if self.ids is None:
            self.ids = np.arange(1, len(self.symbols) + 1, dtype=int)
        else:
            self.ids = np.asarray(self.ids, dtype=int)
        if self.forces is not None:
            self.forces = np.asarray(self.forces, dtype=float).reshape(-1, 3)

    def copy(self) -> "Frame":
        return Frame(
            list(self.symbols), self.positions.copy(), self.cell.copy(), self.ids.copy(),
            None if self.forces is None else self.forces.copy(), self.energy,
            None if self.stress is None else np.asarray(self.stress).copy(), dict(self.info),
        )

    @property
    def volume(self) -> float:
        return abs(float(np.linalg.det(self.cell)))


def fcc_conventional(supercell: Iterable[int], a0: float, symbol: str = "Al") -> Frame:
    reps = np.asarray(list(supercell), dtype=int)
    if reps.shape != (3,) or np.any(reps <= 0):
        raise ValueError("supercell must contain three positive integers")
    basis = np.array([[0, 0, 0], [0, 0.5, 0.5], [0.5, 0, 0.5], [0.5, 0.5, 0]])
    frac = []
    for i in range(reps[0]):
        for j in range(reps[1]):
            for k in range(reps[2]):
                frac.extend((basis + [i, j, k]) / reps)
    cell = np.diag(reps * float(a0))
    positions = np.asarray(frac) @ cell
    return Frame([symbol] * len(positions), positions, cell)


def composition_counts(n_sites: int, fractions: dict[str, float]) -> dict[str, int]:
    if any(float(v) < 0 for v in fractions.values()):
        raise ValueError("atomic fractions cannot be negative")
    if sum(float(v) for v in fractions.values()) >= 1.0:
        raise ValueError("non-Al fractions must sum to less than one")
    raw = {el: n_sites * float(x) for el, x in fractions.items()}
    counts = {el: int(np.floor(v)) for el, v in raw.items()}
    target = int(round(sum(raw.values())))
    order = sorted(raw, key=lambda el: (raw[el] - counts[el], el), reverse=True)
    for el in order[: target - sum(counts.values())]:
        counts[el] += 1
    return counts


def decorate_alloy(
    frame: Frame,
    fractions: dict[str, float],
    vacancy_fraction: float = 0.0,
    seed: int = 0,
) -> Frame:
    rng = np.random.default_rng(seed)
    out = frame.copy()
    n_sites = len(out.symbols)
    indices = rng.permutation(n_sites)
    counts = composition_counts(n_sites, fractions)
    cursor = 0
    for element in sorted(counts):
        chosen = indices[cursor : cursor + counts[element]]
        for idx in chosen:
            out.symbols[int(idx)] = element
        cursor += counts[element]
    n_vac = int(round(n_sites * float(vacancy_fraction)))
    if vacancy_fraction > 0 and n_vac == 0:
        n_vac = 1
    if n_vac:
        vacancies = np.sort(indices[cursor : cursor + n_vac])
        keep = np.ones(n_sites, dtype=bool)
        keep[vacancies] = False
        out.symbols = [s for i, s in enumerate(out.symbols) if keep[i]]
        out.positions = out.positions[keep]
        out.ids = np.arange(1, len(out.symbols) + 1)
        out.info["vacancy_site_indices"] = vacancies.tolist()
    out.info.update({"seed": int(seed), "target_fractions": fractions, "n_sites": n_sites})
    return out


def minimum_image(delta: np.ndarray, cell: np.ndarray) -> np.ndarray:
    inv = np.linalg.inv(cell)
    frac = np.asarray(delta) @ inv
    frac -= np.round(frac)
    return frac @ cell


def write_poscar(frame: Frame, path: str | Path, comment: str = "AlZnMgCuV") -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    order = []
    for preferred in ["Al", "Zn", "Mg", "Cu"]:
        if preferred in frame.symbols:
            order.append(preferred)
    order.extend(sorted(set(frame.symbols) - set(order)))
    indices = [i for el in order for i, symbol in enumerate(frame.symbols) if symbol == el]
    inv = np.linalg.inv(frame.cell)
    frac = frame.positions[indices] @ inv
    frac %= 1.0
    lines = [comment, "1.0"]
    lines += ["  " + "  ".join(f"{x:18.12f}" for x in row) for row in frame.cell]
    lines += ["  " + "  ".join(order)]
    lines += ["  " + "  ".join(str(frame.symbols.count(el)) for el in order), "Direct"]
    lines += ["  " + "  ".join(f"{x:18.12f}" for x in row) for row in frac]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def read_poscar(path: str | Path) -> Frame:
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    scale = float(lines[1].split()[0])
    cell = np.array([[float(x) for x in lines[i].split()] for i in range(2, 5)]) * scale
    elements = lines[5].split()
    counts = [int(x) for x in lines[6].split()]
    cursor = 7
    if lines[cursor].strip().lower().startswith("s"):
        cursor += 1
    direct = lines[cursor].strip().lower().startswith("d")
    cursor += 1
    n = sum(counts)
    coords = np.array([[float(x) for x in lines[i].split()[:3]] for i in range(cursor, cursor + n)])
    positions = coords @ cell if direct else coords * scale
    symbols = [el for el, count in zip(elements, counts) for _ in range(count)]
    return Frame(symbols, positions, cell)


def write_lammps_data(frame: Frame, path: str | Path, elements: list[str]) -> None:
    if not np.allclose(frame.cell, np.diag(np.diag(frame.cell))):
        raise ValueError("LAMMPS writer currently expects an orthorhombic cell")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    type_map = {el: i + 1 for i, el in enumerate(elements)}
    masses = {"Al": 26.9815385, "Zn": 65.38, "Mg": 24.305, "Cu": 63.546}
    lengths = np.diag(frame.cell)
    lines = ["Al-Zn-Mg-Cu generated structure", "", f"{len(frame.symbols)} atoms",
             f"{len(elements)} atom types", "",
             f"0.0 {lengths[0]:.12f} xlo xhi", f"0.0 {lengths[1]:.12f} ylo yhi",
             f"0.0 {lengths[2]:.12f} zlo zhi", "", "Masses", ""]
    lines += [f"{type_map[el]} {masses[el]:.8f} # {el}" for el in elements]
    lines += ["", "Atoms # atomic", ""]
    for atom_id, (el, xyz) in enumerate(zip(frame.symbols, frame.positions), 1):
        lines.append(f"{atom_id} {type_map[el]} {xyz[0]:.12f} {xyz[1]:.12f} {xyz[2]:.12f}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_extxyz(frames: Iterable[Frame], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for frame in frames:
            lattice = " ".join(f"{x:.12g}" for x in frame.cell.ravel())
            fields = [f'Lattice="{lattice}"', 'Properties=species:S:1:pos:R:3']
            if frame.forces is not None:
                fields[1] += ":forces:R:3"
            if frame.energy is not None:
                fields.append(f"energy={frame.energy:.16g}")
            for key in ("task_id", "group_id", "config_type", "category", "run_id", "timestep"):
                if key in frame.info:
                    value = frame.info[key]
                    if isinstance(value, (int, float)):
                        fields.append(f"{key}={value}")
                    else:
                        escaped = str(value).replace('"', "'")
                        fields.append(f'{key}="{escaped}"')
            fields.append('pbc="T T T"')
            handle.write(f"{len(frame.symbols)}\n{' '.join(fields)}\n")
            for i, (symbol, pos) in enumerate(zip(frame.symbols, frame.positions)):
                row = [symbol, *(f"{x:.12g}" for x in pos)]
                if frame.forces is not None:
                    row.extend(f"{x:.12g}" for x in frame.forces[i])
                handle.write(" ".join(row) + "\n")
