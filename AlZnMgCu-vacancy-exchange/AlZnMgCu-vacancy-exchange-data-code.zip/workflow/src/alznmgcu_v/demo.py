from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from .analysis import analyze_dump
from .atoms import decorate_alloy, fcc_conventional, read_poscar, write_lammps_data, write_poscar
from .config import dump_json
from .trajectory import write_lammps_dump


def smoke_demo(cfg: dict) -> Path:
    """Run a dependency-light synthetic end-to-end check (no VASP/MACE/LAMMPS)."""
    out = Path(cfg["_workdir"]) / "demo"
    out.mkdir(parents=True, exist_ok=True)
    # Large enough for configured RDF cutoff and small enough for a quick test.
    base = fcc_conventional([5, 5, 5], cfg["lattice"]["a0_angstrom"])
    alloy = decorate_alloy(base, {"Zn": 0.04, "Mg": 0.04, "Cu": 0.01}, 0.002, cfg["seed"])
    write_poscar(alloy, out / "structure.vasp", "synthetic smoke structure")
    reread = read_poscar(out / "structure.vasp")
    if len(reread.symbols) != len(alloy.symbols) or not np.allclose(reread.cell, alloy.cell):
        raise RuntimeError("POSCAR round-trip failed")
    write_lammps_data(alloy, out / "structure.data", cfg["elements"])

    rng = np.random.default_rng(cfg["seed"])
    frames = []
    positions = alloy.positions.copy()
    for index in range(8):
        frame = alloy.copy()
        # Unwrapped random walk with slightly faster solutes gives non-zero observables.
        if index:
            scale = np.array([1.0 if el == "Al" else 1.8 for el in alloy.symbols])[:, None]
            positions += rng.normal(0, 0.025, positions.shape) * scale
        frame.positions = positions.copy()
        frame.info.update({"timestep": index * 1000, "unwrapped": True})
        frames.append(frame)
    dump = out / "trajectory.dump"
    write_lammps_dump(frames, dump)

    demo_cfg = dict(cfg)
    demo_cfg["analysis"] = dict(cfg["analysis"])
    demo_cfg["analysis"].update({"rdf_rmax_angstrom": 8.0, "rdf_bins": 40})
    analyze_dump(demo_cfg, dump, out / "analysis")
    checks = {
        "atoms": len(alloy.symbols), "frames": len(frames),
        "outputs": sorted(path.name for path in (out / "analysis").iterdir()),
    }
    dump_json(checks, out / "smoke_report.json")
    return out / "smoke_report.json"

