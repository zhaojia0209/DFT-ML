from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from .atoms import Frame, decorate_alloy, fcc_conventional
from .config import ensure_stage, stable_seed
from .vasp import write_campaign_files, write_vasp_task


def _prediction(atoms) -> tuple[float, np.ndarray]:
    if "MACE_energy" in atoms.info:
        energy = float(atoms.info["MACE_energy"])
    elif "energy" in atoms.info:
        energy = float(atoms.info["energy"])
    else:
        energy = float(atoms.get_potential_energy())
    if "MACE_forces" in atoms.arrays:
        forces = np.asarray(atoms.arrays["MACE_forces"], dtype=float)
    elif "forces" in atoms.arrays:
        forces = np.asarray(atoms.arrays["forces"], dtype=float)
    else:
        forces = np.asarray(atoms.get_forces(), dtype=float)
    return energy, forces


def build_targeted_active_pool(
    cfg: dict, neb_tasks: str | Path, output: str | Path
) -> Path:
    """Build perturbed transition-state and random vacancy environments."""
    try:
        from ase import Atoms
        from ase.io import read, write
    except ImportError as exc:
        raise RuntimeError("Active-learning pool generation requires ASE") from exc

    neb_tasks = Path(neb_tasks)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frames = []
    counts: dict[str, int] = {}
    variants = {"Al": 6, "Mg": 8, "Zn": 4, "Cu": 4}
    sigmas = [0.01, 0.02, 0.035, 0.05, 0.07, 0.09, 0.11, 0.13]

    for task in sorted(neb_tasks.glob("vacancy_exchange_*_image_*")):
        metadata_path = task / "metadata.json"
        if not metadata_path.is_file():
            continue
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        element = str(metadata["moving_element"])
        image = int(metadata["image"])
        source = read(task / "POSCAR")
        bucket = f"neb_{element}"
        for variant in range(variants[element]):
            atoms = source.copy()
            seed = stable_seed(cfg["seed"], "al_pool_v1", element, image, variant)
            rng = np.random.default_rng(seed)
            volume_strain = float(rng.uniform(-0.008, 0.008))
            factor = (1.0 + volume_strain) ** (1.0 / 3.0)
            atoms.set_cell(atoms.cell.array * factor, scale_atoms=True)
            sigma = sigmas[variant]
            atoms.positions += rng.normal(0.0, sigma, atoms.positions.shape)
            atoms.info.update({
                "task_id": f"alv1_{element}_image{image:02d}_v{variant:02d}",
                "group_id": f"alv1_{element}_image{image:02d}",
                "config_type": "ALNEBPerturbed",
                "pool_family": "neb_perturbed",
                "moving_element": element,
                "source_image": image,
                "variant": variant,
                "displacement_sigma_angstrom": sigma,
                "volume_strain": volume_strain,
                "seed": int(seed),
            })
            atoms.calc = None
            frames.append(atoms)
            counts[bucket] = counts.get(bucket, 0) + 1

    base = fcc_conventional([3, 3, 3], float(cfg["lattice"]["a0_angstrom"]))
    for alloy in cfg["alloys"]:
        for variant in range(20):
            seed = stable_seed(cfg["seed"], "al_pool_v1_random", alloy["name"], variant)
            rng = np.random.default_rng(seed)
            frame = decorate_alloy(base, alloy["fractions"], 1.0 / len(base.symbols), seed)
            volume_strain = float(rng.uniform(-0.012, 0.012))
            factor = (1.0 + volume_strain) ** (1.0 / 3.0)
            frame.cell *= factor
            frame.positions *= factor
            sigma = float([0.02, 0.05, 0.08, 0.12][variant % 4])
            frame.positions += rng.normal(0.0, sigma, frame.positions.shape)
            atoms = Atoms(
                symbols=frame.symbols, positions=frame.positions, cell=frame.cell, pbc=True
            )
            atoms.info.update({
                "task_id": f"alv1_random_{alloy['name']}_v{variant:02d}",
                "group_id": f"alv1_random_{alloy['name']}_{variant:02d}",
                "config_type": "ALRandomVacancy",
                "pool_family": "random_defect",
                "alloy": alloy["name"],
                "variant": variant,
                "displacement_sigma_angstrom": sigma,
                "volume_strain": volume_strain,
                "seed": int(seed),
            })
            frames.append(atoms)
            counts["random_defect"] = counts.get("random_defect", 0) + 1

    if not frames:
        raise RuntimeError(f"No candidate structures generated from {neb_tasks}")
    write(output, frames, format="extxyz")
    output.with_suffix(".json").write_text(
        json.dumps({"frames": len(frames), "counts": counts,
                    "neb_tasks": str(neb_tasks.resolve())}, indent=2) + "\n",
        encoding="utf-8",
    )
    return output


def select_targeted_active_pool(predictions: list[str], output: str | Path) -> Path:
    """Select a fixed, mechanism-focused quota using ensemble force disagreement."""
    try:
        from ase.io import read, write
    except ImportError as exc:
        raise RuntimeError("Active-learning selection requires ASE") from exc
    if len(predictions) < 3:
        raise ValueError("Targeted selection requires three ensemble predictions")
    ensembles = [read(path, index=":") for path in predictions]
    lengths = {len(items) for items in ensembles}
    if len(lengths) != 1:
        raise ValueError("Prediction files have different frame counts")
    n_frames = lengths.pop()
    uncertainty = []
    for index in range(n_frames):
        energies, forces = zip(*(_prediction(items[index]) for items in ensembles))
        force_std = np.std(np.stack(forces), axis=0)
        first = ensembles[0][index]
        family = str(first.info.get("pool_family", "unknown"))
        element = str(first.info.get("moving_element", ""))
        bucket = f"neb_{element}" if family == "neb_perturbed" else family
        uncertainty.append({
            "frame": index,
            "task_id": str(first.info.get("task_id", index)),
            "bucket": bucket,
            "energy_std_ev_per_atom": float(np.std(energies) / len(first)),
            "max_force_std_ev_per_angstrom": float(
                np.max(np.linalg.norm(force_std, axis=1))
            ),
            "mean_force_std_ev_per_angstrom": float(
                np.mean(np.linalg.norm(force_std, axis=1))
            ),
        })

    quotas = {"neb_Mg": 20, "neb_Al": 10, "neb_Zn": 5, "neb_Cu": 5,
              "random_defect": 20}
    selected: list[int] = []
    for bucket, count in quotas.items():
        members = [row for row in uncertainty if row["bucket"] == bucket]
        members.sort(key=lambda row: row["max_force_std_ev_per_angstrom"], reverse=True)
        selected.extend(int(row["frame"]) for row in members[:count])
    if len(selected) != sum(quotas.values()):
        raise RuntimeError(f"Quota selection produced {len(selected)} rather than 60 frames")

    chosen = []
    by_index = {int(row["frame"]): row for row in uncertainty}
    for rank, index in enumerate(selected):
        atoms = ensembles[0][index].copy()
        atoms.calc = None
        for key in list(atoms.info):
            if key.startswith("MACE_") or key in {"energy", "free_energy", "stress"}:
                atoms.info.pop(key, None)
        for key in list(atoms.arrays):
            if key.startswith("MACE_") or key == "forces":
                atoms.arrays.pop(key, None)
        atoms.info.update({
            "selection_rank": rank,
            "pool_index": index,
            "ensemble_max_force_std_ev_per_angstrom": by_index[index][
                "max_force_std_ev_per_angstrom"
            ],
        })
        chosen.append(atoms)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    write(output, chosen, format="extxyz")
    with output.with_suffix(".csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(uncertainty[0]))
        writer.writeheader()
        writer.writerows(uncertainty)
    output.with_suffix(".json").write_text(
        json.dumps({"predictions": predictions, "quotas": quotas,
                    "selected_indices": selected}, indent=2) + "\n",
        encoding="utf-8",
    )
    return output


def generate_active_learning_vasp(cfg: dict, selected: str | Path) -> Path:
    """Create static VASP labels for the selected active-learning structures."""
    try:
        from ase.io import read
    except ImportError as exc:
        raise RuntimeError("Active-learning VASP generation requires ASE") from exc
    selected = Path(selected)
    atoms_list = read(selected, index=":")
    if len(atoms_list) != 60:
        raise ValueError(f"Expected 60 selected structures, found {len(atoms_list)}")
    stage = ensure_stage(cfg, "01_dft_labels")
    tasks = stage / "tasks"
    tasks.mkdir(parents=True, exist_ok=True)
    records = []
    seen = set()
    for index, atoms in enumerate(atoms_list):
        source_id = str(atoms.info.get("task_id", f"selected_{index:04d}"))
        task_id = f"al_v1_{index:04d}_{source_id}"
        if task_id in seen:
            raise ValueError(f"Duplicate active-learning task id: {task_id}")
        seen.add(task_id)
        family = str(atoms.info.get("pool_family", "unknown"))
        energy_weight = 5.0 if family == "neb_perturbed" else 2.0
        metadata = {
            "task_id": task_id,
            "group_id": task_id,
            "category": "active_learning_v1",
            "campaign": "defect_transition_active_learning_v1",
            "config_type": "ALNEBLabel" if family == "neb_perturbed" else "ALRandomDefectLabel",
            "pool_family": family,
            "source_task_id": source_id,
            "pool_index": int(atoms.info.get("pool_index", -1)),
            "selection_rank": int(atoms.info.get("selection_rank", index)),
            "moving_element": str(atoms.info.get("moving_element", "")),
            "source_image": int(atoms.info.get("source_image", -1)),
            "alloy": str(atoms.info.get("alloy", "")),
            "ensemble_max_force_std_ev_per_angstrom": float(
                atoms.info.get("ensemble_max_force_std_ev_per_angstrom", 0.0)
            ),
            "config_energy_weight": energy_weight,
            "config_forces_weight": 1.0,
            "config_stress_weight": 0.1,
            "excluded_from_validation": True,
            "n_atoms": len(atoms),
        }
        frame = Frame(
            atoms.get_chemical_symbols(), atoms.positions.copy(), atoms.cell.array.copy()
        )
        write_vasp_task(
            frame, tasks / task_id, cfg, metadata,
            overrides={"IBRION": -1, "NSW": 0, "ISTART": 0, "ICHARG": 2},
        )
        records.append(metadata)
    manifest = write_campaign_files(stage, records)
    (stage / "generation.json").write_text(
        json.dumps({"selected": str(selected.resolve()), "generated_tasks": len(records),
                    "static_labels": True, "ionic_relaxation": False}, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest
