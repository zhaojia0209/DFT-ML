from __future__ import annotations

import hashlib
import json
import copy
from pathlib import Path
from typing import Any


def load_config(path: str | Path) -> dict[str, Any]:
    """Load YAML (or the JSON subset of YAML) and attach resolved paths."""
    path = Path(path).resolve()
    text = path.read_text(encoding="utf-8")
    try:
        import yaml

        cfg = yaml.safe_load(text)
    except ImportError:
        cfg = json.loads(text)
    if not isinstance(cfg, dict):
        raise ValueError(f"Configuration must be a mapping: {path}")
    if "extends" in cfg:
        parent_path = Path(cfg.pop("extends"))
        if not parent_path.is_absolute():
            parent_path = path.parent / parent_path
        parent = load_config(parent_path)
        parent.pop("_config_path", None)
        parent.pop("_project_root", None)
        parent.pop("_workdir", None)

        def merge(base: dict, override: dict) -> dict:
            result = copy.deepcopy(base)
            for key, value in override.items():
                if isinstance(value, dict) and isinstance(result.get(key), dict):
                    result[key] = merge(result[key], value)
                else:
                    result[key] = copy.deepcopy(value)
            return result

        cfg = merge(parent, cfg)
    cfg["_config_path"] = str(path)
    cfg["_project_root"] = str(path.parent.parent.resolve())
    workdir = Path(cfg.get("workdir", "work"))
    if not workdir.is_absolute():
        workdir = Path(cfg["_project_root"]) / workdir
    cfg["_workdir"] = str(workdir.resolve())
    return cfg


def ensure_stage(cfg: dict[str, Any], stage: str) -> Path:
    path = Path(cfg["_workdir"]) / stage
    path.mkdir(parents=True, exist_ok=True)
    return path


def stable_seed(base: int, *parts: object) -> int:
    payload = ":".join([str(base), *(str(p) for p in parts)]).encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:4], "little")


def dump_json(data: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
