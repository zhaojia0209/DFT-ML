from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from .config import dump_json


COLORS = {"Al": "#606060", "Zn": "#2C7BB6", "Mg": "#1A9641", "Cu": "#D7191C"}


def _read_rows(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _save(fig, stem: Path) -> list[str]:
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    return [str(stem.with_suffix(".pdf")), str(stem.with_suffix(".png"))]


def make_figures(cfg: dict, analysis_root: str | Path, out: str | Path) -> Path:
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("Figure generation requires matplotlib: pip install matplotlib") from exc
    analysis_root, out = Path(analysis_root), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "sans-serif", "font.size": 8, "axes.linewidth": 0.8,
        "xtick.direction": "in", "ytick.direction": "in", "legend.frameon": False,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    manifest = []
    runs = [path for path in sorted(analysis_root.iterdir()) if path.is_dir()] if analysis_root.exists() else []
    all_diffusion = []
    for run in runs:
        diffusion_path = run / "diffusivity.csv"
        if diffusion_path.exists():
            for row in _read_rows(diffusion_path):
                row["_source"] = str(diffusion_path)
                all_diffusion.append(row)
        msd_path = run / "msd.csv"
        if msd_path.exists():
            rows = _read_rows(msd_path)
            grouped = defaultdict(list)
            for row in rows:
                grouped[row["element"]].append((float(row["time_ps"]), float(row["msd_angstrom2"])))
            fig, ax = plt.subplots(figsize=(3.35, 2.6))
            for element, points in sorted(grouped.items()):
                values = np.asarray(points)
                ax.plot(values[:, 0], values[:, 1], label=element, color=COLORS.get(element), lw=1.2)
            ax.set(xlabel="Time (ps)", ylabel=r"MSD ($\mathrm{\AA^2}$)")
            ax.legend(ncol=2)
            outputs = _save(fig, out / f"msd_{run.name}")
            plt.close(fig)
            manifest.append({"figure": f"msd_{run.name}", "inputs": [str(msd_path)], "outputs": outputs})

        rdf_path = run / "rdf.csv"
        if rdf_path.exists():
            rows = _read_rows(rdf_path)
            grouped = defaultdict(list)
            for row in rows:
                grouped[row["pair"]].append((float(row["r_angstrom"]), float(row["g_r"])))
            fig, ax = plt.subplots(figsize=(3.35, 2.6))
            for pair, points in sorted(grouped.items()):
                if pair == "Al-Al":
                    continue
                values = np.asarray(points)
                ax.plot(values[:, 0], values[:, 1], label=pair, lw=1.0)
            ax.set(xlabel=r"$r$ ($\mathrm{\AA}$)", ylabel=r"$g(r)$", xlim=(0, cfg["analysis"]["rdf_rmax_angstrom"]))
            ax.legend(fontsize=6, ncol=2)
            outputs = _save(fig, out / f"rdf_{run.name}")
            plt.close(fig)
            manifest.append({"figure": f"rdf_{run.name}", "inputs": [str(rdf_path)], "outputs": outputs})

        clusters_path = run / "clusters_by_frame.csv"
        if clusters_path.exists():
            rows = _read_rows(clusters_path)
            t = np.asarray([float(row["timestep"]) * cfg["md"]["timestep_fs"] / 1000 for row in rows])
            largest = np.asarray([float(row["largest_cluster"]) for row in rows])
            fraction = np.asarray([float(row["fraction_in_clusters_ge_5"]) for row in rows])
            fig, left = plt.subplots(figsize=(3.35, 2.6))
            right = left.twinx()
            left.plot(t, largest, color="#6A3D9A", lw=1.2)
            right.plot(t, fraction, color="#FF7F00", lw=1.2)
            left.set(xlabel="Time (ps)", ylabel="Largest cluster (atoms)")
            right.set_ylabel(r"Solute fraction in clusters $\geq 5$")
            outputs = _save(fig, out / f"clusters_{run.name}")
            plt.close(fig)
            manifest.append({"figure": f"clusters_{run.name}", "inputs": [str(clusters_path)], "outputs": outputs})

        sro_path = run / "sro.csv"
        if sro_path.exists():
            rows = _read_rows(sro_path)
            elements = cfg["elements"]
            matrix = np.full((len(elements), len(elements)), np.nan)
            for row in rows:
                if row["center"] in elements and row["neighbor"] in elements:
                    matrix[elements.index(row["center"]), elements.index(row["neighbor"])] = float(row["alpha"])
            fig, ax = plt.subplots(figsize=(3.0, 2.6))
            image = ax.imshow(matrix, cmap="coolwarm", vmin=-1, vmax=1)
            ax.set_xticks(range(len(elements)), elements)
            ax.set_yticks(range(len(elements)), elements)
            ax.set(xlabel="Neighbor species", ylabel="Center species")
            fig.colorbar(image, ax=ax, label=r"Warren–Cowley $\alpha$")
            outputs = _save(fig, out / f"sro_{run.name}")
            plt.close(fig)
            manifest.append({"figure": f"sro_{run.name}", "inputs": [str(sro_path)], "outputs": outputs})

    if all_diffusion:
        grouped = defaultdict(list)
        for row in all_diffusion:
            required = ["alloy", "vacancy", "temperature_k", "element", "D_m2_per_s"]
            if all(key in row and row[key] != "" for key in required) and float(row["D_m2_per_s"]) > 0:
                grouped[(row["alloy"], row["vacancy"], row["element"])].append(
                    (float(row["temperature_k"]), float(row["D_m2_per_s"]))
                )
        if grouped:
            fig, ax = plt.subplots(figsize=(3.35, 2.8))
            fit_rows = []
            for (alloy, vacancy, element), points in sorted(grouped.items()):
                by_temperature = defaultdict(list)
                for temperature, value in points:
                    by_temperature[temperature].append(value)
                temperatures = np.asarray(sorted(by_temperature))
                values = np.asarray([np.mean(by_temperature[t]) for t in temperatures])
                ax.plot(1000 / temperatures, np.log(values), marker="o", ms=3, lw=1,
                        label=f"{alloy}/{vacancy}/{element}", color=COLORS.get(element))
                if len(temperatures) >= 2:
                    x = 1000 / temperatures
                    y = np.log(values)
                    slope, intercept = np.polyfit(x, y, 1)
                    predicted = slope * x + intercept
                    ss_res = float(np.sum((y - predicted) ** 2))
                    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
                    fit_rows.append({"alloy": alloy, "vacancy": vacancy, "element": element,
                                     "n_temperatures": len(temperatures),
                                     "activation_energy_ev": -slope * 1000 * 8.617333262e-5,
                                     "prefactor_m2_per_s": float(np.exp(intercept)),
                                     "r_squared": 1 - ss_res / ss_tot if ss_tot > 0 else np.nan})
            ax.set(xlabel=r"$1000/T$ ($\mathrm{K^{-1}}$)", ylabel=r"$\ln D$ ($D$ in $\mathrm{m^2\,s^{-1}}$)")
            ax.legend(fontsize=5, ncol=2)
            outputs = _save(fig, out / "arrhenius_diffusion")
            plt.close(fig)
            manifest.append({"figure": "arrhenius_diffusion",
                             "inputs": sorted({row["_source"] for row in all_diffusion}), "outputs": outputs})
            if fit_rows:
                fit_path = out / "arrhenius_fits.csv"
                with fit_path.open("w", newline="", encoding="utf-8") as handle:
                    writer = csv.DictWriter(handle, fieldnames=list(fit_rows[0]))
                    writer.writeheader()
                    writer.writerows(fit_rows)

    # NEB is project-level and can be plotted even without MD analyses.
    neb_path = Path(cfg["_workdir"]) / "04_neb" / "neb_paths.csv"
    if neb_path.exists():
        rows = _read_rows(neb_path)
        grouped = defaultdict(list)
        for row in rows:
            grouped[row["element"]].append((float(row["reaction_coordinate"]), float(row["relative_energy_ev"])))
        fig, ax = plt.subplots(figsize=(3.35, 2.6))
        for element, points in grouped.items():
            values = np.asarray(points)
            ax.plot(values[:, 0], values[:, 1], marker="o", ms=3, label=element,
                    color=COLORS.get(element))
        ax.set(xlabel="Normalized reaction coordinate", ylabel="Relative energy (eV)")
        ax.legend()
        outputs = _save(fig, out / "neb_paths")
        plt.close(fig)
        manifest.append({"figure": "neb_paths", "inputs": [str(neb_path)], "outputs": outputs})

    manifest_path = out / "figure_manifest.json"
    dump_json({"config": cfg["_config_path"], "figures": manifest}, manifest_path)
    return manifest_path
