#!/usr/bin/env bash
set -euo pipefail
# MACE always uses the project interpreter, independent of default python3.
PROJECT=${PROJECT:-/home/zhaojia/AlZnMgCuV1}
cd "$PROJECT"
PKG="$PROJECT/cu_story_supplement_v2"
MACE_PY=${MACE_PY:-$PROJECT/.venv-mace-cpu/bin/python3}
DFT_PY=${DFT_PY:-/usr/bin/python3.8}
stage=${1:?Usage: bash cu_story_supplement_v2/run.sh STAGE [options]}
shift
export OMP_NUM_THREADS=${STORY_THREADS:-8}
export MKL_NUM_THREADS=$OMP_NUM_THREADS
export OPENBLAS_NUM_THREADS=1
export STORY_INTEL_LIBRARY_PATH=${LD_LIBRARY_PATH:-}
case "$stage" in
  enumerate|screen|cell4)
    exec env -u LD_LIBRARY_PATH -u LD_PRELOAD -u PYTHONPATH "$MACE_PY" -u "$PKG/pipeline.py" "$stage" --threads "$OMP_NUM_THREADS" "$@"
    ;;
  dft-high|dft-check|mechanism|audit)
    # Preserve Intel runtime paths for VASP; story.py removes LibTorch paths.
    exec env -u LD_PRELOAD -u PYTHONPATH "$DFT_PY" -u "$PKG/pipeline.py" "$stage" "$@"
    ;;
  evaluate)
    exec env -u LD_LIBRARY_PATH -u LD_PRELOAD -u PYTHONPATH "$MACE_PY" -u "$PKG/evaluate.py" --threads "$OMP_NUM_THREADS" "$@"
    ;;
  analyze)
    exec env -u LD_PRELOAD -u PYTHONPATH "$DFT_PY" -u "$PKG/story.py" analyze "$@"
    ;;
  compare)
    exec "$DFT_PY" -u "$PKG/compare.py" "$@"
    ;;
  test)
    exec env -u LD_PRELOAD -u PYTHONPATH "$DFT_PY" "$PKG/test_story.py"
    ;;
  *) echo "Unknown stage: $stage" >&2; exit 2 ;;
esac
