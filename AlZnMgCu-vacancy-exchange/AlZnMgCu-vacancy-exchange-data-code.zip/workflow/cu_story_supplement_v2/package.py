"""Build reproducible source-only zip; exclude caches and generated calculation outputs."""
import hashlib
import json
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts
             and p.suffix in ('.py','.sh','.md'))
out=root.parent/'cu_story_supplement_v2.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    hashes={}
    for p in files:
        data=p.read_bytes().replace(b'\r\n',b'\n')
        name=str(p.relative_to(root.parent)).replace('\\','/')
        z.writestr(name,data)
        hashes[name]=hashlib.sha256(data).hexdigest()
    z.writestr(root.name+'/SHA256.json',json.dumps(hashes,indent=2))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert all(not name.endswith('.pyc') for name in z.namelist())
    assert all(b'\r\n' not in z.read(name) for name in z.namelist() if name.endswith('.sh'))
print(out)
print('Files:',len(files),'Bytes:',out.stat().st_size)
