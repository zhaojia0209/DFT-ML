"""Collect explicit supplementary runs; no mixing of raw energies between compositions."""
import argparse
import json
from pathlib import Path
from story import table, atomic_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--roots', type=Path, nargs='+', required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.output.exists():p.error('Output exists')
    allrows=[];contrasts=[];missing=[]
    for root in a.roots:
        if not root.is_dir() or not list(root.glob('*/summary.json')):
            raise ValueError('Missing results group: '+str(root))
        by={}
        for file in sorted(root.glob('*/summary.json')):
            s=json.loads(file.read_text())
            if s.get('status')!='converged':
                missing.append(str(file));continue
            settings=json.loads((file.parent/'settings.json').read_text())
            row={'run_group':root.name,'task':s['task'],'kind':s['kind'],
                 'forward_barrier_ev':s['forward_barrier_ev'],'reverse_barrier_ev':s['reverse_barrier_ev'],
                 'delta_energy_ev':s['final_energy_ev']-s['initial_energy_ev'],
                 'ci_fmax_ev_A':s['ci_fmax_ev_A'],'freeze_cu':s.get('freeze_cu',False),
                 'n_atoms':s.get('n_atoms',''),'settings_file':str(file.parent/'settings.json')}
            allrows.append(row);by[s['task']]=(row,settings)
        for e in ('Mg','Zn'):
            for c in ('common_neighbor','near_solute'):
                if e+'_'+c not in by or e+'_far_cu' not in by:continue
                r,rs=by[e+'_'+c];f,fs=by[e+'_far_cu']
                keys=('backend','model_hash','cfg','freeze_cu','method')
                if any(rs[k]!=fs[k] for k in keys):raise ValueError('Incompatible contrast settings')
                contrasts.append({'run_group':root.name,'element':e,'environment':c,
                    'reference':'far_cu','forward_contrast_ev':r['forward_barrier_ev']-f['forward_barrier_ev'],
                    'reverse_contrast_ev':r['reverse_barrier_ev']-f['reverse_barrier_ev']})
    table(a.output/'all_runs.csv',allrows)
    if contrasts:table(a.output/'contrasts.csv',contrasts)
    atomic_json(a.output/'notes.json',{'unconverged':missing,
        'interpretation':'Compare contrasts between settings; no automatic numerical-convergence verdict.',
        'cell4':'far Cu is the farthest selected periodic site, not infinite separation.',
        'freeze_cu':'Constraint-specific comparison, not unique chemical/elastic decomposition.'})


if __name__=='__main__':main()
