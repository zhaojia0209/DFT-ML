"""Offline tests; no VASP/MACE launch. ASE-specific tests skip only if ASE is absent."""
import ast
import importlib.util
import json
from pathlib import Path
import tempfile
import uuid
from contextlib import contextmanager
import unittest
import sys
import numpy as np
from story import atomic_json, parser, resample, validate_band, checkpoint
from lib.enumerate_cu_sites import enumerate_sites


@contextmanager
def scratch():
    # Keep test writes inside the selected workspace, not a restricted system TEMP.
    p=Path.cwd()/'work/story_offline_tests'/uuid.uuid4().hex
    p.mkdir(parents=True)
    yield str(p)


class Tests(unittest.TestCase):
    def test_python38_syntax(self):
        for p in Path(__file__).parent.rglob('*.py'):
            ast.parse(p.read_text(encoding='utf8'),feature_version=8)

    def test_symmetry(self):
        for n in (3,4):
            sites,r,ops,shells=enumerate_sites(n,2)
            self.assertEqual(len(sites),4*n**3)
            self.assertEqual(len(r),11)
            self.assertEqual(sum(x['degeneracy'] for x in r),26)
            by={x['class_id']:x for x in r}
            for x in r:
                self.assertEqual(by[x['reverse_class']]['reverse_class'],x['class_id'])

    def test_atomic_record(self):
        with scratch() as d:
            p=Path(d)/'record.json'
            atomic_json(p,{'phase':'ci'})
            self.assertEqual(json.loads(p.read_text()),{'phase':'ci'})
            self.assertFalse(p.with_name('record.json.tmp').exists())

    def test_cli(self):
        a=parser().parse_args(['band','--source','s','--output','o','--task','Mg_test','--backend','dft'])
        self.assertEqual(a.ranks,18)
        self.assertEqual(a.images,5)

    @unittest.skipUnless(importlib.util.find_spec('ase'),'ASE not installed on test host')
    def test_geometry_checkpoint(self):
        from ase import Atoms
        from ase.io import read
        x=Atoms('Al2',positions=[[0,0,0],[3,0,0]],cell=[10,10,10],pbc=True)
        y=x.copy();y.positions[0,1]=.1
        z=x.copy();z.positions[0,1]=.2
        band=resample([x,y,z],7)
        self.assertEqual(len(band),9)
        validate_band(band)
        np.testing.assert_allclose(band[-1].positions,z.positions)
        with scratch() as d:
            p=Path(d)/'checkpoint.extxyz'
            checkpoint(p,band,'ci')
            saved=read(str(p),index=':')
            self.assertEqual(saved[0].info['story_phase'],'ci')
            self.assertEqual(len(saved),9)


if __name__=='__main__':unittest.main(verbosity=2)
