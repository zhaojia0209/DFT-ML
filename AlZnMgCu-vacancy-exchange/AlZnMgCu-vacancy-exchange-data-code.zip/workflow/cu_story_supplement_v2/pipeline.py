"""Stage dispatcher. Existing six-path production tasks remain read-only."""
import argparse
import csv
import json
from pathlib import Path
import subprocess
import sys
import os
from story import HERE, atomic_json, digest, table


def call(args):
    print('[command]', ' '.join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), check=True)


def rows(p):
    with Path(p).open(newline='', encoding='utf8') as f:
        return list(csv.DictReader(f))


def model(project, seed):
    if seed == 11:
        p = project/'work/final_models/alzmcv_v6_seed11_final.model'
    else:
        p = project/('work/vacancy_reweight_v6/02_mace/seed%d/checkpoints/alzmcv_vacweight_v6_seed%d_run-%d_stagetwo.model' % (seed, seed, seed))
    if not p.is_file():
        raise FileNotFoundError(p)
    return p


def reused(a, source, dest, name):
    """Copy independently converged MACE outputs after model/endpoint provenance checks."""
    from ase.io import read
    from story import band_files, validate_band, write_band
    oldroot = a.project/'work/cu_environment_v1/03_neb_seed11'
    settings = json.loads((oldroot/'settings.json').read_text())
    if settings['model_sha256'] != digest(model(a.project, 11)):
        raise ValueError('Old MACE model differs; cannot reuse')
    old = next(r for r in rows(oldroot/'neb_summary.csv') if r['task'] == source)
    if old['status'] != 'converged_screen' or float(old['ci_neb_fmax_ev_A']) > .02:
        raise ValueError('Old path not converged: '+source)
    endpointroot = a.project/'work/cu_environment_v1/02_endpoints_seed11'
    if json.loads((endpointroot/'settings.json').read_text())['model_sha256'] != settings['model_sha256']:
        raise ValueError('Old endpoint model mismatch')
    endpoints = [r for r in rows(endpointroot/'endpoint_summary.csv') if r['task'] == source]
    if len(endpoints) != 2 or any(r['status'] != 'pass' for r in endpoints):
        raise ValueError('Old endpoints not passed')
    if dest.exists():
        s = json.loads((dest/'summary.json').read_text())
        p = json.loads((dest/'settings.json').read_text())
        if s['status'] != 'converged' or p['model_hash'] != settings['model_sha256']:
            raise ValueError('Invalid cached reuse')
        return
    images = [read(str(f)) for f in band_files(oldroot/'tasks'/source)]
    validate_band(images)
    write_band(dest/'band', images)
    atomic_json(dest/'settings.json', {'backend': 'mace', 'model_hash': settings['model_sha256'],
        'cfg': None, 'freeze_cu': False, 'method': 'improvedtangent_CI',
        'reuse_source': str((oldroot/'tasks'/source).resolve()),
        'source_hashes': [digest(f) for f in band_files(oldroot/'tasks'/source)]})
    profile = rows(oldroot/'tasks'/source/'profile.csv')
    e = [float(r['energy_ev']) for r in profile]
    table(dest/'profile.csv', [dict(task=name, image=i, energy_ev=v,
        free_energy_ev=v, relative_energy_ev=v-e[0]) for i, v in enumerate(e)])
    atomic_json(dest/'summary.json', {'task': name, 'status': 'converged', 'kind': 'mace_CI_NEB_reused',
        'composition': images[0].get_chemical_formula(), 'cell': images[0].cell.array.tolist(),
        'initial_energy_ev': e[0], 'final_energy_ev': e[-1], 'peak_energy_ev': max(e),
        'forward_barrier_ev': max(e)-e[0], 'reverse_barrier_ev': max(e)-e[-1],
        'max_image': e.index(max(e)), 'ci_fmax_ev_A': float(old['ci_neb_fmax_ev_A']),
        'symmetry_equivalent_to': source, 'freeze_cu': False})


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage', choices=['enumerate', 'screen', 'dft-high', 'dft-check', 'mechanism', 'cell4', 'audit'])
    p.add_argument('--project', type=Path, default=Path.cwd())
    p.add_argument('--root', type=Path, default=Path('work/cu_story_supplement_v2'))
    p.add_argument('--seed', type=int, choices=[11,29,47], default=11)
    p.add_argument('--threads', type=int, default=8)
    p.add_argument('--ranks', type=int, default=18, help='MPI ranks for ONE serial VASP image, not total NEB ranks')
    p.add_argument('--tasks', nargs='+')
    p.add_argument('--variant', choices=['base','k4','encut600','sigma010','tight','images7','perturb'], default='base')
    a = p.parse_args()
    a.project = a.project.resolve()
    os.chdir(str(a.project))
    a.root = a.root.resolve()
    old = a.project/'work/cu_environment_v1'
    geometry = a.root/'geometries'
    band = [sys.executable, HERE/'story.py', 'band']
    if a.stage == 'enumerate':
        if geometry.exists():
            proof = json.loads((geometry/'symmetry.json').read_text())
            if proof['cells'] != 3 or proof['shells'] != 2 or proof['a0'] != 4.05:
                raise ValueError('Existing enumeration settings differ')
            print('[skip enumeration]', geometry)
            return
        call([sys.executable, HERE/'lib/enumerate_cu_sites.py', '--output', geometry,
              '--cells', 3, '--a0', 4.05, '--shells', 2, '--existing', old/'01_geometries'])
    elif a.stage == 'screen':
        matches = {r['task']:r['existing_task'] for r in rows(geometry/'reuse_matches.csv')}
        allnames = [r['task'] for r in rows(geometry/'enumeration.csv')]
        allnames += [e+'_'+c for e in ('Mg','Zn') for c in ('no_cu','far_cu','near_solute','near_vacancy','common_neighbor')]
        names = a.tasks or allnames
        if any(t not in allnames for t in names):
            raise ValueError('Unknown task')
        root = a.root/('mace_seed%d' % a.seed)
        for name in names:
            dest = root/name
            legacy = matches.get(name, name if (old/'01_geometries/tasks'/name).is_dir() else None)
            if a.seed == 11 and legacy:
                reused(a, legacy, dest, name)
                continue
            src = old/'01_geometries/tasks'/name if (old/'01_geometries/tasks'/name).is_dir() else geometry/'tasks'/name
            call(band+['--source', src, '--output', dest, '--task', name, '--backend', 'mace',
                       '--model', model(a.project, a.seed), '--threads', a.threads])
        summaries = [json.loads((root/t/'summary.json').read_text()) for t in names]
        table(root/('landscape_'+('all' if not a.tasks else 'subset')+'.csv'), [
            {k:s[k] for k in ('task','status','initial_energy_ev','final_energy_ev','forward_barrier_ev','reverse_barrier_ev','ci_fmax_ev_A')} for s in summaries])
    elif a.stage in ('dft-high', 'dft-check', 'mechanism'):
        names = a.tasks or (['Mg_near_solute','Zn_near_solute'] if a.stage == 'dft-high' else
            [e+'_'+c for e in ('Mg','Zn') for c in ('far_cu','common_neighbor')])
        for name in names:
            if Path(name).name != name or name in ('.','..'):
                raise ValueError('Invalid task name')
            extra = []
            if a.stage == 'dft-high':
                src = old/'03_neb_seed11/tasks'/name
                if not src.is_dir():
                    src = a.root/'mace_seed11'/name/'band'
                dest = a.root/'dft_high'/name
            elif a.stage == 'mechanism':
                # Matched unconstrained/constraint runs use the SAME MACE starting band and electronic settings.
                src = old/'03_neb_seed11/tasks'/name
                dest = a.root/'freeze_cu'/name
                extra = ['--freeze-cu']
            else:
                src = a.root/'native_exports'/name
                if not src.exists():
                    call([sys.executable, HERE/'story.py', 'export-native', '--source',
                        a.project/'work/cu_environment_dft_v1/neb/tasks'/name, '--output', src])
                dest = a.root/('dft_check_'+a.variant)/name
                extra = {'base':[], 'k4':['--kmesh',4,4,4], 'encut600':['--encut',600],
                         'sigma010':['--sigma',.10], 'tight':['--fmax',.01,'--endpoint-fmax',.005],
                         'images7':['--images',7], 'perturb':['--perturb',.02]}[a.variant]
            call(band+['--source',src,'--output',dest,'--task',name,'--backend','dft',
                       '--ranks',a.ranks,'--project',a.project]+extra)
    elif a.stage == 'cell4':
        geom = a.root/'cell4_geometries'
        if not geom.exists():
            call([sys.executable,HERE/'lib/build_cu_environment_paths.py','--output',geom,'--cells',4,'--a0',4.05,'--images',5])
        names = a.tasks or [e+'_'+c for e in ('Mg','Zn') for c in ('far_cu','common_neighbor')]
        for name in names:
            # Keep original geometries explicit; 255 atoms, one vacancy. Do NOT replicate a vacancy cell.
            call(band+['--source',geom/'tasks'/name,'--output',a.root/'cell4_mace'/name,
                '--task',name,'--backend','mace','--model',model(a.project,11),'--threads',a.threads])
            call(band+['--source',a.root/'cell4_mace'/name/'band','--output',a.root/'cell4_dft_k3'/name,
                '--task',name,'--backend','dft','--kmesh',3,3,3,'--ranks',a.ranks])
    elif a.stage == 'audit':
        output = a.root/'audit/splits.json'
        call([sys.executable,HERE/'lib/audit_splits.py','--train',a.project/'work/vacancy_reweight_v6/02_mace/train.extxyz',
            '--valid',a.project/'work/vacancy_reweight_v6/02_mace/valid.extxyz',
            '--test',a.project/'work/vacancy_reweight_v6/02_mace/test.extxyz','--output',output])


if __name__ == '__main__':
    main()
