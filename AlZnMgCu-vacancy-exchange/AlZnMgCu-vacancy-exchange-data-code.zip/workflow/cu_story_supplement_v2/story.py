"""Read-only sources; independent, resumable supplementary Cu calculations (Python >=3.8)."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from contextlib import contextmanager

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'lib'))


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def atomic_json(p, obj):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    temp = p.with_name(p.name + '.tmp')
    with temp.open('w', encoding='utf8') as f:
        json.dump(obj, f, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(str(temp), str(p))


def table(p, rows):
    if not rows:
        raise ValueError('No rows: ' + str(p))
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('w', newline='', encoding='utf8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


@contextmanager
def lock(directory):
    """flock releases automatically after exit; no stale-lock deletion is needed."""
    import fcntl
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / '.story.lock').open('a+') as f:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def idle():
    """Guard against already running legacy VASP jobs; does not terminate anything."""
    for name in ('vasp_std', 'vasp_gam', 'vasp_ncl'):
        r = subprocess.run(['pgrep', '-x', name], stdout=subprocess.PIPE, text=True)
        if r.returncode == 0:
            raise RuntimeError('VASP is already running. Wait for it to finish: ' + name)
        if r.returncode != 1:
            raise RuntimeError('Could not check existing VASP processes')


def model_calc(path, threads):
    import torch
    from mace.calculators import MACECalculator
    torch.set_num_threads(threads)
    return MACECalculator(model_paths=str(Path(path).resolve()), device='cpu',
                          default_dtype='float64')


def band_files(source):
    return sorted(Path(source).glob('[0-9][0-9]/POSCAR'))


def validate_band(images):
    import numpy as np
    if len(images) < 3:
        raise ValueError('At least three images required')
    for x in images:
        if not np.array_equal(x.numbers, images[0].numbers) or not np.allclose(x.cell, images[0].cell):
            raise ValueError('Species ordering/cell mismatch')
        if not np.isfinite(x.positions).all():
            raise ValueError('Nonfinite geometry')
        d = x.get_all_distances(mic=True)
        np.fill_diagonal(d, np.inf)
        if d.min() < 1.5:
            raise ValueError('Atom overlap (<1.5 A)')


def resample(images, n):
    """Piecewise Cartesian interpolation after sequential MIC unwrapping."""
    import numpy as np
    from ase.geometry import find_mic
    positions = [images[0].positions.copy()]
    for x, y in zip(images, images[1:]):
        delta, _ = find_mic(y.positions - x.positions, x.cell, x.pbc)
        positions.append(positions[-1] + delta)
    result = []
    for t in np.linspace(0, len(images) - 1, n + 2):
        j = min(int(t), len(images) - 2)
        im = images[0].copy()
        im.positions = (1 - (t - j)) * positions[j] + (t - j) * positions[j + 1]
        result.append(im)
    return result


def write_band(path, images):
    from ase.io import write
    path.mkdir(parents=True, exist_ok=True)
    for i, x in enumerate(images):
        dest = path / ('%02d' % i)
        dest.mkdir(exist_ok=True)
        write(str(dest / 'POSCAR'), x, format='vasp', sort=False, direct=True)


def checkpoint(path, images, phase=None):
    from ase.io import write
    temp = path.with_name(path.name + '.tmp')
    copies = [x.copy() for x in images]
    if phase is not None:
        copies[0].info['story_phase'] = phase
    write(str(temp), copies, format='extxyz', write_results=False)
    with temp.open('rb') as f:
        os.fsync(f.fileno())
    os.replace(str(temp), str(path))


def make_vasp(a, cfg, directory):
    """Every SCF has an immutable geometry-keyed directory; completed SCFs are cached."""
    import numpy as np
    from ase.calculators.calculator import Calculator, all_changes
    from cu_dft_workflow import write_inputs, load_result

    class Singlepoint(Calculator):
        implemented_properties = ['energy', 'free_energy', 'forces', 'stress']

        def calculate(self, atoms=None, properties=None, system_changes=all_changes):
            Calculator.calculate(self, atoms, properties, system_changes)
            keydata = {'numbers': self.atoms.numbers.tolist(),
                       'positions': self.atoms.positions.tolist(),
                       'cell': self.atoms.cell.array.tolist(), 'cfg': cfg}
            key = hashlib.sha256(json.dumps(keydata, sort_keys=True).encode()).hexdigest()
            cache = directory / key
            marker = cache / 'complete.json'
            if marker.exists():
                record = json.loads(marker.read_text())
            else:
                idle()
                cache.mkdir(parents=True, exist_ok=True)
                attempt = Path(tempfile.mkdtemp(prefix='attempt_', dir=str(cache)))
                plain = self.atoms.copy()
                plain.set_constraint()
                write_inputs(attempt, plain, cfg, 'sp')
                with (attempt / 'vasp.stdout').open('w') as out, (attempt / 'vasp.stderr').open('w') as err:
                    code = subprocess.run([a.mpi, '-np', str(a.ranks), a.vasp],
                                          cwd=str(attempt), stdin=subprocess.DEVNULL,
                                          stdout=out, stderr=err).returncode
                atomic_json(attempt / 'execution.json', {'exit_code': code, 'key': key})
                if code:
                    raise RuntimeError('VASP failed; preserved: ' + str(attempt))
                frame, e0, free, _ = load_result(attempt)
                record = {'energy': free, 'free_energy': free, 'sigma0_energy': e0,
                          'forces': frame.get_forces().tolist(), 'stress': frame.get_stress().tolist(),
                          'source': str(attempt.resolve())}
                atomic_json(marker, record)
            self.results = {k: np.array(v) if k in ('forces', 'stress') else v
                            for k, v in record.items() if k != 'source'}

    return Singlepoint()


def prepare_cfg(a):
    from cu_dft_workflow import POTS
    cfg = json.loads(a.campaign.read_text())
    # Do not carry ionic/NEB tags into ASE-driven singlepoints.
    for k in ('IBRION', 'NSW', 'EDIFFG', 'POTIM', 'SMASS', 'IMAGES', 'SPRING',
              'LCLIMB', 'IOPT', 'ICHAIN', 'NPAR', 'NCORE', 'KPAR'):
        cfg['electronic_incar'].pop(k, None)
    for k, v in [('ENCUT', a.encut), ('SIGMA', a.sigma), ('EDIFF', a.ediff)]:
        if v is not None:
            cfg['electronic_incar'][k] = str(v)
    if a.kmesh:
        cfg['kpoints'] = 'Automatic Gamma mesh\n0\nGamma\n%s\n0 0 0\n' % ' '.join(map(str, a.kmesh))
    if a.potcar_root:
        cfg['potcar_root'] = str(a.potcar_root.resolve())
    for e, pot in POTS.items():
        if digest(Path(cfg['potcar_root']) / pot / 'POTCAR') != cfg['potcar_hashes'][e]:
            raise ValueError('POTCAR mismatch: ' + e)
    return cfg


def run_band(a):
    import numpy as np
    from ase.io import read
    from ase.optimize import FIRE
    from ase.mep import NEB
    from ase.constraints import FixAtoms
    from ase.geometry import find_mic
    from cu_dft_workflow import verify_basin
    import ase
    files = band_files(a.source)
    if len(files) < 3:
        raise ValueError('Source requires numbered POSCAR images')
    originals = [read(str(f), format='vasp') for f in files]
    validate_band(originals)
    cfg = prepare_cfg(a) if a.backend == 'dft' else None
    if a.backend == 'mace' and not a.model:
        raise ValueError('--model required')
    provenance = {'task': a.task, 'ase_version': ase.__version__,
                  'vasp_sha256': digest(a.vasp) if cfg else None,
                  'source': str(a.source.resolve()), 'source_hashes': [digest(f) for f in files],
                  'backend': a.backend, 'model_hash': digest(a.model) if a.model else None,
                  'cfg': cfg, 'images': a.images, 'fmax': a.fmax, 'endpoint_fmax': a.endpoint_fmax,
                  'freeze_cu': a.freeze_cu, 'spring': a.spring, 'perturb': a.perturb,
                  'method': 'improvedtangent_CI', 'energy_for_optimization': 'free_energy' if cfg else 'model_energy'}
    out = a.output.resolve()
    if a.source.resolve() == out or a.source.resolve() in out.parents:
        raise ValueError('Output must be separate from source')
    if out.exists() and not (out / 'settings.json').exists():
        raise ValueError('Output exists without provenance')
    out.mkdir(parents=True, exist_ok=True)
    with lock(out):
        settings = out / 'settings.json'
        if settings.exists() and json.loads(settings.read_text()) != provenance:
            raise ValueError('Settings changed; choose another output directory')
        atomic_json(settings, provenance)
        if (out / 'summary.json').exists():
            if json.loads((out / 'summary.json').read_text()).get('status') == 'converged':
                print('[skip]', out, flush=True)
                return
        images = resample(originals, a.images)
        if a.perturb:
            rng = np.random.default_rng(20260911)
            for i, x in enumerate(images[1:-1], 1):
                x.positions += rng.normal(0, a.perturb, x.positions.shape) * np.sin(np.pi*i/(len(images)-1))
        cu = np.where(images[0].numbers == 29)[0]
        if a.freeze_cu:
            if len(cu) != 1:
                raise ValueError('freeze-cu requires one Cu')
            for x in images:
                x.positions[cu] = images[0].positions[cu]
                x.set_constraint(FixAtoms(indices=cu))
        endpoint_anchors = [x.positions.copy() for x in images]
        cp = out / 'checkpoint.extxyz'
        statefile = out / 'state.json'
        phase = json.loads(statefile.read_text()).get('phase', 'endpoints') if statefile.exists() else 'endpoints'
        if cp.exists():
            saved = read(str(cp), index=':')
            phase = saved[0].info.get('story_phase', phase)
            if len(saved) != len(images):
                raise ValueError('Checkpoint image count mismatch')
            validate_band(saved)
            for x, s in zip(images, saved):
                if not np.array_equal(x.numbers, s.numbers) or not np.allclose(x.cell, s.cell):
                    raise ValueError('Checkpoint species/cell mismatch')
                x.positions = s.positions
            print('[resume coordinates]', phase, flush=True)
        shared = model_calc(a.model, a.threads) if a.backend == 'mace' else None
        for i, x in enumerate(images):
            x.calc = shared or make_vasp(a, cfg, out / 'scf' / ('%02d' % i))
        def save():
            validate_band(images)
            checkpoint(cp, images, phase)
        try:
            if phase == 'endpoints':
                before = endpoint_anchors
                for i in (0, len(images)-1):
                    opt = FIRE(images[i], logfile=str(out / ('endpoint_%02d.log' % i)), maxstep=.05)
                    opt.attach(save, interval=1)
                    if not opt.run(fmax=a.endpoint_fmax, steps=a.steps):
                        raise RuntimeError('Endpoint not converged; rerun resumes coordinates')
                    # Check site identity, but do not translate a frozen-Cu endpoint.
                    verify_basin(originals[0 if i == 0 else -1], images[i])
                d0, _ = find_mic(images[0].positions-before[0], images[0].cell, True)
                d1, _ = find_mic(images[-1].positions-before[-1], images[0].cell, True)
                for i, x in enumerate(images[1:-1], 1):
                    correction = (1-i/(len(images)-1))*d0 + i/(len(images)-1)*d1
                    if a.freeze_cu:
                        correction[cu] = 0
                    x.positions += correction
                phase = 'pre'
                save()
                atomic_json(statefile, {'phase': phase})
            neb = NEB(images, k=a.spring, method='improvedtangent', climb=False,
                      parallel=False, allow_shared_calculator=(shared is not None))
            if phase == 'pre':
                opt = FIRE(neb, logfile=str(out/'pre.log'), maxstep=.05)
                opt.attach(save, interval=1)
                if not opt.run(fmax=max(.05, a.fmax), steps=a.steps):
                    raise RuntimeError('Pre-NEB not converged; rerun resumes')
                phase = 'ci'
                save()
                atomic_json(statefile, {'phase': phase})
            neb.climb = True
            opt = FIRE(neb, logfile=str(out/'ci.log'), maxstep=.05)
            opt.attach(save, interval=1)
            ok = opt.run(fmax=a.fmax, steps=a.steps)
            fmax = float(np.linalg.norm(neb.get_forces(), axis=1).max())
            free = [float(x.get_potential_energy()) for x in images]
            e0 = [float(x.calc.results['sigma0_energy']) if cfg else e for x, e in zip(images, free)]
            peak = int(np.argmax(free))
            if not ok or fmax > a.fmax or peak in (0, len(images)-1):
                raise RuntimeError('CI force/peak gate failed; last coordinates preserved')
            write_band(out/'band', images)
            profile = [{'task': a.task, 'image': i, 'energy_ev': e0[i], 'free_energy_ev': free[i],
                        'relative_energy_ev': e0[i]-e0[0]} for i in range(len(images))]
            table(out/'profile.csv', profile)
            atomic_json(out/'summary.json', {'task': a.task, 'status': 'converged',
                'kind': a.backend+'_CI_NEB', 'freeze_cu': a.freeze_cu,
                'n_atoms': len(images[0]), 'composition': images[0].get_chemical_formula(),
                'cell': images[0].cell.array.tolist(), 'initial_energy_ev': e0[0],
                'final_energy_ev': e0[-1], 'peak_energy_ev': max(e0),
                'forward_barrier_ev': max(e0)-e0[0], 'reverse_barrier_ev': max(e0)-e0[-1],
                'ci_fmax_ev_A': fmax, 'max_image': int(np.argmax(e0)),
                'free_energy_max_image': peak, 'sigma0_peak_differs_from_free_peak': int(np.argmax(e0)) != peak,
                'forward_free_barrier_ev': max(free)-free[0],
                'note': 'CI force convergence is not a Hessian saddle-order verification.'})
            print('[converged]', a.task, max(e0)-e0[0], flush=True)
        except BaseException as exc:
            atomic_json(out/'last_error.json', {'error': repr(exc), 'phase': phase})
            raise


def runtime(a):
    if a.backend != 'dft':
        run_band(a)
        return
    import resource
    if a.ranks < 2 or a.ranks % 2:
        raise ValueError('NCORE=2 requires a positive even MPI count')
    for p in (a.mpi, a.vasp):
        if not Path(p).is_file():
            raise FileNotFoundError(p)
    resource.setrlimit(resource.RLIMIT_STACK, (resource.RLIM_INFINITY, resource.RLIM_INFINITY))
    os.environ.pop('LD_PRELOAD', None)
    os.environ.update(OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    libs = [x for x in os.environ.get('STORY_INTEL_LIBRARY_PATH', os.environ.get('LD_LIBRARY_PATH', '')).split(':') if x and 'libtorch' not in x.lower()]
    os.environ['LD_LIBRARY_PATH'] = '/opt/intel/oneapi/mpi/2021.12/lib:' + ':'.join(libs)
    with lock(a.project.resolve() / 'work/cu_story_supplement_v2_runtime'):
        idle()
        run_band(a)


def export_native(a):
    """Export only completed source NEB; source task is never modified."""
    from ase.io import read
    files = band_files(a.source)
    if len(files) != 7:
        raise ValueError('Expected 00..06 POSCAR')
    if a.output.exists():
        raise ValueError('Export output exists')
    images = []
    for i, p in enumerate(files):
        if i in (0, 6):
            images.append(read(str(p)))
        else:
            out = (p.parent/'OUTCAR').read_text(errors='replace')
            if '\x00' in out or any(s not in out for s in ('reached required accuracy', 'General timing and accounting')):
                raise ValueError('Unconverged/corrupt image: ' + str(p.parent))
            x = read(str(p.parent/'CONTCAR'))
            ref = read(str(p))
            import numpy as np
            if not np.array_equal(x.numbers, ref.numbers) or not np.allclose(x.cell, ref.cell):
                raise ValueError('CONTCAR species/cell mismatch')
            images.append(x)
    validate_band(images)
    write_band(a.output, images)
    atomic_json(a.output/'export.json', {'source': str(a.source.resolve()), 'kind': 'ordinary_DFT_NEB_geometries'})


def analyze(a):
    import numpy as np
    from ase.io import read
    from ase.geometry import find_mic
    if a.output.exists():
        raise ValueError('Analysis output exists')
    runs = []
    for root in a.runs:
        summary = json.loads((root/'summary.json').read_text())
        settings = json.loads((root/'settings.json').read_text())
        if summary['status'] != 'converged':
            raise ValueError('Unconverged run ' + str(root))
        runs.append((root, summary, settings))
    if len({r[1]['task'] for r in runs}) != len(runs):
        raise ValueError('Duplicate task names; analyze different variants separately')
    rows, geom, rates = [], [], []
    kb = 8.617333262145e-5
    for root, s, settings in runs:
        element = s['task'].split('_')[0]
        controls = [x for x in runs if x[1]['task'] == element+'_far_cu']
        if 'Cu' in s['composition']:
            if len(controls) != 1:
                raise ValueError('Exactly one far_cu reference required per solute')
            _, ref, refsettings = controls[0]
            comparable = ('backend', 'model_hash', 'cfg', 'freeze_cu', 'method')
            if any(settings[k] != refsettings[k] for k in comparable) or s['composition'] != ref['composition'] or not np.allclose(s['cell'], ref['cell']):
                raise ValueError('Incompatible same-composition reference')
            di = s['initial_energy_ev']-ref['initial_energy_ev']
            dt = s['peak_energy_ev']-ref['peak_energy_ev']
            df = s['final_energy_ev']-ref['final_energy_ev']
            rows.append({'task': s['task'], 'delta_initial_ev': di, 'delta_peak_ev': dt,
                         'delta_final_ev': df, 'delta_forward_barrier_ev': dt-di,
                         'delta_reverse_barrier_ev': dt-df, 'reference': ref['task']})
            for temperature in a.temperatures:
                for direction in ('forward', 'reverse'):
                    delta = s[direction+'_barrier_ev']-ref[direction+'_barrier_ev']
                    rates.append({'task': s['task'], 'reference': ref['task'], 'temperature_K': temperature,
                        'direction': direction, 'delta_barrier_ev': delta,
                        'log10_relative_rate': -delta/(kb*temperature*np.log(10)),
                        'relative_rate': float(np.exp(-delta/(kb*temperature))),
                        'assumption': 'equal_prefactors_conditional_jump_only_not_diffusivity'})
        images = [read(str(f)) for f in band_files(root/'band')]
        mover = np.where(images[0].numbers == (12 if element == 'Mg' else 30))[0]
        cu = np.where(images[0].numbers == 29)[0]
        if len(mover) != 1:
            raise ValueError('Exactly one migrating solute expected')
        m = int(mover[0]); refpos = images[0].positions
        ids = np.argsort(images[0].get_distances(m, range(len(images[0])), mic=True))[1:13]
        for i, x in enumerate(images):
            disp, _ = find_mic(x.positions-refpos, x.cell, x.pbc)
            host = x.numbers == 13
            disp -= np.median(disp[host], axis=0)
            geom.append({'task': s['task'], 'image': i,
                'mover_Cu_distance_A': float(x.get_distance(m, int(cu[0]), mic=True)) if len(cu) else '',
                'mover_displacement_A': float(np.linalg.norm(disp[m])),
                'Cu_displacement_A': float(np.linalg.norm(disp[cu[0]])) if len(cu) else '',
                'host_displacement_RMS_A': float(np.sqrt(np.mean(np.sum(disp[host]**2, axis=1)))),
                'initial_neighbor_mean_distance_A': float(x.get_distances(m, ids, mic=True).mean())})
    table(a.output/'stabilization.csv', rows)
    table(a.output/'geometry.csv', geom)
    table(a.output/'conditional_rates.csv', rates)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    q = sub.add_parser('band', help='MACE or serial-image ASE/VASP CI-NEB; same command resumes')
    q.add_argument('--source', type=Path, required=True)
    q.add_argument('--output', type=Path, required=True)
    q.add_argument('--task', required=True)
    q.add_argument('--backend', choices=['mace', 'dft'], required=True)
    q.add_argument('--model', type=Path)
    q.add_argument('--threads', type=int, default=8)
    q.add_argument('--images', type=int, default=5)
    q.add_argument('--steps', type=int, default=500)
    q.add_argument('--fmax', type=float, default=.02)
    q.add_argument('--endpoint-fmax', type=float, default=.01)
    q.add_argument('--spring', type=float, default=.1)
    q.add_argument('--perturb', type=float, default=0)
    q.add_argument('--freeze-cu', action='store_true')
    q.add_argument('--project', type=Path, default=Path.cwd())
    q.add_argument('--campaign', type=Path, default=Path('work/cu_environment_dft_v1/campaign.json'))
    q.add_argument('--potcar-root', type=Path)
    q.add_argument('--ranks', type=int, default=18)
    q.add_argument('--mpi', default='/opt/intel/oneapi/mpi/2021.12/bin/mpirun')
    q.add_argument('--vasp', default='/home/zhaojia/vasp.6.4.2/bin/vasp_std')
    q.add_argument('--kmesh', type=int, nargs=3)
    q.add_argument('--encut', type=float)
    q.add_argument('--sigma', type=float)
    q.add_argument('--ediff', type=float)
    q.set_defaults(func=runtime)
    q = sub.add_parser('export-native')
    q.add_argument('--source', type=Path, required=True)
    q.add_argument('--output', type=Path, required=True)
    q.set_defaults(func=export_native)
    q = sub.add_parser('analyze')
    q.add_argument('--runs', type=Path, nargs='+', required=True)
    q.add_argument('--output', type=Path, required=True)
    q.add_argument('--temperatures', type=float, nargs='+', default=[373, 423, 473])
    q.set_defaults(func=analyze)
    return p


if __name__ == '__main__':
    a = parser().parse_args()
    if a.command == 'band':
        if min(a.threads, a.steps, a.images) < 1 or not 0 < a.fmax < 1 or not 0 < a.endpoint_fmax < 1 or a.spring <= 0 or a.perturb < 0:
            raise SystemExit('Invalid numerical settings')
        if a.kmesh and min(a.kmesh) < 1:
            raise SystemExit('Invalid k mesh')
    if a.command == 'analyze' and min(a.temperatures) <= 0:
        raise SystemExit('Temperature must be positive')
    a.func(a)
