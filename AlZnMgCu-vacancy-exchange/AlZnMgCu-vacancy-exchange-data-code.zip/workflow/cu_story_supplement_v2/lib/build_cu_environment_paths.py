"""Stage 1: geometry-only Cu environment controls for Mg/Zn vacancy exchange.

Standard-library only. No DFT/NEB jobs are submitted. Images are unrelaxed guesses.
"""
import argparse
import csv
import itertools
import json
import math
from pathlib import Path


ELEMENTS = ('Al', 'Zn', 'Mg', 'Cu')


def delta(a, b, length):
    return tuple((x-y)-length*round((x-y)/length) for x,y in zip(a,b))


def distance(a, b, length):
    return math.sqrt(sum(x*x for x in delta(a,b,length)))


def poscar(path, symbols, xyz, length, title):
    order = [e for e in ELEMENTS if e in symbols]
    rows = [title, '1.0', f'{length:.14f} 0 0', f'0 {length:.14f} 0',
            f'0 0 {length:.14f}', ' '.join(order),
            ' '.join(str(symbols.count(e)) for e in order), 'Cartesian']
    rows += [' '.join(f'{v:.14f}' for v in r) for r in xyz]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('\n'.join(rows)+'\n', encoding='utf-8')


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=Path('work/cu_environment_v1/01_geometries'))
    p.add_argument('--cells', type=int, default=3)
    p.add_argument('--a0', type=float, default=4.05)
    p.add_argument('--images', type=int, default=5, help='Intermediate images, excluding endpoints')
    a = p.parse_args()
    if a.cells < 3 or not math.isfinite(a.a0) or a.a0 <= 0 or not 1 <= a.images <= 97:
        p.error('Require cells >= 3, a0 > 0 and 1 <= images <= 97')
    if a.output.exists() and any(a.output.iterdir()):
        p.error('Output directory is not empty; choose a new --output to preserve prior work')
    length = a.cells*a.a0
    basis = [(0,0,0),(0,.5,.5),(.5,0,.5),(.5,.5,0)]
    sites = [tuple(a.a0*(v+bv) for v,bv in zip(ijk,b))
             for ijk in itertools.product(range(a.cells),repeat=3) for b in basis]
    vacancy, moving = 0, 3
    v, s = sites[vacancy], sites[moving]
    mid = tuple((x+y)/2 for x,y in zip(v,s))
    nn = a.a0/math.sqrt(2)
    candidates = []
    for idx, r in enumerate(sites):
        if idx in (vacancy,moving):
            continue
        dv, ds, dm = (distance(r,q,length) for q in (v,s,mid))
        candidates.append(dict(site_index=idx, distance_to_initial_vacancy_A=dv,
                               distance_to_initial_solute_A=ds, distance_to_path_midpoint_A=dm))
    close_v = [r for r in candidates if abs(r['distance_to_initial_vacancy_A']-nn)<1e-8
               and r['distance_to_initial_solute_A']>nn+1e-8]
    close_s = [r for r in candidates if abs(r['distance_to_initial_solute_A']-nn)<1e-8
               and r['distance_to_initial_vacancy_A']>nn+1e-8]
    common = [r for r in candidates if abs(r['distance_to_initial_solute_A']-nn)<1e-8
              and abs(r['distance_to_initial_vacancy_A']-nn)<1e-8]
    if not (close_v and close_s and common):
        raise ValueError('Could not find required FCC environment classes')
    # Select representatives reproducibly. Near-S is explicitly the reverse-related
    # partner of near-V under r -> s-r (mod cell); they are not independent mechanisms.
    near_v = min(close_v, key=lambda r:(r['distance_to_initial_solute_A'],r['site_index']))
    mirror = tuple((x-y)%length for x,y in zip(s,sites[near_v['site_index']]))
    near_s = min(close_s,key=lambda r:distance(sites[r['site_index']],mirror,length))
    if distance(sites[near_s['site_index']],mirror,length)>1e-8:
        raise ValueError('Reverse symmetry counterpart not found')
    selections = dict(no_cu=None,
        far_cu=max(candidates,key=lambda r:(min(r['distance_to_initial_vacancy_A'],r['distance_to_initial_solute_A']),-r['site_index'])),
        near_vacancy=near_v, near_solute=near_s,
        common_neighbor=min(common,key=lambda r:(r['distance_to_path_midpoint_A'],r['site_index'])))
    a.output.mkdir(parents=True, exist_ok=True)
    write_csv(a.output/'cu_candidate_distances.csv',candidates)
    manifest = []
    for element in ('Mg','Zn'):
        for environment, chosen in selections.items():
            cu = chosen['site_index'] if chosen else None
            name = f'{element}_{environment}'
            task = a.output/'tasks'/name
            labels = {i:('Cu' if i==cu else element if i==moving else 'Al')
                      for i in range(len(sites)) if i!=vacancy}
            # Identical species grouping AND within-species atom order for every image.
            ordered = sorted(labels,key=lambda i:(ELEMENTS.index(labels[i]),i))
            symbols = [labels[i] for i in ordered]
            start = [sites[i] for i in ordered]
            move_row = ordered.index(moving)
            jump = delta(v,s,length)
            path_min = float('inf')
            trajectory = []
            for image in range(a.images+2):
                fraction = image/(a.images+1)
                xyz = list(start)
                xyz[move_row] = tuple(x+fraction*d for x,d in zip(s,jump))
                minsep = min(distance(x,y,length) for i,x in enumerate(xyz) for y in xyz[i+1:])
                path_min = min(path_min,minsep)
                poscar(task/f'{image:02d}'/'POSCAR',symbols,xyz,length,f'{name} image={image} unrelaxed')
                trajectory += [str(len(xyz)), f'{name} image={image} unrelaxed']
                trajectory += [el+' '+' '.join(f'{q:.12f}' for q in r) for el,r in zip(symbols,xyz)]
            if path_min < 0.6*nn:
                raise ValueError(f'Unphysical overlap in {name}: {path_min}')
            (task/'path.xyz').write_text('\n'.join(trajectory)+'\n',encoding='utf-8')
            write_csv(task/'atom_map.csv',[dict(poscar_row_1based=j+1,site_index_0based=i,
                element=labels[i],is_moving_atom=i==moving,is_cu=i==cu) for j,i in enumerate(ordered)])
            metadata = dict(task_id=name, moving_element=element, environment=environment,
                n_sites=len(sites), n_atoms=len(symbols), supercell=[a.cells]*3,
                a0_angstrom=a.a0, box_length_angstrom=length, intermediate_images=a.images,
                initial_vacancy_site=vacancy, final_vacancy_site=moving,
                moving_poscar_row_1based=move_row+1, cu_site_index=cu,
                moving_start_angstrom=s, moving_end_angstrom=v, jump_vector_angstrom=jump,
                cu_position_angstrom=sites[cu] if cu is not None else None,
                distances=chosen, minimum_image_separation_along_guess_A=path_min,
                counts={el:symbols.count(el) for el in ELEMENTS if el in symbols},
                reverse_related_task=f'{element}_near_solute' if environment=='near_vacancy' else
                    f'{element}_near_vacancy' if environment=='near_solute' else None,
                status='unrelaxed_geometry_only',
                independence_requires_training_dataset_overlap_audit=True,
                notes=['Near-vacancy and near-solute are reverse-related controls, not independent mechanisms.',
                       'Far Cu is only the farthest selected periodic site, not infinite dilution.',
                       'Relax endpoints and verify basin retention before interpolating a production NEB.',
                       'No POTCAR, INCAR, KPOINTS, or job submission is generated.'])
            (task/'metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
            row=dict(task_id=name,n_atoms=len(symbols),cu_site=cu,
                cu_vacancy_distance_A=chosen['distance_to_initial_vacancy_A'] if chosen else '',
                cu_solute_distance_A=chosen['distance_to_initial_solute_A'] if chosen else '',
                cu_midpoint_distance_A=chosen['distance_to_path_midpoint_A'] if chosen else '',
                min_pair_distance_A=path_min,moving_row_1based=move_row+1,
                reverse_related_task=metadata['reverse_related_task'] or '')
            manifest.append(row)
            print('[generated]',name,'atoms=',len(symbols),'min_distance=',round(path_min,4))
    write_csv(a.output/'manifest.csv',manifest)
    (a.output/'generation.json').write_text(json.dumps(dict(tasks=len(manifest),
        poscars=len(manifest)*(a.images+2), geometry_checks_passed=True,
        stage='geometry only, no energies or barriers', a0=a.a0,cells=a.cells,
        reverse_related_controls_not_independent=True),indent=2),encoding='utf-8')
    print('Manifest:',a.output/'manifest.csv')


if __name__=='__main__':
    main()
