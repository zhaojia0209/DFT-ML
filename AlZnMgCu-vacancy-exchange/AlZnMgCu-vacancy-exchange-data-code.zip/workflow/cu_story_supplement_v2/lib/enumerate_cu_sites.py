"""Exact cubic-FCC directed exchange-pair symmetry enumeration (one Cu)."""
import argparse
import itertools
import json
import math
from pathlib import Path
from build_cu_environment_paths import poscar, write_csv, distance, ELEMENTS


def enumerate_sites(n, shells):
    L=2*n; v=(0,0,0); s=(1,1,0)
    sites=[tuple(2*i+b for i,b in zip(ijk,basis))
           for ijk in itertools.product(range(n),repeat=3)
           for basis in ((0,0,0),(0,1,1),(1,0,1),(1,1,0))]
    def d2(r,q):
        return sum(min((x-y)%L,(y-x)%L)**2 for x,y in zip(r,q))
    # All signed permutations are symmetries of cubic FCC; only those fixing the
    # ordered endpoints separately enter the reduction (do not swap solute/vacancy).
    operations=[]
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((-1,1),repeat=3):
            if tuple(signs[j]*s[perm[j]]%L for j in range(3))==s:
                operations.append((perm,signs))
    def orbit(r):
        return {tuple(signs[j]*r[perm[j]]%L for j in range(3)) for perm,signs in operations}
    allowed=sorted({d2(r,v) for r in sites if r!=v})[:shells]
    candidates={r for r in sites if r not in (v,s) and (d2(r,v) in allowed or d2(r,s) in allowed)}
    groups={}
    for r in candidates:
        key=min(orbit(r)); groups.setdefault(key,set()).add(r)
    for key,members in groups.items():
        assert orbit(key)==members
    index={key:i for i,key in enumerate(sorted(groups))}
    records=[]
    for key in sorted(groups):
        reversed_site=tuple((x-y)%L for x,y in zip(s,key))
        reverse_key=min(orbit(reversed_site))
        records.append(dict(class_id='cu_%03d'%index[key],site=key,
            degeneracy=len(groups[key]),members=sorted(groups[key]),
            reverse_class='cu_%03d'%index[reverse_key],dv2=d2(key,v),ds2=d2(key,s)))
    assert sum(r['degeneracy'] for r in records)==len(candidates)
    return sites,records,len(operations),allowed


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cells',type=int,default=3)
    p.add_argument('--a0',type=float,default=4.05)
    p.add_argument('--shells',type=int,choices=(1,2),default=2)
    p.add_argument('--existing',type=Path,help='Old geometry root; identify symmetry-equivalent existing tasks')
    a=p.parse_args()
    if a.cells<3 or not math.isfinite(a.a0) or a.a0<=0: p.error('Invalid cell/a0')
    if a.output.exists(): p.error('Output exists; use a new directory')
    sites,records,nops,allowed=enumerate_sites(a.cells,a.shells)
    a.output.mkdir(parents=True)
    length=a.cells*a.a0
    physical=[tuple(x*a.a0/2 for x in r) for r in sites]
    vacancy=sites.index((0,0,0)); moving=sites.index((1,1,0))
    rows=[]
    for e in ('Mg','Zn'):
        for rec in records:
            name=e+'_'+rec['class_id']; task=a.output/'tasks'/name
            cu=sites.index(rec['site'])
            symbols_by_site={i:('Cu' if i==cu else e if i==moving else 'Al') for i in range(len(sites)) if i!=vacancy}
            order=sorted(symbols_by_site,key=lambda i:(ELEMENTS.index(symbols_by_site[i]),i))
            symbols=[symbols_by_site[i] for i in order]; mover=order.index(moving)
            minimum=float('inf')
            for image in range(7):
                xyz=[physical[i] for i in order]
                xyz[mover]=tuple(x*(1-image/6) for x in physical[moving])
                minimum=min(minimum,min(distance(x,y,length) for j,x in enumerate(xyz) for y in xyz[j+1:]))
                poscar(task/f'{image:02d}'/'POSCAR',symbols,xyz,length,name+' unrelaxed')
            if minimum<1.5: raise ValueError('Unsafe minimum distance '+name)
            write_csv(task/'atom_map.csv',[dict(poscar_row_1based=j+1,site_index_0based=i,
                element=symbols_by_site[i],is_moving_atom=i==moving,is_cu=i==cu) for j,i in enumerate(order)])
            meta=dict(task_id=name,moving_element=e,environment=rec['class_id'],
                n_sites=len(sites),n_atoms=len(sites)-1,supercell=[a.cells]*3,
                a0_angstrom=a.a0,box_length_angstrom=length,intermediate_images=5,
                moving_poscar_row_1based=mover+1,moving_start_angstrom=physical[moving],
                moving_end_angstrom=physical[vacancy],initial_vacancy_site=vacancy,
                final_vacancy_site=moving,cu_site_index=cu,cu_position_angstrom=physical[cu],
                degeneracy=rec['degeneracy'],reverse_related_task=e+'_'+rec['reverse_class'],
                status='unrelaxed_geometry_only',enumeration_scope='one Cu; union of specified shells around ordered pair')
            (task/'metadata.json').write_text(json.dumps(meta,indent=2))
            rows.append(dict(task=name,degeneracy=rec['degeneracy'],
                cu_vacancy_distance_A=math.sqrt(rec['dv2'])*a.a0/2,
                cu_solute_distance_A=math.sqrt(rec['ds2'])*a.a0/2,
                cu_x_A=physical[cu][0],cu_y_A=physical[cu][1],cu_z_A=physical[cu][2],
                reverse_related_task=meta['reverse_related_task'],min_distance_A=minimum))
    write_csv(a.output/'enumeration.csv',rows)
    reused=[]
    if a.existing:
        if not (a.existing/'tasks').is_dir(): raise ValueError('Existing geometry tasks directory missing')
        for f in sorted((a.existing/'tasks').glob('*/metadata.json')):
            old=json.loads(f.read_text()); pos=old.get('cu_position_angstrom')
            if pos is None: continue
            if abs(old['box_length_angstrom']-length)>1e-8 or abs(old['a0_angstrom']-a.a0)>1e-8:
                raise ValueError('Old geometry cell differs; cannot assume exact equivalence')
            old_site=tuple(round(x*2/a.a0)%(2*a.cells) for x in pos)
            for rec in records:
                if old_site in rec['members']:
                    reused.append(dict(task=old['moving_element']+'_'+rec['class_id'],existing_task=old['task_id'],
                                       relationship='directed_pair_symmetry_equivalent_initial_geometry'))
        if reused: write_csv(a.output/'reuse_matches.csv',reused)
    matched={r['task'] for r in reused}
    (a.output/'new_task_names.txt').write_text('\n'.join(r['task'] for r in rows if r['task'] not in matched)+'\n')
    (a.output/'symmetry.json').write_text(json.dumps(dict(cells=a.cells,a0=a.a0,
        shells=a.shells,shell_squared_distances_half_lattice_units=allowed,
        directed_pair_symmetry_operations=nops,candidate_sites=sum(r['degeneracy'] for r in records),
        directed_classes_per_solute=len(records),classes=records,
        note='Reverse-related classes retained separately. Degeneracy is a count, not a kinetic population.'),indent=2))
    print('Classes per solute:',len(records),'Total tasks:',len(rows),'POSCARs:',7*len(rows))
    print('Output:',a.output)


if __name__=='__main__': main()
