"""Counts, cross-split group leakage and approximate wrapped-coordinate duplicates."""
import argparse
import collections
import hashlib
import json
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--train',type=Path,required=True)
    p.add_argument('--valid',type=Path,required=True)
    p.add_argument('--test',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.output.exists():p.error('Output exists')
    import numpy as np
    from ase.io import iread
    summary={};groups=collections.defaultdict(set);geometries=collections.defaultdict(set)
    missing_groups={}
    for split in ('train','valid','test'):
        counts=collections.Counter();missing=0
        for frame in iread(str(getattr(a,split)),index=':'):
            counts[str(frame.info.get('config_type','unspecified'))]+=1
            g=frame.info.get('original_group_id',frame.info.get('group_id'))
            if g is None:missing+=1
            else:groups[str(g)].add(split)
            # Conservative duplicate screen only; no rotation/origin-change equivalence.
            pos=frame.get_positions(wrap=True)
            atomic=sorted((int(z),*np.round(r,6)) for z,r in zip(frame.numbers,pos))
            key=repr((atomic,np.round(frame.cell.array,6).tolist(),frame.pbc.tolist()))
            geometries[hashlib.sha256(key.encode()).hexdigest()].add(split)
        summary[split]=dict(counts);missing_groups[split]=missing
    result=dict(counts=summary,missing_group_ids=missing_groups,
        cross_split_group_ids={g:sorted(s) for g,s in groups.items() if len(s)>1},
        cross_split_geometry_hashes={g:sorted(s) for g,s in geometries.items() if len(s)>1},
        caveats=['Group-name collisions across sources need manual inspection.',
                 'No group ID or duplicate match is NOT proof of independence.',
                 'Symmetry-equivalent, translated and nearby trajectory frames need a provenance audit.'])
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2))
    print(a.output)


if __name__=='__main__':main()
