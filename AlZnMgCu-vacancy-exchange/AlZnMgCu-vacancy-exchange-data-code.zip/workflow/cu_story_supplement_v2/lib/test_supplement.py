import unittest
from enumerate_cu_sites import enumerate_sites


class SymmetryTests(unittest.TestCase):
    def test_partition(self):
        sites,rows,operations,shells=enumerate_sites(3,2)
        self.assertEqual(len(sites),108)
        self.assertEqual(len(rows),11)
        self.assertEqual(operations,4)
        self.assertEqual(shells,[2,4])
        self.assertEqual(sum(r['degeneracy'] for r in rows),26)
        all_members=[r for row in rows for r in row['members']]
        self.assertEqual(len(all_members),len(set(all_members)))

    def test_reverse_involution(self):
        _,rows,_,_=enumerate_sites(3,2);by={r['class_id']:r for r in rows}
        for r in rows:
            other=by[r['reverse_class']]
            self.assertEqual(other['reverse_class'],r['class_id'])
            self.assertEqual(other['dv2'],r['ds2'])
            self.assertEqual(other['degeneracy'],r['degeneracy'])

    def test_larger_cell_same_local_classes(self):
        _,small,_,_=enumerate_sites(3,2)
        _,large,_,_=enumerate_sites(4,2)
        self.assertEqual(sorted((r['dv2'],r['ds2'],r['degeneracy']) for r in small),
                         sorted((r['dv2'],r['ds2'],r['degeneracy']) for r in large))


if __name__=='__main__':unittest.main()
