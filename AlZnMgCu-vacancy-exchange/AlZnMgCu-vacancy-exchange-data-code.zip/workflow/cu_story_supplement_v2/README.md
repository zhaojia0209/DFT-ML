# Cu 局部环境故事补充包 v2

本包对应上一轮清单第 2–6 项；**不执行第 1 项旧六条 DFT 生产任务**。
所有新输出在 `work/cu_story_supplement_v2/`。只读取原数据，不改原 scripts、不清理旧输出。
请将整个 `cu_story_supplement_v2` 文件夹放在 `/home/zhaojia/AlZnMgCuV1/`，不要拆开或只复制单个文件。

## 必须先知道

- `run.sh` 固定使用项目 Python 3.11 环境运行 MACE；默认 Python 3.8 只用于 ASE/DFT 和分析。**不修改系统 python3**。
- 文件是 LF 换行，无需粘贴代码生成脚本，也不要把 Markdown 的 ``` 粘贴到终端。
- DFT 使用 **ASE 串行图像 CI-NEB + 原版 vasp_std 单点力**，不是之前 VASP 原生 `IMAGES=5` 的 90-rank 模式。
  默认每次一个图像、18 MPI ranks，随后计算下一个图像。`--ranks 90` 表示单个图像用90进程，不是5×18，通常不应直接套用。
- 保持参考 ENCUT520、EDIFF1e-6、Gamma3×3×3、ISMEAR1、SIGMA0.15、Mg_pv/Cu_pv。每次验证 POTCAR SHA256。
- ASE优化使用 VASP free energy 与对应力；同时输出 sigma→0 能量和势垒，用于和原论文口径对照。
  两种能量的最高图像若不同，summary 会标记。不同展宽测试要检查这一差异。
- CI收敛不等于 Hessian 已证明仅有一个不稳定模式；本包没有声称完成振动模式验证或尝试频率计算。
- 新任务使用自动释放文件锁，并在每次VASP启动前检查其他VASP进程。旧脚本不共享锁，因此不要同时启动旧任务与新DFT任务。
- 同命令重跑会检查设置一致性，已收敛则跳过，未完成则恢复完整坐标检查点；电子态及优化器历史重新初始化。
  不会自动恢复有破损记录的旧任务。修改参数请使用不同目录。
- 每次成功DFT单点按几何哈希缓存，输出保留在scf目录；这利于恢复但需要较多磁盘空间。运行前检查空间，不自动删除任何SCF数据。
- `nohup/setsid` 可以脱离终端，**不能抵抗WSL关机、Windows重启或硬件故障**。
- 受限Cu计算固定所有图像的Cu在起始Cu位置，重新优化受限端点；结果是该约束定义下的势垒，不是唯一化学/弹性分解。

## 0. 环境自检，不启动计算

```bash
cd /home/zhaojia/AlZnMgCuV1
/usr/bin/python3.8 -c "import sys,ase,numpy; print(sys.executable,ase.__version__,numpy.__version__)"
env -u LD_LIBRARY_PATH -u LD_PRELOAD -u PYTHONPATH \
  /home/zhaojia/AlZnMgCuV1/.venv-mace-cpu/bin/python3 \
  -c "import torch,mace,ase; print(torch.__version__,ase.__version__,mace.__file__)"
bash cu_story_supplement_v2/run.sh test
```

如3.8缺ASE，使用同一解释器安装：`/usr/bin/python3.8 -m pip install --user 'ase==3.23.0'`。
不要用该命令改变MACE环境。安装失败先解决环境，不要混用另一个同名venv。
如Intel库未初始化，先加载你原先可成功运行VASP的oneAPI环境，再运行本包。

## 2. 两壳层局部Cu枚举与MACE筛选

范围：有向Mg/Zn–V最近邻对两端1NN和2NN的并集，单个Cu，3×3×3 FCC，a0=4.05 Å。
整数晶格对称去重：26个候选Cu位点，11个有向类/溶质，共22类。
反向相关类保留并注明，不当作独立机制或统计重复。这里**不宣称覆盖三壳层及更远Cu环境**。

```bash
bash cu_story_supplement_v2/run.sh enumerate
bash cu_story_supplement_v2/background.sh screen --seed 11 --threads 8
```

输出：`geometries/enumeration.csv`、`symmetry.json`、`reuse_matches.csv`；`mace_seed11/landscape_all.csv`。
seed11按模型哈希和原收敛报告验证后复用已完成的等价代表路径；新类计算端点和CI路径。
旧代表的别名也保留用于far/no参照，**不把别名和枚举类重复计入构型统计**。
复用的等价类保留旧构型实际空间取向；距离等不变量可比较，画空间取向图须使用该输出的实际结构而不是枚举位点坐标。

三种子独立优化（先完成seed11，不要同时启动三份抢CPU）：

```bash
bash cu_story_supplement_v2/background.sh screen --seed 29 --threads 8
# 上一个完成后
bash cu_story_supplement_v2/background.sh screen --seed 47 --threads 8
```

也可先只跑代表：`screen --seed 29 --tasks Mg_far_cu Mg_common_neighbor Mg_near_solute Zn_far_cu Zn_common_neighbor Zn_near_solute`。
新种子重新优化自己的端点，不能直接把seed11端点当作该模型已收敛端点。

## 3. 两条高势垒DFT路径（新计算）

确认旧VASP已停，执行：

```bash
bash cu_story_supplement_v2/background.sh dft-high --ranks 18
```

顺序运行Mg_near_solute、Zn_near_solute，自动DFT端点优化、普通NEB预优化、CI-NEB与最终汇总。
输出 `dft_high/<task>/summary.json`、`profile.csv`、`band/`。
没有重复启动旧六条任务，也没有生成/覆盖旧campaign记录。
如枚举发现新极值，可明确指定 `--tasks Mg_cu_XXX`（用实际枚举类名），先确保该类seed11筛选完成。

## 4. 数值可靠性、图像数、鞍点精化

默认选择Mg/Zn × far_cu/common_neighbor。先确保这些**旧NEB源文件已收敛**。
导出步骤只读取正常结束且收敛的OUTCAR及完整CONTCAR，失败会停止，绝不改原目录。

```bash
# 从已有普通DFT-NEB几何精化，形成一致的CI基线
bash cu_story_supplement_v2/background.sh dft-check --variant base --ranks 18
```

基线完成后，逐项运行，不要整段同时提交：

```bash
bash cu_story_supplement_v2/background.sh dft-check --variant k4 --ranks 18
bash cu_story_supplement_v2/background.sh dft-check --variant tight --ranks 18
bash cu_story_supplement_v2/background.sh dft-check --variant images7 --ranks 18
bash cu_story_supplement_v2/background.sh dft-check --variant encut600 --ranks 18
bash cu_story_supplement_v2/background.sh dft-check --variant sigma010 --ranks 18
```

以上每行均为独立任务：k4=4×4×4；tight=CI0.01/端点0.005 eV/Å；images7=7个中间图像；ENCUT600 eV；SIGMA0.10 eV。
都从同一原路径出发并在各自电子设置下重新优化端点。
优先k4和tight；如果资源有限，用`--tasks Mg_common_neighbor Mg_far_cu`先完成一组配对，不能只测common不测far就宣称势垒差收敛。

路径起点敏感性（可选）：

```bash
bash cu_story_supplement_v2/background.sh dft-check --variant perturb --ranks 18
```

固定随机种子，对中间图像施加0.02 Å尺度扰动后重新优化。这只是一项初始路径敏感性检查，不证明全局最低路径。

超胞检查（很昂贵，先确认其他结果）：

```bash
bash cu_story_supplement_v2/background.sh cell4 --ranks 18 --threads 8
```

重新建立4×4×4 FCC、255原子、**一个空位**，不是复制107原子的含空位结构。
先MACE端点+CI，再DFT端点+CI，保持Gamma3×3×3，不用降k点补偿尺寸。
局部common几何保持同类型；far选择大超胞最远位点，所以比较同时检验far参考的有限距离效应。
如要分开尺寸效应与far距离效应，另需同物理Cu距离映射的大超胞对照，不应把本结果称为纯粹尺寸分解。

各组完成后汇总：

```bash
bash cu_story_supplement_v2/run.sh compare \
 --roots work/cu_story_supplement_v2/dft_check_base \
         work/cu_story_supplement_v2/dft_check_k4 \
         work/cu_story_supplement_v2/dft_check_tight \
         work/cu_story_supplement_v2/dft_check_images7 \
         work/cu_story_supplement_v2/dft_check_encut600 \
         work/cu_story_supplement_v2/dft_check_sigma010 \
         work/cu_story_supplement_v2/cell4_dft_k3 \
 --output work/cu_story_supplement_v2/convergence_report
```

读取`all_runs.csv`和`contrasts.csv`，比较common−far差值是否稳定。没有自动将任意阈值包装成通用学术标准。

## 5. 初态/峰值/末态分解与局部结构

先对独立一致的DFT基线分析：

```bash
bash cu_story_supplement_v2/run.sh analyze \
 --runs work/cu_story_supplement_v2/dft_check_base/Mg_far_cu \
        work/cu_story_supplement_v2/dft_check_base/Mg_common_neighbor \
        work/cu_story_supplement_v2/dft_high/Mg_near_solute \
        work/cu_story_supplement_v2/dft_check_base/Zn_far_cu \
        work/cu_story_supplement_v2/dft_check_base/Zn_common_neighbor \
        work/cu_story_supplement_v2/dft_high/Zn_near_solute \
 --output work/cu_story_supplement_v2/mechanism_report
```

产出`stabilization.csv`、`geometry.csv`、`conditional_rates.csv`。
检查相同组成、晶胞、电子设置/模型哈希与约束方案后，才允许同成分far-Cu参考分解。
Cu-free不参与原始总能量稳定化相减。CI峰值称peak，未做Hessian时不标注已证实一阶鞍点。

少量固定Cu受限计算（**非必须先跑的昂贵阶段**）：

```bash
bash cu_story_supplement_v2/background.sh mechanism --ranks 18 \
 --tasks Mg_far_cu Mg_common_neighbor Mg_near_solute Zn_far_cu Zn_common_neighbor Zn_near_solute
```

对照`freeze_cu`与相应不受限基线的势垒差，包含重新优化后的受限端点。
它检验Cu位移自由度的作用；不等价于把所有邻域弛豫冻结，也不是电子机制证明。

## 6. 三模型同几何评估、测试精度、划分审计、条件速率

同一组MACE枚举路径上计算三模型分歧：

```bash
bash cu_story_supplement_v2/background.sh evaluate \
 --bands work/cu_story_supplement_v2/mace_seed11/Mg_cu_* work/cu_story_supplement_v2/mace_seed11/Zn_cu_* \
 --output work/cu_story_supplement_v2/committee_enumeration
```

已有42个新Cu DFT图像，逐帧能量/力/应力与势垒误差：

```bash
bash cu_story_supplement_v2/background.sh evaluate \
 --stage work/cu_environment_dft_v1/sp \
 --output work/cu_story_supplement_v2/holdout_sp
```

原测试集统一精度表：

```bash
bash cu_story_supplement_v2/background.sh evaluate \
 --test work/vacancy_reweight_v6/02_mace/test.extxyz \
 --output work/cu_story_supplement_v2/test_metrics
bash cu_story_supplement_v2/run.sh audit
```

评估输出`per_frame.csv`（含应力六分量）、`force_pairs_seed*.csv`、`metrics.csv`、路径时有`barriers_fixed_geometry.csv`、`committee.csv`。
同几何势垒必须与`screen --seed 29/47`得到的独立优化势垒区别标注。
audit报告组ID和近似几何重复，只是筛查，不自动证明无数据泄漏。原始组ID跨来源同名可能需人工核对。

第5节`analyze`已输出373/423/473 K等前因子相对跳跃速率；可通过`--temperatures`改变。
不提供未经校准的置信区间、不把委员会标准差当真实误差、不导出宏观扩散系数。
对不同seed分别运行`analyze`可显示模型间速率范围，但该范围不是置信区间。

## 每次后台任务如何看进度/恢复

background.sh打印唯一日志路径。使用 `tail -f 完整日志路径` 查看；Ctrl-C只退出tail。
旧DFT仍在运行时，新DFT会报`VASP is already running`并停止，不会偷偷排队。
确认旧任务结束后，重复**同一条background命令**即可。
补充任务若被WSL停止，修复宿主问题后重复原命令恢复坐标。不要删除summary、settings或SCF缓存。
正常完成以`summary.json`的`status=converged`为准，不只看后台进程退出码。

## 测试与边界

提供离线`test_story.py`：Python3.8语法、枚举对称性、反向映射、原子记录写入、默认参数；有ASE时额外测试插值和检查点。
构建机器不具备VASP/MACE执行环境，所以**没有声称通过真实VASP/MACE端到端计算测试**。
不能直接修改旧VASP正在读取的输入。所有首次真实计算建议只指定一个新任务，检查第一轮SCF与日志后继续。
方法参考：https://docs.ase-lib.org/ase/neb.html
