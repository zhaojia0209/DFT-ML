#!/usr/bin/env bash
set -euo pipefail
PROJECT=${PROJECT:-/home/zhaojia/AlZnMgCuV1}
cd "$PROJECT"
mkdir -p work/cu_story_supplement_v2_logs
LOG=$(mktemp "$PROJECT/work/cu_story_supplement_v2_logs/job_XXXXXX.log")
nohup setsid bash "$PROJECT/cu_story_supplement_v2/run.sh" "$@" > "$LOG" 2>&1 < /dev/null &
LAUNCH_PID=$!
disown "$LAUNCH_PID" 2>/dev/null || true
printf 'Launcher PID: %s\nLog: %s\n' "$LAUNCH_PID" "$LOG"
printf 'Closing this terminal is OK. Windows/WSL shutdown still stops the calculation.\n'
