"""Three-model fixed-geometry predictions and optional DFT/test error tables."""
import argparse
import json
from pathlib import Path
import sys
import csv
from story import model_calc, digest, table, atomic_json, band_files
from pipeline import model as model_path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument('--bands', type=Path, nargs='+', help='One or more task run dirs containing band/ and summary.json')
    src.add_argument('--stage', type=Path, help='Original sp/final-sp directory with manifest.json')
    src.add_argument('--test', type=Path, help='extxyz test set with REF_energy/REF_forces/REF_stress')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--project', type=Path, default=Path.cwd())
    p.add_argument('--threads', type=int, default=8)
    p.add_argument('--seeds', type=int, nargs='+', choices=[11,29,47], default=[11,29,47])
    a = p.parse_args()
    if a.output.exists():
        p.error('Output exists; use another name')
    import numpy as np
    from ase.io import read
    from ase.stress import full_3x3_to_voigt_6_stress
    from cu_dft_workflow import load_result
    data = []
    if a.bands:
        for root in a.bands:
            s = json.loads((root/'summary.json').read_text())
            if s['status'] != 'converged':
                raise ValueError('Unconverged input')
            for i, f in enumerate(band_files(root/'band')):
                data.append((s['task'],i,'Cu_path',read(str(f)),None))
    elif a.stage:
        for ent in json.loads((a.stage/'manifest.json').read_text()):
            f = Path(ent['path'])
            if not f.is_dir():
                # Local copy portability: resolve this stage's task basename, never rewrite source manifest.
                f = a.stage/'tasks'/Path(ent['path']).name
            atoms,e,free,_ = load_result(f)
            data.append((ent['task'],int(ent['image']),'Cu_DFT',atoms,
                         (e,atoms.get_forces(),atoms.get_stress())))
    else:
        for i, atoms in enumerate(read(str(a.test), index=':')):
            if 'REF_energy' not in atoms.info or 'REF_forces' not in atoms.arrays or 'REF_stress' not in atoms.info:
                raise ValueError('Missing explicit REF labels at frame %d' % i)
            stress=np.asarray(atoms.info['REF_stress'],dtype=float)
            if stress.shape==(3,3):
                stress=full_3x3_to_voigt_6_stress(stress)
            if stress.shape != (6,):
                raise ValueError('Invalid REF_stress shape')
            data.append((str(atoms.info.get('task_id','test_%d'%i)),i,
                         str(atoms.info.get('config_type','unknown')),atoms,
                         (float(atoms.info['REF_energy']),atoms.arrays['REF_forces'],stress)))
    if not data:
        raise ValueError('No input frames')
    a.output.mkdir(parents=True)
    frame_rows, metrics, profile_rows = [], [], []
    allE, allF = [], []
    for seed in a.seeds:
        path = model_path(a.project.resolve(),seed)
        calc = model_calc(path,a.threads)
        eerrors, ferrors, serrors = {}, {}, {}
        es, fs = [], []
        with (a.output/('force_pairs_seed%d.csv'%seed)).open('w',newline='') as ff:
            fw=csv.writer(ff);fw.writerow(['frame','task','atom','component','dft_ev_A','mace_ev_A'])
            for j,(task,i,cls,ref,labels) in enumerate(data):
                x=ref.copy();x.set_constraint();x.calc=calc
                e=float(x.get_potential_energy());f=x.get_forces();s=x.get_stress()
                if not np.isfinite(e) or not np.isfinite(f).all() or not np.isfinite(s).all():
                    raise ValueError('Nonfinite prediction')
                es.append(e);fs.append(f.copy())
                r={'seed':seed,'frame':j,'task':task,'image':i,'config_type':cls,'n_atoms':len(x),
                   'mace_energy_ev':e,'dft_energy_ev':'','energy_error_ev_atom':'','force_rmse_ev_A':'','stress_rmse_GPa':''}
                for k, comp in enumerate(('xx','yy','zz','yz','xz','xy')):
                    r['mace_stress_'+comp+'_GPa']=float(s[k]*160.21766208)
                    r['dft_stress_'+comp+'_GPa']=''
                if labels:
                    re,rf,rs=labels;de=(e-re)/len(x);df=f-rf;ds=(s-rs)*160.21766208
                    r.update(dft_energy_ev=re,energy_error_ev_atom=de,
                             force_rmse_ev_A=float(np.sqrt(np.mean(df**2))),stress_rmse_GPa=float(np.sqrt(np.mean(ds**2))))
                    for k,comp in enumerate(('xx','yy','zz','yz','xz','xy')):
                        r['dft_stress_'+comp+'_GPa']=float(rs[k]*160.21766208)
                    for atom in range(len(x)):
                        for k,comp in enumerate('xyz'):
                            fw.writerow([j,task,atom+1,comp,rf[atom,k],f[atom,k]])
                    for group in ('all',cls):
                        eerrors.setdefault(group,[]).append(de)
                        ferrors.setdefault(group,[]).extend(df.ravel())
                        serrors.setdefault(group,[]).extend(ds.ravel())
                frame_rows.append(r)
        for cls in eerrors:
            r={'seed':seed,'config_type':cls,'n_frames':len(eerrors[cls])}
            for kind,values in [('energy_ev_atom',eerrors[cls]),('force_ev_A',ferrors[cls]),('stress_GPa',serrors[cls])]:
                v=np.asarray(values)
                r[kind+'_mae']=float(np.abs(v).mean());r[kind+'_rmse']=float(np.sqrt(np.mean(v**2)))
                r[kind+'_max_abs']=float(np.abs(v).max())
            metrics.append(r)
        if not a.test:
            for task in sorted({x[0] for x in data}):
                idx=sorted([j for j,x in enumerate(data) if x[0]==task],key=lambda j:data[j][1])
                if [data[j][1] for j in idx] != list(range(len(idx))):
                    raise ValueError('Missing/duplicate image indices')
                ee=[es[j] for j in idx]
                row={'seed':seed,'task':task,'forward_barrier_ev':max(ee)-ee[0],
                     'reverse_barrier_ev':max(ee)-ee[-1],'max_image':int(np.argmax(ee)),
                     'geometry':'same_fixed_geometries','dft_forward_ev':'','barrier_error_ev':''}
                if data[idx[0]][4]:
                    rr=[data[j][4][0] for j in idx]
                    row.update(dft_forward_ev=max(rr)-rr[0],barrier_error_ev=max(ee)-ee[0]-max(rr)+rr[0])
                profile_rows.append(row)
        allE.append(es);allF.append(fs)
        atomic_json(a.output/('model_seed%d.json'%seed),{'path':str(path),'sha256':digest(path)})
    table(a.output/'per_frame.csv',frame_rows)
    if metrics:table(a.output/'metrics.csv',metrics)
    if profile_rows:table(a.output/'barriers_fixed_geometry.csv',profile_rows)
    if len(a.seeds)>1:
        table(a.output/'committee.csv',[{'task':d[0],'image':d[1],
            'energy_std_ev_atom':float(np.std([v[j] for v in allE],ddof=1)/len(d[3])),
            'force_std_RMS_ev_A':float(np.sqrt(np.mean(np.var(np.stack([v[j] for v in allF]),axis=0,ddof=1))))}
            for j,d in enumerate(data)])
    atomic_json(a.output/'notes.json',{'independence':'Requires provenance audit; not inferred from this evaluation.',
        'spread':'Committee spread is not a calibrated confidence interval.',
        'stress_order':['xx','yy','zz','yz','xz','xy'], 'force_atom_index':'1-based'})


if __name__=='__main__':main()
